
ALTER TABLE `q_main_base`.`incidents` 
ADD COLUMN `db_threat_model_mitre_public` VARCHAR(3) NULL DEFAULT 'No' AFTER `db_Share_SLA_Escalation_Recipients`,
ADD COLUMN `db_threat_model_qcontex_public` VARCHAR(3) NULL DEFAULT 'No' AFTER `db_threat_model_mitre_public`,
ADD COLUMN `db_threat_model_killchain_public` VARCHAR(3) NULL DEFAULT 'No' AFTER `db_threat_model_qcontex_public`,
ADD COLUMN `db_threat_model_diamond_public` VARCHAR(3) NULL DEFAULT 'No' AFTER `db_threat_model_killchain_public`;


ALTER TABLE `q_main_base`.`incidents` 
ADD COLUMN `db_submission_form_title` VARCHAR(500) NULL AFTER `db_threat_model_diamond_public`,
ADD COLUMN `db_submission_form_type` VARCHAR(45) NULL AFTER `db_submission_form_title`,
ADD COLUMN `db_submission_form_content` LONGTEXT NULL AFTER `db_submission_form_type`,
ADD COLUMN `db_submission_form_file_name` VARCHAR(45) NULL AFTER `db_submission_form_content`,
ADD COLUMN `db_submission_form_file_title` VARCHAR(45) NULL AFTER `db_submission_form_file_name`;


INSERT INTO `q_main_base`.`system_properties` (`db_id`, `db_Name`, `db_Group`, `db_Display_Text`, `db_Customizable`, `db_Value_SIMP`, `db_Value_SCMP`, `db_Value_STMP`, `db_Value_CTSP`, `db_Value_CISO`, `db_LastUpdate`, `db_Hidden`, `db_Applied_To_Module`, `db_Value_Type`, `db_List_Default_Values`, `db_Value_Selection`, `db_Group_Order`) VALUES ('324', 'ADDIN_MSG_CONTENT_AR', 'Addin_Settings', 'MESSAGE CONTENT - AR', 'Yes', '', '', '', '', '', '2022-06-01 09:11:37', 'No', 'simp scmp stmp', 'FreeList', '', 'Multiple', '0');
INSERT INTO `q_main_base`.`system_properties` (`db_id`, `db_Name`, `db_Group`, `db_Display_Text`, `db_Customizable`, `db_Value_SIMP`, `db_Value_SCMP`, `db_Value_STMP`, `db_Value_CTSP`, `db_Value_CISO`, `db_LastUpdate`, `db_Hidden`, `db_Applied_To_Module`, `db_Value_Type`, `db_List_Default_Values`, `db_Value_Selection`, `db_Group_Order`) VALUES ('325', 'ADDIN_MSG_CONTENT_EN', 'Addin_Settings', 'MESSAGE CONTENT - EN', 'Yes', '', '', '', '', '', '2022-06-01 09:11:37', 'No', 'simp scmp stmp', 'FreeList', '', 'Multiple', '0');
ALTER TABLE `q_main_base`.`custom_attributes` CHANGE COLUMN `db_Value` `db_Value` VARCHAR(5000) NULL DEFAULT NULL ;
