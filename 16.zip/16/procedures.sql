DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `addActivityLog`(
IN p_Subject varchar(50),
IN p_Object varchar(50),
IN p_ObjectID int(11),
IN p_Event varchar(50),
IN p_EventDetails longtext ,
IN p_RemotIP varchar(100),
IN p_module varchar(50)
)
BEGIN

INSERT INTO activity_logs
( 
db_Subject,
db_Object,
db_ObjectID,
db_Event,
db_EventDetails,
db_RemotIP,
db_module
 )
VALUES
(
 p_Subject,
 p_Object,
 p_ObjectID,
 p_Event,
 p_EventDetails,
 p_RemotIP,
 p_module
);



END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `addSecurityLog`(   
IN p_Type VARCHAR (50),
IN p_Caller VARCHAR (300),
IN p_RemoteIP VARCHAR (50),
IN p_Details LONGTEXT,
IN p_product VARCHAR (50)
  )
BEGIN

 INSERT INTO security_logs (`Type`,Caller,RemoteIP,Details, Product) 
 VALUES (p_Type,p_Caller,p_RemoteIP,p_Details,p_product);
 
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `api_getAll`(
IN p_module VARCHAR(50)
)
BEGIN

SELECT a.*,  DATE_FORMAT(a.db_dateCreated,'%d-%m-%Y %h:%i %p') as 'db_DateFormatted', u.db_FullName, DATE_FORMAT(a.db_last_request,'%d-%m-%Y %h:%i %p') as 'db_Last_Request_Date_Formatted'
FROM api a, users u
WHERE a.db_module = p_module
AND a.db_del = 'No'
AND a.db_created_by = u.db_id
ORDER BY a.db_id DESC
LIMIT 500

;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `api_getAllByKey`(
IN p_key varchar(500)
)
BEGIN

SELECT * FROM api 
WHERE db_del = 'No'
AND db_key = p_key
LIMIT 1
;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `api_getAllObjectsByLastUpdatedByHours`(
IN p_last_updated_hours INT(11)
)
BEGIN

SELECT 
		t1.db_FullName as 'Assginee',
		t2.db_FullName as 'Owner',
        t.name as 'Type', 
        categories.name as 'Category',
        subcategories.name as 'Sub_Category',
        DATE_FORMAT(i.db_StartDateTime,'%d-%m-%Y %h:%i %p') as 'Start_Date_Time',
        DATE_FORMAT(i.db_Date_of_Closure,'%d-%m-%Y %h:%i %p') as 'Closure_Date',
        concat('Q',QUARTER(i.db_startdatetime)) as 'Quarter',
		MONTHNAME(STR_TO_DATE(Month(i.db_startdatetime), '%m')) as 'Month',
        Year(i.db_startdatetime) as 'Year',
        group_concat(DISTINCT concat(asset.db_name,':',asset.db_value) SEPARATOR '|') as 'Assets',
        group_concat(DISTINCT concat(ioc.db_name,':',ioc.db_value) SEPARATOR '|') as 'IOCs'
        
FROM incidents i
LEFT JOIN `types` t on i.db_typeID = t.id 
		LEFT JOIN  categories on i.db_CategoryID = categories.id
        LEFT JOIN subcategories on i.db_SubCategoryID = subcategories.id
        LEFT JOIN users t1 on i.db_ManagerID = t1.db_id
        LEFT JOIN users t2 on i.db_InitiatorID = t2.db_id
        LEFT JOIN incident_ioc asset on i.db_ID = asset.db_ERID 
        LEFT JOIN incident_ioc ioc on i.db_ID = ioc.db_ERID
Where	
		(i.db_deleted = 'No') 
        AND HOUR(TIMEDIFF(now(), i.db_LastUpdate)) <= p_last_updated_hours
		AND t.`name` IN ('Incident')
        AND asset.db_Mode = 'Asset'
        AND asset.db_del = 'No'
        AND ioc.db_Mode = 'IOC'
        AND ioc.db_del = 'No'
        

GROUP BY 	i.db_id        
ORDER By	db_StartDateTime desc
limit p_last_updated_hours;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `api_get_by_id`(
IN p_id INT(11)
)
BEGIN

SELECT a.* 
FROM api a 
WHERE a.db_id = p_id
AND a.db_del = 'No'

;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `api_updateTotalRequestNumbers`(
IN p_id int(11)
)
BEGIN
UPDATE api set db_number_of_requests = (db_number_of_requests + 1) where db_id = p_id;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `asset_get_all`()
BEGIN

SELECT a.*,
		DATE_FORMAT(a.db_first_seen,'%d-%m-%Y %h:%i %p') as 'db_StartDateTimeFormatted',
        DATE_FORMAT(a.db_last_seen,'%d-%m-%Y %h:%i %p') as 'db_ContainmentDateFormatted',
        u1.db_fullname as db_created_by,
		u2.db_fullname as db_updated_by
        
FROM  assets a, users u1, users u2
where 	a.db_del = 'No'
AND 	a.db_created_by_id = u1.db_id
AND 	a.db_updated_by_id = u2.db_id

;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `asset_getAllByERID`(
IN p_id INT(11)
)
BEGIN

SELECT t.*,
	IFNULL((select count(ioc.db_ID) FROM incident_ioc ioc,incidents i,`types` ty where ty.id = i.db_TypeID AND ioc.db_ERID = i.db_ID AND ioc.db_name = t.db_name AND  db_value = t.db_value AND db_Del = 'No' AND i.db_Deleted = 'No' AND ty.Module = 'simp' Group by ioc.db_value ),0)  as db_IR_Hits,
	IFNULL((select count(ioc.db_ID) FROM incident_ioc ioc,incidents i,`types` ty where ty.id = i.db_TypeID AND ioc.db_ERID = i.db_ID AND ioc.db_name = t.db_name AND  db_value = t.db_value AND db_Del = 'No' AND i.db_Deleted = 'No' AND ty.Module = 'stmp' Group by ioc.db_value),0)  as db_Threat_Hits,
	IFNULL((select count(ioc.db_ID) FROM incident_ioc ioc,incidents i,`types` ty where ty.id = i.db_TypeID AND ioc.db_ERID = i.db_ID AND ioc.db_name = t.db_name AND  db_value = t.db_value AND db_Del = 'No' AND i.db_Deleted = 'No' AND ty.Module = 'scmp' Group by ioc.db_value ),0)  as db_Case_Hits,
    IFNULL((select count(ioc.db_ID) FROM incident_ioc ioc,incidents i,`types` ty where ty.id = i.db_TypeID AND ioc.db_ERID = i.db_ID AND ioc.db_name = t.db_name AND  db_value = t.db_value AND db_Del = 'No' AND i.db_Deleted = 'No' AND ty.Module = 'ctsp' Group by ioc.db_value ),0)  as db_Share_Hits,
	IFNULL((select group_concat(concat(db_id,'$',db_name,'$',db_Category) SEPARATOR '|') from tags where db_ChildGroup = 'Asset' and db_ChildGroupID = t.db_ID and db_Del = 'No'),'')  as db_IOC_Tags
FROM incident_ioc t
WHERE t.db_ERID = p_ID 
	AND t.db_Del = 'No'
    AND t.db_Mode = 'Asset'
    

ORDER BY t.db_ID DESC    
    ;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `asset_getAllByERID_ByProfile_ByGroup`(
IN p_id INT(11),
IN p_profile VARCHAR(500),
IN p_group VARCHAR(500)
)
BEGIN


SELECT t.*,
	IFNULL((select count(ioc.db_ID) FROM incident_ioc ioc,incidents i,`types` ty,users u,user_profiles up where ty.id = i.db_TypeID AND ioc.db_ERID = i.db_ID AND i.db_ManagerID = u.db_id AND u.db_UserProfileID = up.id AND up.name = p_profile AND u.db_group = p_group AND ioc.db_name = t.db_name AND  db_value = t.db_value AND ioc.db_Del = 'No' AND i.db_Deleted = 'No' AND ty.Module = 'simp' Group by ioc.db_value ),0)  as db_IR_Hits,
	IFNULL((select count(ioc.db_ID) FROM incident_ioc ioc,incidents i,`types` ty,users u,user_profiles up where ty.id = i.db_TypeID AND ioc.db_ERID = i.db_ID AND i.db_ManagerID = u.db_id AND u.db_UserProfileID = up.id AND up.name = p_profile AND u.db_group = p_group AND ioc.db_name = t.db_name AND  db_value = t.db_value AND ioc.db_Del = 'No' AND i.db_Deleted = 'No' AND ty.Module = 'stmp' Group by ioc.db_value),0)  as db_Threat_Hits,
	IFNULL((select count(ioc.db_ID) FROM incident_ioc ioc,incidents i,`types` ty,users u,user_profiles up where ty.id = i.db_TypeID AND ioc.db_ERID = i.db_ID AND i.db_ManagerID = u.db_id AND u.db_UserProfileID = up.id AND up.name = p_profile AND u.db_group = p_group AND ioc.db_name = t.db_name AND  db_value = t.db_value AND ioc.db_Del = 'No' AND i.db_Deleted = 'No' AND ty.Module = 'scmp' Group by ioc.db_value ),0)  as db_Case_Hits,
     IFNULL((select group_concat(concat(db_id,'$',db_name,'$',db_Category) SEPARATOR '|') from tags where tags.db_Group = 'IOC' and tags.db_GroupID = t.db_ID and tags.db_Del = 'No'),'')  as db_IOC_Tags


FROM incident_ioc t
 
WHERE t.db_ERID = p_ID 
	AND t.db_Del = 'No'
    AND t.db_Mode = 'Asset'
    
    

ORDER BY t.db_ID DESC    
    ;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `community_getERsMostRecent`(

IN p_module VARCHAR(100) 

)
BEGIN

SELECT i.*,t1.db_FullName as db_Manager,
		t2.db_FullName as db_Initiator,
        `types`.name as db_Type, 
        `types`.DisplayName_2 as db_Type_2, 
        categories.name as db_Category,
        subcategories.name as db_SubCategory, 
        DATE_FORMAT(i.db_StartDateTime,'%d-%m-%Y %h:%i %p') as 'db_StartDateTimeFormatted',
        DATE_FORMAT(i.db_Containment_Date,'%d-%m-%Y %h:%i %p') as 'db_ContainmentDateFormatted',
        DATE_FORMAT(i.db_Date_of_Closure,'%d-%m-%Y %h:%i %p') as 'db_DateOfClosureFormatted',
        '' as db_tags,
        concat('Q',QUARTER(i.db_startdatetime)) as db_Quarter,
		MONTHNAME(STR_TO_DATE(Month(i.db_startdatetime), '%m')) as db_Month,
		s.db_title as db_sla_name,
		(SELECT count(db_id) from custom_attributes WHERE db_del = 'No' AND db_public = 'Yes' AND db_type = 'File' AND db_ERID = i.db_id) as ca_count,
        (SELECT count(db_id) from incident_ioc WHERE db_del = 'No' AND db_public = 'Yes'  AND db_Mode = 'IOC' AND db_ERID = i.db_id) as iocs_count,
        (SELECT count(db_id) from incident_ioc WHERE db_del = 'No' AND db_public = 'Yes'  AND db_Mode = 'Asset' AND db_ERID = i.db_id) as assets_count,
        (SELECT count(db_id) from tags WHERE db_del = 'No' AND db_private_tag = 'No' AND db_GroupID = i.db_id) as tags_count,
		(SELECT count(db_erid) from community_article_views WHERE db_erid = i.db_id) as view_count 
		 
        
        
FROM incidents i
LEFT JOIN `types` on i.db_typeID = `types`.id  
		LEFT JOIN  categories on i.db_CategoryID = categories.id
        LEFT JOIN subcategories on i.db_SubCategoryID = subcategories.id
        LEFT JOIN users t1 on i.db_ManagerID = t1.db_id
        LEFT JOIN users t2 on i.db_InitiatorID = t2.db_id
        LEFT JOIN sla s on s.db_id = i.db_SLA_ID 
         
Where	
		i.db_id IN  (SELECT db_id from (select i.db_id from incidents i, `types` t where i.db_typeID = t.id and t.Module = p_module and i.db_Deleted = 'No' order by i.db_Escalation_Date DESC, i.db_StartDateTime DESC limit 500) as t) 
        AND  i.db_Deleted = 'No'
        AND  i.db_Share_Status = 'Published'
        
        
GROUP BY i.db_id        
ORDER By i.db_Escalation_Date DESC, i.db_StartDateTime DESC
limit 500;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `community_getERsMostRecent_member`(

IN p_module VARCHAR(100),
IN p_member_id INT(11)

)
BEGIN

SELECT i.*,t1.db_FullName as db_Manager,
		t2.db_FullName as db_Initiator,
        `types`.name as db_Type, 
        `types`.DisplayName_2 as db_Type_2, 
        categories.name as db_Category,
        subcategories.name as db_SubCategory, 
        DATE_FORMAT(i.db_StartDateTime,'%d-%m-%Y %h:%i %p') as 'db_StartDateTimeFormatted',
        DATE_FORMAT(i.db_Containment_Date,'%d-%m-%Y %h:%i %p') as 'db_ContainmentDateFormatted',
        DATE_FORMAT(i.db_Date_of_Closure,'%d-%m-%Y %h:%i %p') as 'db_DateOfClosureFormatted',
        '' as db_tags,
        concat('Q',QUARTER(i.db_startdatetime)) as db_Quarter,
		MONTHNAME(STR_TO_DATE(Month(i.db_startdatetime), '%m')) as db_Month,
		s.db_title as db_sla_name,
		(SELECT count(db_id) from custom_attributes WHERE db_del = 'No' AND db_public = 'Yes' AND db_type = 'File' AND db_ERID = i.db_id) as ca_count,
        (SELECT count(db_id) from incident_ioc WHERE db_del = 'No' AND db_public = 'Yes'  AND db_Mode = 'IOC' AND db_ERID = i.db_id) as iocs_count,
        (SELECT count(db_id) from incident_ioc WHERE db_del = 'No' AND db_public = 'Yes'  AND db_Mode = 'Asset' AND db_ERID = i.db_id) as assets_count,
        (SELECT count(db_id) from tags WHERE db_del = 'No' AND db_private_tag = 'No' AND db_GroupID = i.db_id) as tags_count,
		(SELECT count(db_erid) from community_article_views WHERE db_erid = i.db_id) as view_count 
		 
        
        
FROM `share` sh, incidents i
LEFT JOIN `types` on i.db_typeID = `types`.id  
		LEFT JOIN  categories on i.db_CategoryID = categories.id
        LEFT JOIN subcategories on i.db_SubCategoryID = subcategories.id
        LEFT JOIN users t1 on i.db_ManagerID = t1.db_id
        LEFT JOIN users t2 on i.db_InitiatorID = t2.db_id
        LEFT JOIN sla s on s.db_id = i.db_SLA_ID 
         
Where	
		i.db_id IN  (SELECT db_id from (select i.db_id from incidents i, `types` t where i.db_typeID = t.id and t.Module = p_module and i.db_Deleted = 'No' order by i.db_Escalation_Date DESC, i.db_StartDateTime DESC limit 500) as t) 
        AND  i.db_Deleted = 'No'
        AND  i.db_Share_Status = 'Published'
        AND i.db_id = sh.db_erid
        AND sh.db_shared_with_id = p_member_id
        AND sh.db_del = 'No'
        
        
GROUP BY i.db_id        
ORDER By i.db_Escalation_Date DESC, i.db_StartDateTime DESC
limit 500;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `community_get_submitted_forms`()
BEGIN

SELECT u.db_FullName as db_username, i.db_id,i.db_Reference,db_submission_form_title ,db_submission_form_type, DATE_FORMAT(i.db_StartDateTime,'%d-%m-%Y %h:%i %p') as 'db_StartDateTimeFormatted'
FROM incidents i, users u, user_profiles up
WHERE i.db_InitiatorID = u.db_id
AND u.db_UserProfileID = up.id
AND i.db_deleted = 'No'
AND up.name = 'Community Member'
ORDER BY i.db_id desc
;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `community_get_submitted_forms_by_user`(
IN p_user_id INT(11)
)
BEGIN

SELECT u.db_FullName as db_username,i.db_id,i.db_Reference,db_submission_form_title ,db_submission_form_type, DATE_FORMAT(i.db_StartDateTime,'%d-%m-%Y %h:%i %p') as 'db_StartDateTimeFormatted'
FROM incidents i, users u
WHERE i.db_InitiatorID = u.db_id
AND i.db_deleted = 'No'
AND i.db_InitiatorID = p_user_id
ORDER BY i.db_id desc
;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `CustomAttributes_GetAllByERID`(
IN p_id INT(11),
IN p_typeGroup varchar(50)
)
BEGIN

SELECT *
FROM custom_attributes 
WHERE db_ERID = p_ID 
	AND db_Del = 'No'
    AND db_Parent = p_typeGroup
ORDER BY db_order, db_ID DESC
;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `deleteER`(
IN p_erID INT (11)
)
BEGIN

UPDATE incidents SET db_Deleted = 'Yes' WHERE db_ID = p_erID ;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `discussion_get_by_object_id`(
IN p_obj_id int(11) ,
IN p_obj VARCHAR(100) 
)
BEGIN
SELECT 	
		d.*, 
		u.db_fullname,
        DATE_FORMAT(d.db_entry_date,'%d-%m-%Y %h:%i %p') as 'db_entry_date',
        d.db_post,
        u.db_Pic
FROM discussion d, users u
WHERE d.db_del = 'No'
AND d.db_user_id = u.db_id
AND d.db_object = p_obj
AND d.db_object_id = p_obj_id
order by d.db_id 
;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `er_FireEyeByAlertType`(
IN p_type varchar(500),
IN p_module varchar(500),
IN p_backTime_from VARCHAR(100),
IN p_backTime_to VARCHAR(100)

)
BEGIN
	SELECT 	t.db_name, 
			COUNT(t.db_name) as 'db_count', 
			FLOOR(IF(COUNT(1)=0,0,COUNT(1) / icount.cnt * 100))  AS 'db_percent',
			icount.cnt  AS 'db_total_count' 
	FROM tags t, incidents i, types tp
    CROSS JOIN (SELECT IF(COUNT(DISTINCT db_GroupID)=0,0,COUNT(DISTINCT db_GroupID)) as cnt from tags t,incidents i, types tp WHERE t.db_GroupID = i.db_id AND tp.id = i.db_typeID  AND IF(p_type = 'ER', tp.`group`, tp.`name`) = p_type AND tp.module = p_module AND i.db_FalsePositive_Flag = 'No' AND i.db_StartDateTime BETWEEN p_backTime_from AND p_backTime_to AND t.db_name = 'FireEye Email' AND t.db_Category = 'Security Control' AND db_Del = 'No') icount
	WHERE t.db_GroupID = i.db_id
    AND tp.id = i.db_typeID
    AND IF(p_type = 'ER', tp.`group`, tp.`name`) = p_type
    AND tp.module = p_module
	AND i.db_Deleted = 'No'
	AND t.db_Del = 'No'
	AND i.db_FalsePositive_Flag = 'No' 
    AND i.db_StartDateTime BETWEEN p_backTime_from AND p_backTime_to
	AND t.db_GroupID IN (SELECT DISTINCT db_GroupID from tags t1 WHERE  t1.db_name = 'FireEye Email' AND t1.db_Category = 'Security Control' AND db_Del = 'No')
	AND t.db_name  IN ('Bad Attachment' , 'Bad URL' , 'Bad Header')
	GROUP BY t.db_name 
    ORDER BY COUNT(t.db_name) DESC 
	LIMIT 10
    ;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `er_FireEyeByAttachmentExtension`()
BEGIN
	SELECT 	t.db_name, 
			COUNT(t.db_name) as 'db_count', 
			FLOOR(IF(COUNT(1)=0,0,COUNT(1) / icount.cnt * 100))  AS 'db_percent'  
	FROM tags t, incidents i
    CROSS JOIN (SELECT IF(COUNT(1)=0,0,COUNT(1)) AS cnt FROM incidents WHERE db_deleted = 'No') icount
	WHERE t.db_GroupID = i.db_id
	AND i.db_Deleted = 'No'
	AND t.db_Del = 'No'
	AND i.db_FalsePositive_Flag = 'No'
	AND t.db_GroupID IN (select distinct db_GroupID from tags t1 WHERE lower(t1.db_name) = 'fireeye email' AND lower(t1.db_Category) = 'security control') 
	AND (lower(t.db_Category) = 'file extension')
	GROUP BY t.db_name 
	ORDER BY COUNT(t.db_name) DESC 
	LIMIT 10
    ;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `er_FireEyeByCountry`()
BEGIN
	SELECT 	ioc.db_Geo as 'db_name', 
			COUNT(ioc.db_value) as 'db_count', 
			FLOOR(IF(COUNT(1)=0,0,COUNT(1) / icount.cnt * 100))  AS 'db_percent'  
	FROM incidents i, incident_ioc ioc
    CROSS JOIN (SELECT IF(COUNT(1)=0,0,COUNT(1)) AS cnt FROM incidents WHERE db_deleted = 'No') icount
	WHERE ioc.db_ERID = i.db_id
	AND i.db_Deleted = 'No'
	AND ioc.db_Del = 'No'
    AND i.db_FalsePositive_Flag = 'No'
	AND ioc.db_ERID IN (select distinct db_GroupID from tags t1 WHERE lower(t1.db_name) = 'fireeye email' AND lower(t1.db_Category) = 'security control') 
    AND ioc.db_Geo <> 'N/A'
	GROUP BY ioc.db_Geo 
	ORDER BY COUNT(ioc.db_Geo) DESC 
	LIMIT 10
    ;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `er_FireEyeByDomain`()
BEGIN
	SELECT 	ioc.db_value as 'db_name', 
			COUNT(ioc.db_value) as 'db_count', 
			FLOOR(IF(COUNT(1)=0,0,COUNT(1) / icount.cnt * 100))  AS 'db_percent'  
	FROM incidents i, incident_ioc ioc
    CROSS JOIN (SELECT IF(COUNT(1)=0,0,COUNT(1)) AS cnt FROM incidents WHERE db_deleted = 'No') icount
	WHERE ioc.db_ERID = i.db_id
	AND i.db_Deleted = 'No'
	AND ioc.db_Del = 'No'
    AND i.db_FalsePositive_Flag = 'No'
	AND ioc.db_ERID IN (select distinct db_GroupID from tags t1 WHERE lower(t1.db_name) = 'fireeye email' AND lower(t1.db_Category) = 'security control') 
	AND ioc.db_Name = 'Domain'
    AND ioc.db_Mode = 'IOC'
	GROUP BY ioc.db_Value 
	ORDER BY COUNT(ioc.db_Value) DESC 
	LIMIT 10
    ;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `er_FireEyeByHash`()
BEGIN
    SELECT 	ioc.db_value as 'db_name', 
			COUNT(ioc.db_value) as 'db_count', 
			FLOOR(IF(COUNT(1)=0,0,COUNT(1) / icount.cnt * 100))  AS 'db_percent'  
	FROM incidents i, incident_ioc ioc
    CROSS JOIN (SELECT IF(COUNT(1)=0,0,COUNT(1)) AS cnt FROM incidents WHERE db_deleted = 'No') icount
	WHERE ioc.db_ERID = i.db_id
	AND i.db_Deleted = 'No'
	AND ioc.db_Del = 'No'
    AND i.db_FalsePositive_Flag = 'No'
	AND ioc.db_ERID IN (select distinct db_GroupID from tags t1 WHERE lower(t1.db_name) = 'fireeye email' AND lower(t1.db_Category) = 'security control') 
	AND ioc.db_Name like 'Hash %'
    AND ioc.db_Mode = 'IOC'
	GROUP BY ioc.db_Value 
	ORDER BY COUNT(ioc.db_Value) DESC 
	LIMIT 10
    ;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `er_FireEyeByIP`()
BEGIN
	SELECT 	ioc.db_value as 'db_name', 
			COUNT(ioc.db_value) as 'db_count', 
			FLOOR(IF(COUNT(1)=0,0,COUNT(1) / icount.cnt * 100))  AS 'db_percent'  
	FROM incidents i, incident_ioc ioc
    CROSS JOIN (SELECT IF(COUNT(1)=0,0,COUNT(1)) AS cnt FROM incidents WHERE db_deleted = 'No') icount
	WHERE ioc.db_ERID = i.db_id
	AND i.db_Deleted = 'No'
	AND ioc.db_Del = 'No'
    AND i.db_FalsePositive_Flag = 'No'
	AND ioc.db_ERID IN (select distinct db_GroupID from tags t1 WHERE lower(t1.db_name) = 'fireeye email' AND lower(t1.db_Category) = 'security control') 
	AND ioc.db_Name = 'IP'
    AND ioc.db_Mode = 'IOC'
	GROUP BY ioc.db_Value 
	ORDER BY COUNT(ioc.db_Value) DESC 
	LIMIT 10
    ;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `er_FireEyeByMalwareName`()
BEGIN
	SELECT 	t.db_name, 
			COUNT(t.db_name) as 'db_count', 
			FLOOR(IF(COUNT(1)=0,0,COUNT(1) / icount.cnt * 100))  AS 'db_percent'  
	FROM tags t, incidents i
    CROSS JOIN (SELECT IF(COUNT(1)=0,0,COUNT(1)) AS cnt FROM incidents WHERE db_deleted = 'No') icount
	WHERE t.db_GroupID = i.db_id
	AND t.db_GroupID = i.db_id
	AND i.db_Deleted = 'No'
	AND t.db_Del = 'No'
	AND i.db_FalsePositive_Flag = 'No'
	AND t.db_GroupID IN (select distinct db_GroupID from tags t1 WHERE lower(t1.db_name) = 'fireeye email' AND lower(t1.db_Category) = 'security control') 
	AND (lower(t.db_Category) = 'malware name')
	GROUP BY t.db_name 
	ORDER BY COUNT(t.db_name) DESC 
	LIMIT 10
    ;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `er_FireEyeByTarget`()
BEGIN
	SELECT 	ioc.db_value as 'db_name', 
			COUNT(ioc.db_value) as 'db_count', 
			FLOOR(IF(COUNT(1)=0,0,COUNT(1) / icount.cnt * 100))  AS 'db_percent'  
	FROM incidents i, incident_ioc ioc
    CROSS JOIN (SELECT IF(COUNT(1)=0,0,COUNT(1)) AS cnt FROM incidents WHERE db_deleted = 'No') icount
	WHERE ioc.db_ERID = i.db_id
	AND i.db_Deleted = 'No'
	AND ioc.db_Del = 'No'
    AND i.db_FalsePositive_Flag = 'No'
	AND ioc.db_ERID IN (select distinct db_GroupID from tags t1 WHERE lower(t1.db_name) = 'fireeye email' AND lower(t1.db_Category) = 'security control') 
	AND ioc.db_Name = 'Email Receipient ID'
    AND ioc.db_Mode = 'Asset'
	GROUP BY ioc.db_Value 
	ORDER BY COUNT(ioc.db_Value) DESC 
	LIMIT 10
    ;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `er_FireEyeByThreatActor`()
BEGIN
	SELECT 	t.db_name, 
			COUNT(t.db_name) as 'db_count', 
			FLOOR(IF(COUNT(1)=0,0,COUNT(1) / icount.cnt * 100))  AS 'db_percent'  
	FROM tags t, incidents i
    CROSS JOIN (SELECT IF(COUNT(1)=0,0,COUNT(1)) AS cnt FROM incidents WHERE db_deleted = 'No') icount
	WHERE t.db_GroupID = i.db_id
	AND t.db_GroupID = i.db_id
	AND i.db_Deleted = 'No'
	AND t.db_Del = 'No'
	AND i.db_FalsePositive_Flag = 'No'
	AND t.db_GroupID IN (select distinct db_GroupID from tags t1 WHERE lower(t1.db_name) = 'fireeye email' AND lower(t1.db_Category) = 'security control') 
	AND (lower(t.db_Category) = 'threat actor')
	GROUP BY t.db_name 
	ORDER BY COUNT(t.db_id) DESC 
	LIMIT 10
    ;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `er_getActivityReminders`()
BEGIN
select * from incidents 
where db_ReminderEnabled = 'Yes'
and db_ReminderNotificationSent = 'No'
and db_ReminderDate < now()
and db_Deleted = 'No'
;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `er_getAllByStatusByTime`(
IN p_typeGroup VARCHAR(100),
IN p_module VARCHAR(100),
IN p_backTime_from VARCHAR(100),
IN p_backTime_to VARCHAR(100)
)
BEGIN
SELECT s.db_name as db_status, ifnull(i.db_count,0) as 'db_Count' 
from `status_er` s

left outer join (
				SELECT i.db_status,IFNULL(count(*),0) as db_count
				FROM incidents i, `types` t
                where  i.db_TypeID = t.ID
				AND (i.db_deleted = 'No')
				AND ((i.db_StartDateTime BETWEEN p_backTime_from AND p_backTime_to) OR (i.db_Escalation_Date BETWEEN p_backTime_from AND p_backTime_to))
				AND t.Module = p_module
				AND t.`name`=p_typeGroup
                group by i.db_status
    ) as i on s.db_name = i.db_status
    
group by s.db_name
order by s.db_ID

;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `er_getAllByStatusByTime_ByProfile_ByGroup`(
IN p_typeGroup VARCHAR(100),
IN p_profile VARCHAR(500),
IN p_group VARCHAR(500),
IN p_module VARCHAR(100),
IN p_backTime_from VARCHAR(100),
IN p_backTime_to VARCHAR(100)
)
BEGIN
SELECT s.db_name as db_status, ifnull(i.db_count,0) as 'db_Count' 
from `status_er` s

left outer join (
				SELECT i.db_status,IFNULL(count(*),0) as db_count
				FROM incidents i, `types` t, users u, user_profiles up
                where  i.db_TypeID = t.ID
				AND (i.db_deleted = 'No')
				AND ((i.db_StartDateTime BETWEEN p_backTime_from AND p_backTime_to) OR (i.db_Escalation_Date BETWEEN p_backTime_from AND p_backTime_to))
				AND t.Module = p_module
				AND t.`name`=p_typeGroup
                AND i.db_ManagerID = u.db_id 
				AND u.db_UserProfileID = up.id
				AND up.name = p_profile
				AND u.db_group = p_group
                group by i.db_status
    ) as i on s.db_name = i.db_status
    
group by s.db_name
order by s.db_ID

;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `er_getAllERsByType_AllYears`(
IN p_status VARCHAR(50),
IN p_managerID VARCHAR(50),
IN p_type VARCHAR(100)
)
BEGIN

	SELECT i.*,t1.db_FullName as db_Manager,
		t2.db_FullName as db_Initiator,
        `types`.name as db_Type, 
        `types`.DisplayName_2 as db_Type_2, 
        categories.name as db_Category,
        subcategories.name as db_SubCategory, 
        DATE_FORMAT(i.db_StartDateTime,'%d-%m-%Y %h:%i %p') as 'db_StartDateTimeFormatted',
        DATE_FORMAT(i.db_Containment_Date,'%d-%m-%Y %h:%i %p') as 'db_ContainmentDateFormatted',
        DATE_FORMAT(i.db_Date_of_Closure,'%d-%m-%Y %h:%i %p') as 'db_DateOfClosureFormatted',
        '' as db_tags,
        concat('Q',QUARTER(i.db_startdatetime)) as db_Quarter,
		MONTHNAME(STR_TO_DATE(Month(i.db_startdatetime), '%m')) as db_Month,
		s.db_title as db_sla_name 
        
FROM incidents i
LEFT JOIN `types` on i.db_typeID = `types`.id 
		LEFT JOIN  categories on i.db_CategoryID = categories.id
        LEFT JOIN subcategories on i.db_SubCategoryID = subcategories.id
        LEFT JOIN users t1 on i.db_ManagerID = t1.db_id
        LEFT JOIN users t2 on i.db_InitiatorID = t2.db_id
        LEFT JOIN sla s on s.db_id = i.db_SLA_ID
        

Where	
		(i.db_deleted = 'No') 
		AND (`types`.`name` = p_type)
        AND i.db_Status like p_status
        AND i.db_ManagerID like p_managerID
        
        
GROUP BY i.db_id        
ORDER By	i.db_Escalation_Date DESC, i.db_StartDateTime DESC
limit 500;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `er_getAllERsByTypeGroupByTime`(

IN p_status VARCHAR(50),
IN p_managerID VARCHAR(50),
IN p_typeGroup VARCHAR(100),
IN p_module VARCHAR(100),
IN p_backTime_from VARCHAR(100),
IN p_backTime_to VARCHAR(100),
IN p_limit int(11)

)
BEGIN

SELECT i.*,t1.db_FullName as db_Manager,
		t2.db_FullName as db_Initiator,
        `types`.name as db_Type, 
        `types`.DisplayName_2 as db_Type_2, 
        categories.name as db_Category,
        subcategories.name as db_SubCategory, 
        DATE_FORMAT(i.db_StartDateTime,'%d-%m-%Y %h:%i %p') as 'db_StartDateTimeFormatted',
        DATE_FORMAT(i.db_Containment_Date,'%d-%m-%Y %h:%i %p') as 'db_ContainmentDateFormatted',
        DATE_FORMAT(i.db_Date_of_Closure,'%d-%m-%Y %h:%i %p') as 'db_DateOfClosureFormatted',
        '' as db_tags,
        concat('Q',QUARTER(i.db_startdatetime)) as db_Quarter,
		MONTHNAME(STR_TO_DATE(Month(i.db_startdatetime), '%m')) as db_Month,
		s.db_title as db_sla_name
        
FROM incidents i
LEFT JOIN `types` on i.db_typeID = `types`.id 
		LEFT JOIN  categories on i.db_CategoryID = categories.id
        LEFT JOIN subcategories on i.db_SubCategoryID = subcategories.id
        LEFT JOIN users t1 on i.db_ManagerID = t1.db_id
        LEFT JOIN users t2 on i.db_InitiatorID = t2.db_id
        LEFT JOIN sla s on s.db_id = i.db_SLA_ID
       

Where	
		(i.db_deleted = 'No') 
		AND (`types`.`Group` = p_typeGroup)
        AND (lower(`types`.`Module`) = lower(p_module))
        AND i.db_Status like p_status
        AND i.db_ManagerID like p_managerID
        AND ((i.db_StartDateTime BETWEEN p_backTime_from AND p_backTime_to) OR (i.db_Escalation_Date BETWEEN p_backTime_from AND p_backTime_to))
		
        
GROUP BY i.db_id        
ORDER By	i.db_Escalation_Date DESC, i.db_StartDateTime DESC
limit p_limit;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `er_getAllERsByTypeGroupByTime_ByProfile_ByGroup`(

IN p_status VARCHAR(50),
IN p_managerID VARCHAR(50),
IN p_typeGroup VARCHAR(100),
IN p_profile VARCHAR(500),
IN p_group VARCHAR(500),
IN p_module VARCHAR(100),
IN p_backTime_from VARCHAR(100),
IN p_backTime_to VARCHAR(100),
IN p_limit int(11)

)
BEGIN

SELECT i.*,t1.db_FullName as db_Manager,
		t2.db_FullName as db_Initiator,
        `types`.name as db_Type, 
        `types`.DisplayName_2 as db_Type_2, 
        categories.name as db_Category,
        subcategories.name as db_SubCategory, 
        DATE_FORMAT(i.db_StartDateTime,'%d-%m-%Y %h:%i %p') as 'db_StartDateTimeFormatted',
        DATE_FORMAT(i.db_Containment_Date,'%d-%m-%Y %h:%i %p') as 'db_ContainmentDateFormatted',
        DATE_FORMAT(i.db_Date_of_Closure,'%d-%m-%Y %h:%i %p') as 'db_DateOfClosureFormatted',
        '' as db_tags,
        concat('Q',QUARTER(i.db_startdatetime)) as db_Quarter,
		MONTHNAME(STR_TO_DATE(Month(i.db_startdatetime), '%m')) as db_Month,
		s.db_title as db_sla_name 
        
FROM incidents i
LEFT JOIN `types` on i.db_typeID = `types`.id 
		LEFT JOIN  categories on i.db_CategoryID = categories.id
        LEFT JOIN subcategories on i.db_SubCategoryID = subcategories.id
        LEFT JOIN users t1 on i.db_ManagerID = t1.db_id
        LEFT JOIN users t2 on i.db_InitiatorID = t2.db_id
        left join users u on  i.db_ManagerID = u.db_id 
		left join user_profiles up on u.db_UserProfileID = up.id
        LEFT JOIN sla s on s.db_id = i.db_SLA_ID

Where	
		(i.db_deleted = 'No') 
		AND (`types`.`Group` = p_typeGroup)
        AND i.db_Status like p_status
        AND (lower(`types`.`Module`) = lower(p_module))
        AND i.db_ManagerID like p_managerID
        AND ((i.db_StartDateTime BETWEEN p_backTime_from AND p_backTime_to) OR (i.db_Escalation_Date BETWEEN p_backTime_from AND p_backTime_to))
        AND up.name = p_profile
		AND u.db_group = p_group
        
        
GROUP BY i.db_id        
ORDER By	i.db_Escalation_Date DESC, i.db_StartDateTime DESC
limit p_limit;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `er_getAllERsByTypeNameByTime`(
IN p_status VARCHAR(50),
IN p_managerID VARCHAR(50),
IN p_type VARCHAR(100),
IN p_module VARCHAR(100),
IN p_backTime_from VARCHAR(100),
IN p_backTime_to VARCHAR(100),
IN p_limit int(11)
)
BEGIN

	SELECT i.*,t1.db_FullName as db_Manager,
		t2.db_FullName as db_Initiator,
        `types`.name as db_Type, 
        `types`.DisplayName_2 as db_Type_2, 
        categories.name as db_Category,
        subcategories.name as db_SubCategory, 
        DATE_FORMAT(i.db_StartDateTime,'%d-%m-%Y %h:%i %p') as 'db_StartDateTimeFormatted',
        DATE_FORMAT(i.db_Containment_Date,'%d-%m-%Y %h:%i %p') as 'db_ContainmentDateFormatted',
        DATE_FORMAT(i.db_Date_of_Closure,'%d-%m-%Y %h:%i %p') as 'db_DateOfClosureFormatted',
        '' as db_tags,
        concat('Q',QUARTER(i.db_startdatetime)) as db_Quarter,
		MONTHNAME(STR_TO_DATE(Month(i.db_startdatetime), '%m')) as db_Month,
		s.db_title as db_sla_name
        
FROM incidents i
LEFT JOIN `types` on i.db_typeID = `types`.id 
		LEFT JOIN  categories on i.db_CategoryID = categories.id
        LEFT JOIN subcategories on i.db_SubCategoryID = subcategories.id
        LEFT JOIN users t1 on i.db_ManagerID = t1.db_id
        LEFT JOIN users t2 on i.db_InitiatorID = t2.db_id
        LEFT JOIN sla s on s.db_id = i.db_SLA_ID
        

Where	
		(i.db_deleted = 'No') 
		AND (`types`.`name` = p_type)
        AND (lower(`types`.`Module`) = lower(p_module))
        AND i.db_Status like p_status
        AND i.db_ManagerID like p_managerID
        AND ((i.db_StartDateTime BETWEEN p_backTime_from AND p_backTime_to) OR (i.db_Escalation_Date BETWEEN p_backTime_from AND p_backTime_to))
        
        
GROUP BY i.db_id        
ORDER By i.db_Escalation_Date DESC, i.db_StartDateTime DESC
limit p_limit;


END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `er_getAllERsByTypeNameByTime_ByProfile_ByGroup`(

IN p_status VARCHAR(50),
IN p_managerID VARCHAR(50),
IN p_typeName VARCHAR(100),
IN p_profile VARCHAR(500),
IN p_group VARCHAR(500),
IN p_module VARCHAR(100),
IN p_backTime_from VARCHAR(100),
IN p_backTime_to VARCHAR(100),
IN p_limit int(11)

)
BEGIN

SELECT i.*,t1.db_FullName as db_Manager,
		t2.db_FullName as db_Initiator,
        `types`.name as db_Type, 
        `types`.DisplayName_2 as db_Type_2, 
        categories.name as db_Category,
        subcategories.name as db_SubCategory, 
        DATE_FORMAT(i.db_StartDateTime,'%d-%m-%Y %h:%i %p') as 'db_StartDateTimeFormatted',
        DATE_FORMAT(i.db_Containment_Date,'%d-%m-%Y %h:%i %p') as 'db_ContainmentDateFormatted',
        DATE_FORMAT(i.db_Date_of_Closure,'%d-%m-%Y %h:%i %p') as 'db_DateOfClosureFormatted',
        '' as db_tags,
        concat('Q',QUARTER(i.db_startdatetime)) as db_Quarter,
		MONTHNAME(STR_TO_DATE(Month(i.db_startdatetime), '%m')) as db_Month,
		s.db_title as db_sla_name 
        
FROM incidents i
LEFT JOIN `types` on i.db_typeID = `types`.id 
		LEFT JOIN  categories on i.db_CategoryID = categories.id
        LEFT JOIN subcategories on i.db_SubCategoryID = subcategories.id
        LEFT JOIN users t1 on i.db_ManagerID = t1.db_id
        LEFT JOIN users t2 on i.db_InitiatorID = t2.db_id
        left join users u on  i.db_ManagerID = u.db_id 
		left join user_profiles up on u.db_UserProfileID = up.id
        LEFT JOIN sla s on s.db_id = i.db_SLA_ID

Where	
		(i.db_deleted = 'No') 
		AND (`types`.`name` = p_typeName)
        AND i.db_Status like p_status
        AND (lower(`types`.`Module`) = lower(p_module))
        AND i.db_ManagerID like p_managerID
        AND ((i.db_StartDateTime BETWEEN p_backTime_from AND p_backTime_to) OR (i.db_Escalation_Date BETWEEN p_backTime_from AND p_backTime_to))
        AND up.name = p_profile
		AND u.db_group = p_group
        
        
GROUP BY i.db_id        
ORDER By	i.db_Escalation_Date DESC, i.db_StartDateTime DESC
limit p_limit;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `er_getAllEsclatedIncidents`(
 

IN p_type VARCHAR(100),
IN p_module VARCHAR(100),
IN p_backTime_from VARCHAR(100),
IN p_backTime_to VARCHAR(100),
IN p_escalated_module VARCHAR(100)

)
BEGIN

	SELECT i.*,t1.db_FullName as db_Manager,
		t2.db_FullName as db_Initiator,
        `types`.name as db_Type, 
         `types`.DisplayName_2 as db_Type_2, 
        categories.name as db_Category,
        subcategories.name as db_SubCategory, 
        DATE_FORMAT(i.db_StartDateTime,'%d-%m-%Y %h:%i %p') as 'db_StartDateTimeFormatted',
        DATE_FORMAT(i.db_Containment_Date,'%d-%m-%Y %h:%i %p') as 'db_ContainmentDateFormatted',
        DATE_FORMAT(i.db_Date_of_Closure,'%d-%m-%Y %h:%i %p') as 'db_DateOfClosureFormatted',
        '' as db_tags,
        concat('Q',QUARTER(i.db_startdatetime)) as db_Quarter,
		MONTHNAME(STR_TO_DATE(Month(i.db_startdatetime), '%m')) as db_Month,
		s.db_title as db_sla_name 
        
FROM incidents i
LEFT JOIN `types` on i.db_typeID = `types`.id 
		LEFT JOIN  categories on i.db_CategoryID = categories.id
        LEFT JOIN subcategories on i.db_SubCategoryID = subcategories.id
        LEFT JOIN users t1 on i.db_ManagerID = t1.db_id
        LEFT JOIN users t2 on i.db_InitiatorID = t2.db_id
        LEFT JOIN sla s on s.db_id = i.db_SLA_ID 

Where	
		(i.db_deleted = 'No') 
		AND (`types`.`name` = p_type)
        AND (lower(`types`.`Module`) = lower(p_module))
		AND ((i.db_StartDateTime BETWEEN p_backTime_from AND p_backTime_to) OR (i.db_Escalation_Date BETWEEN p_backTime_from AND p_backTime_to))
        AND (i.db_EsclatedIncident_Flag = 'Yes')
	    AND (i.db_Escalated_Module = p_escalated_module)
        
        
GROUP BY i.db_id        
ORDER By i.db_Escalation_Date DESC, i.db_StartDateTime DESC
limit 500;


END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `er_get_community_groups`(
IN p_erid INT(11)
)
BEGIN

select i.db_id, c.db_id as db_community_group_id , c.db_Name as db_community_group
from incidents i, community_groups c, incident_community_groups ic 
where i.db_id = ic.db_erid
AND c.db_id = ic.db_community_group_id
AND i.db_id = p_erid
;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `er_get_community_shares`(
IN p_erid INT(11)
)
BEGIN

SELECT s.*,
u1.db_FullName AS db_shared_with, 
u1.db_Email AS db_shared_with_email, 
u2.db_FullName AS db_shared_by, 
DATE_FORMAT(s.db_EntryDate,'%d-%m-%Y %h:%i %p') as 'db_Share_Date',
(SELECT COUNT(*) FROM community_article_views WHERE db_user_id = u1.db_id) as db_view_count

FROM `share` s, 
users u1,
users u2,
incidents i

WHERE s.db_erid = i.db_id
AND s.db_shared_with_id = u1.db_id
AND s.db_shared_by_id = u2.db_id
AND i.db_id = p_erid
AND s.db_del = 'No'
;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `er_getCountByAdversaryOverall`()
BEGIN
	SELECT t.db_Name , count(t.db_id) AS 'db_count'  
	FROM tags t, incidents i
    WHERE t.db_GroupID = i.db_ID
    AND lower(t.db_Category) LIKE '%adversary%' 	
			AND (t.db_del = 'No') 
            AND (i.db_deleted = 'No') 
			 
    GROUP BY lower(trim(t.db_Name))
    ORDER BY count(t.db_id) DESC
    LIMIT 10
    ;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `er_getCountByCategory`(
IN p_type varchar(100),
IN p_module VARCHAR(100),
IN p_backTime_from VARCHAR(100),
IN p_backTime_to VARCHAR(100),
IN p_false_positive VARCHAR(3)
)
BEGIN
SELECT c.name as db_Category,IFNULL(i.db_count,0) as 'db_count', IFNULL(i.db_percent,0) as 'db_percent', i.db_total
	FROM categories c
	join (
				SELECT ii.db_CategoryID,IFNULL(count(*),0) as db_count, IF(IF(COUNT(1)=0,0,COUNT(1) / t1.cnt * 100)>=1,ROUND(IF(COUNT(1)=0,0,COUNT(1) / t1.cnt * 100),0),ROUND(IF(COUNT(1)=0,0,COUNT(1) / t1.cnt * 100),1)) AS 'db_percent', t1.cnt as 'db_total'
				FROM incidents ii, `types` ty
                CROSS JOIN (SELECT IF(COUNT(1)=0,0,COUNT(1)) AS cnt FROM incidents i, `types` t WHERE t.name = p_type AND t.module = p_module   AND i.db_deleted = 'No' and i.db_typeid  = (select id from `types` where name = p_type and Module = p_module)  AND i.db_StartDateTime BETWEEN p_backTime_from AND p_backTime_to ) t1
				Where (ii.db_deleted = 'No')
                AND ty.id = ii.db_typeid
				AND ty.name = p_type 
                AND ty.module = p_module
                AND ii.db_StartDateTime BETWEEN p_backTime_from AND p_backTime_to
                AND (ii.db_FalsePositive_Flag = 'No' OR ii.db_FalsePositive_Flag = p_false_positive)
                group by ii.db_CategoryID      
    ) as i on c.id = i.db_CategoryID
    
	group by 1
    order by db_count DESC
    limit 10
;


END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `er_getCountByCategory_all`(
IN p_backTime_from VARCHAR(100),
IN p_backTime_to VARCHAR(100),
IN p_false_positive VARCHAR(3)
)
BEGIN
SELECT c.name as db_Category,IFNULL(i.db_count,0) as 'db_count', IFNULL(i.db_percent,0) as 'db_percent', i.db_total
	FROM categories c
	join (
				SELECT ii.db_CategoryID,IFNULL(count(*),0) as db_count, IF(IF(COUNT(1)=0,0,COUNT(1) / t1.cnt * 100)>=1,ROUND(IF(COUNT(1)=0,0,COUNT(1) / t1.cnt * 100),0),ROUND(IF(COUNT(1)=0,0,COUNT(1) / t1.cnt * 100),1)) AS 'db_percent', t1.cnt as 'db_total'
				FROM incidents ii, `types` ty
                CROSS JOIN (SELECT IF(COUNT(1)=0,0,COUNT(1)) AS cnt FROM incidents i WHERE i.db_deleted = 'No' and i.db_typeid  IN (select id from `types` where `group` = 'ER')  AND i.db_StartDateTime BETWEEN p_backTime_from AND p_backTime_to ) t1
				Where (ii.db_deleted = 'No')
                AND ty.id = ii.db_typeid
				AND ty.`group` = 'ER' 
                AND ii.db_StartDateTime BETWEEN p_backTime_from AND p_backTime_to
                AND (ii.db_FalsePositive_Flag = 'No' OR ii.db_FalsePositive_Flag = p_false_positive)
                group by ii.db_CategoryID      
    ) as i on c.id = i.db_CategoryID
    
	group by 1
    order by db_count DESC
    limit 10
;


END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `er_getCountByCategoryOverall`(
IN p_group varchar(100),
IN p_module VARCHAR(100),
IN p_backTime_from VARCHAR(100),
IN p_backTime_to VARCHAR(100)

)
BEGIN
SELECT c.name as db_Category, count(i.db_id) as 'db_Count' 
    from incidents i, `types` t, categories c
    WHERE 	i.db_typeID = t.id
			AND i.db_CategoryID = c.id
			AND (i.db_deleted = 'No') 
			AND (t.`Group` = p_group )
            AND (t.`Module` = p_module)
            AND i.db_StartDateTime BETWEEN p_backTime_from AND p_backTime_to
    group by c.name
;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `er_getCountByCategoryOverall_all`(
IN p_backTime_from VARCHAR(100),
IN p_backTime_to VARCHAR(100)

)
BEGIN
SELECT c.name as db_Category, count(i.db_id) as 'db_Count' 
    from incidents i, `types` t, categories c
    WHERE 	i.db_typeID = t.id
			AND i.db_CategoryID = c.id
			AND (i.db_deleted = 'No') 
			AND (t.`Group` = 'ER' )
            AND i.db_StartDateTime BETWEEN p_backTime_from AND p_backTime_to
    group by c.name
    limit 50
;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `er_getCountByCountryOverall`()
BEGIN
	SELECT t.db_Name , count(t.db_id) as 'db_count' 
    FROM tags t, incidents i
    WHERE t.db_GroupID = i.db_ID
    AND lower(t.db_Category) like '%country%' 	
			AND (t.db_del = 'No') 
            AND (i.db_deleted = 'No') 
			 
     group by lower(trim(t.db_name))
    ORDER by count(t.db_id) desc
    ;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `er_getCountByCountryOverall_ByIOCGeo`(
IN p_module VARCHAR(100),
IN p_backTime_from VARCHAR(100),
IN p_backTime_to VARCHAR(100)
)
BEGIN
	SELECT ioc.db_Geo  as 'db_Name', count(ioc.db_id) as 'db_count' 
    FROM incident_ioc ioc, incidents i, `types` t
    WHERE i.db_typeID = t.id
    AND i.db_ID = ioc.db_ERID
    AND t.Module = p_module
	AND ioc.db_Geo <> 'N/A'
    AND (ioc.db_del = 'No') 
    AND (ioc.db_Mode = 'IOC') 
    AND i.db_StartDateTime BETWEEN p_backTime_from AND p_backTime_to
    GROUP by ioc.db_Geo
    ORDER by count(ioc.db_ID) desc
    ;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `er_getCountByCountryOverall_ByIOCGeo_all`(
IN p_backTime_from VARCHAR(100),
IN p_backTime_to VARCHAR(100)
)
BEGIN
	SELECT ioc.db_Geo  as 'db_Name', count(ioc.db_id) as 'db_count' 
    FROM incident_ioc ioc, incidents i, `types` t
    WHERE i.db_typeID = t.id
    AND i.db_ID = ioc.db_ERID
	AND ioc.db_Geo <> 'N/A'
    AND (ioc.db_del = 'No') 
    AND (ioc.db_Mode = 'IOC') 
    AND i.db_StartDateTime BETWEEN p_backTime_from AND p_backTime_to
    GROUP by ioc.db_Geo
    ORDER by count(ioc.db_ID) desc
    ;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `er_getCountByCountryOverall_ByTag`()
BEGIN
	SELECT t.db_Name , count(t.db_id) as 'db_count' 
    FROM tags t, incidents i
    WHERE t.db_GroupID = i.db_ID
    AND lower(t.db_Category) like '%country%' 	
			AND (t.db_del = 'No') 
            AND (i.db_deleted = 'No') 
			 
     group by lower(trim(t.db_name))
    ORDER by count(t.db_id) desc
    ;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `er_getCountByDepOverall`()
BEGIN
	SELECT t.db_Name, 
		count(t.db_id) as 'db_count',
        FLOOR(IF(COUNT(1)=0,0,COUNT(1) / t.cnt * 100))  AS 'db_percent' 
    FROM tags t, incidents i
    CROSS JOIN (SELECT IF(COUNT(1)=0,0,COUNT(1)) AS cnt FROM incidents WHERE db_deleted = 'No') t
    WHERE t.db_GroupID = i.db_ID
    AND lower(t.db_Category) like '%department%' 	
			AND (t.db_del = 'No') 
            AND (i.db_deleted = 'No') 
            
	group by lower(trim(t.db_name))
    ORDER by count(t.db_id) desc
    limit 10
    ;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `er_getCountByEROverall`(
IN p_group varchar(100)
)
BEGIN
SELECT c.name as db_Category,IFNULL(i1.db_percent,0) as 'ER' 
	from categories c
            
	left outer join (
				SELECT db_CategoryID,IFNULL(count(*),0)  as db_count,FLOOR(IF(COUNT(1)=0,0,COUNT(1) / t1.cnt * 100))  AS 'db_percent'
				FROM incidents
                CROSS JOIN (SELECT IF(COUNT(1)=0,0,COUNT(1)) AS cnt FROM incidents WHERE db_deleted = 'No') t1
				Where (db_deleted = 'No')
				AND  
                (db_TypeID IN (select id from `types` where `group` = p_group))
                group by db_CategoryID   
    ) as i1 on c.id = i1.db_CategoryID
    ORDER By IFNULL(i1.db_percent,0) desc
;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `er_getCountByIndustryOverall`()
BEGIN
	SELECT 	t.db_Name, 
			count(t.db_id) as 'db_count',
			FLOOR(IF(COUNT(1)=0,0,COUNT(1) / t.cnt * 100))  AS 'db_percent' 	
    FROM tags t, incidents i
    CROSS JOIN (SELECT IF(COUNT(1)=0,0,COUNT(1)) AS cnt FROM incidents WHERE db_deleted = 'No') t
    WHERE t.db_GroupID = i.db_ID
    AND t.db_Category = 'industry' 	
			AND (t.db_del = 'No') 
            AND (i.db_deleted = 'No') 
     group by lower(trim(t.db_name))
    ORDER by count(t.db_id) desc
    limit 10
    ;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `er_getCountByQuarterByTime`(
IN p_typeGroup varchar(500),
IN p_module VARCHAR(100),
IN p_year VARCHAR(100) 
)
BEGIN

SELECT q.`name` AS db_quarter, IFNULL(COUNT(i.db_ID),0) AS db_count
FROM quarters q 
left join incidents i on q.`name` =  concat('Q',QUARTER(i.db_startdatetime))
AND (YEAR(i.db_startdatetime) = p_year) 
AND (i.db_deleted = 'No')
AND (i.db_TypeID IN (select id from `types` where `name`=p_typeGroup AND `types`.Module = p_module))
GROUP BY q.`name`
;


END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `er_getCountByQuarterByTime_ByProfile_ByGroup`(
IN p_typeGroup varchar(500),
IN p_profile VARCHAR(500),
IN p_group VARCHAR(500),
IN p_module VARCHAR(100),
IN p_year VARCHAR(100) 
)
BEGIN

SELECT q.`name` AS db_quarter, IFNULL(COUNT(i.db_ID),0) AS db_count
FROM quarters q 
left join incidents i on q.`name` =  concat('Q',QUARTER(i.db_startdatetime))
AND (YEAR(i.db_startdatetime) = p_year) 
AND (i.db_deleted = 'No')
AND (i.db_TypeID IN (select id from `types` where `name`=p_typeGroup AND `types`.Module = p_module))
left join users u on  i.db_ManagerID = u.db_id 
left join user_profiles up on u.db_UserProfileID = up.id


Where up.name = p_profile
	and u.db_group = p_group

GROUP BY q.`name`



;


END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `er_getCountByShift`(
IN p_type varchar(100),
IN p_module VARCHAR(100),
IN p_backTime_from VARCHAR(100),
IN p_backTime_to VARCHAR(100),
IN p_false_positive VARCHAR(3)
)
BEGIN
	SELECT ii.db_shift,IFNULL(count(*),0) as db_count, IF(IF(COUNT(1)=0,0,COUNT(1) / t1.cnt * 100)>=1,ROUND(IF(COUNT(1)=0,0,COUNT(1) / t1.cnt * 100),0),ROUND(IF(COUNT(1)=0,0,COUNT(1) / t1.cnt * 100),1)) AS 'db_percent', t1.cnt as 'db_total'
	FROM incidents ii, `types` ty
	CROSS JOIN (SELECT IF(COUNT(1)=0,0,COUNT(1)) AS cnt FROM incidents i, `types` t WHERE t.name = p_type AND t.module = p_module   AND i.db_deleted = 'No'  AND i.db_StartDateTime BETWEEN p_backTime_from AND p_backTime_to AND i.db_shift <> '-'  ) t1
	Where (ii.db_deleted = 'No') 
	AND ty.id = ii.db_typeid
	AND ty.name = p_type 
	AND ty.module = p_module
	AND ii.db_StartDateTime BETWEEN p_backTime_from AND p_backTime_to
	AND (ii.db_FalsePositive_Flag = 'No' OR ii.db_FalsePositive_Flag = p_false_positive)
	AND ii.db_shift <> '-' 
	GROUP BY ii.db_shift 
	ORDER BY db_count DESC
	LIMIT 10
;


END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `er_getCountBySLAStatus`(
IN p_type VARCHAR(100),
IN p_module VARCHAR(100),
IN p_backTime_from VARCHAR(100),
IN p_backTime_to VARCHAR(100)
)
BEGIN
SELECT 
(SELECT count(*) FROM incidents i, `types` t WHERE i.db_typeID = t.id AND t.name = p_type AND t.module = p_module AND i.db_Deleted = 'No' AND i.db_StartDateTime BETWEEN p_backTime_from AND p_backTime_to AND i.db_SLA_Applied = 'Yes' AND (i.db_Assignment_SLA_Violated = 'Yes' OR i.db_Response_SLA_Violated = 'Yes' OR i.db_Containment_SLA_Violated = 'Yes' OR i.db_Resolve_SLA_Violated = 'Yes'  OR i.db_Max_Age_SLA_Violated = 'Yes' )) as db_sla_violations, 
(SELECT count(*) FROM incidents i, `types` t WHERE i.db_typeID = t.id AND t.name = p_type AND t.module = p_module AND i.db_Deleted = 'No' AND i.db_StartDateTime BETWEEN p_backTime_from AND p_backTime_to AND i.db_SLA_Applied = 'Yes' AND (i.db_Assignment_SLA_Violated = 'No' AND i.db_Response_SLA_Violated = 'No' AND i.db_Containment_SLA_Violated = 'No' AND i.db_Resolve_SLA_Violated = 'No'  AND i.db_Max_Age_SLA_Violated = 'No' )) as db_sla_compliance
;		
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `er_getCountByStateSponsoredOverall`()
BEGIN
	SELECT 	t1.db_Name, 
		count(t1.cnt)  as 'db_count'
	FROM tags t1, tags t2
	CROSS JOIN (SELECT IF(COUNT(1)=0,0,1) AS cnt FROM tags WHERE db_Category = 'Threat Actor' AND db_del = 'No') t1
	WHERE t1.db_ID = t2.db_ID
		AND t1.db_Category = 'State Sponsored'
		AND (t1.db_del = 'No') 
	group by lower(trim(t1.db_name))
	ORDER by count(t1.db_id) desc
	limit 10 
    ;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `er_getCountBySubCategory`(
IN p_type varchar(100),
IN p_module VARCHAR(100),
IN p_backTime_from VARCHAR(100),
IN p_backTime_to VARCHAR(100),
IN p_false_positive VARCHAR(3)
)
BEGIN
SELECT c.name as db_SubCategory,IFNULL(i.db_count,0) as 'db_count', IFNULL(i.db_percent,0) as 'db_percent', i.db_total
	FROM subcategories c
	join (
				SELECT ii.db_SubCategoryID,IFNULL(count(*),0) as db_count, IF(IF(COUNT(1)=0,0,COUNT(1) / t1.cnt * 100)>=1,ROUND(IF(COUNT(1)=0,0,COUNT(1) / t1.cnt * 100),0),ROUND(IF(COUNT(1)=0,0,COUNT(1) / t1.cnt * 100),1)) AS 'db_percent', t1.cnt as 'db_total'
				FROM incidents ii, `types` ty
                CROSS JOIN (SELECT IF(COUNT(1)=0,0,COUNT(1)) AS cnt FROM incidents i, `types` t WHERE t.name = p_type  AND t.module = p_module  AND i.db_deleted = 'No' and i.db_typeid  = (select id from `types` where name = p_type and Module = p_module)  AND i.db_StartDateTime BETWEEN p_backTime_from AND p_backTime_to ) t1
				Where (ii.db_deleted = 'No')
                AND ty.id = ii.db_typeid
				AND ty.name = p_type 
                AND ty.module = p_module
                AND ii.db_StartDateTime BETWEEN p_backTime_from AND p_backTime_to
                AND (ii.db_FalsePositive_Flag = 'No' OR ii.db_FalsePositive_Flag = p_false_positive)
                group by ii.db_SubCategoryID      
    ) as i on c.id = i.db_SubCategoryID
    
	group by 1
    order by db_count DESC
    limit 10
;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `er_getCountBySubCategory_all`(
IN p_backTime_from VARCHAR(100),
IN p_backTime_to VARCHAR(100),
IN p_false_positive VARCHAR(3)
)
BEGIN
SELECT c.name as db_SubCategory,IFNULL(i.db_count,0) as 'db_count', IFNULL(i.db_percent,0) as 'db_percent', i.db_total
	FROM subcategories c
	join (
				SELECT ii.db_SubCategoryID,IFNULL(count(*),0) as db_count, IF(IF(COUNT(1)=0,0,COUNT(1) / t1.cnt * 100)>=1,ROUND(IF(COUNT(1)=0,0,COUNT(1) / t1.cnt * 100),0),ROUND(IF(COUNT(1)=0,0,COUNT(1) / t1.cnt * 100),1)) AS 'db_percent', t1.cnt as 'db_total'
				FROM incidents ii, `types` ty
                CROSS JOIN (SELECT IF(COUNT(1)=0,0,COUNT(1)) AS cnt FROM incidents i WHERE i.db_deleted = 'No' and i.db_typeid  IN (select id from `types` where `group` = 'ER')  AND i.db_StartDateTime BETWEEN p_backTime_from AND p_backTime_to ) t1
				Where (ii.db_deleted = 'No')
                AND ty.id = ii.db_typeid
				AND ty.`group` = 'ER' 
                AND ii.db_StartDateTime BETWEEN p_backTime_from AND p_backTime_to
                AND (ii.db_FalsePositive_Flag = 'No' OR ii.db_FalsePositive_Flag = p_false_positive)
                group by ii.db_SubCategoryID      
    ) as i on c.id = i.db_SubCategoryID
    
	group by 1
    order by db_count DESC
    limit 10
;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `er_getCountByTagCategoryByTime`(
IN p_tagType varchar(500),
IN p_module varchar(500),
IN p_backTime_from VARCHAR(100),
IN p_backTime_to VARCHAR(100)
)
BEGIN
	SELECT 	t.db_Name, 
			count(t.db_id) as 'db_count',
			IF( IF(COUNT(1)=0,1,COUNT(1) / tt.cnt * 100) >= 1,ROUND(IF(COUNT(1)=0,1,COUNT(1) / tt.cnt * 100),0) ,ROUND(IF(COUNT(1)=0,1,COUNT(1) / tt.cnt * 100),1))  AS 'db_percent',
            tt.cnt as 'Total'
    FROM tags t,`types` , incidents i
    CROSS JOIN (SELECT IF(COUNT(1)=0,0,COUNT(1)) AS cnt FROM incidents,`types` ty  WHERE  ty.id = incidents.db_TypeID AND ty.`Module` = p_module AND incidents.db_deleted = 'No' AND incidents.db_StartDateTime BETWEEN p_backTime_from AND p_backTime_to) tt
    WHERE t.db_GroupID = i.db_ID
    AND `types`.id = i.db_TypeID 
    AND `types`.`Module` = p_module
    AND t.db_Category = p_tagType 	
	AND (t.db_del = 'No') 
	AND (i.db_deleted = 'No')
	AND i.db_FalsePositive_Flag = 'No'
    AND i.db_StartDateTime BETWEEN p_backTime_from AND p_backTime_to
	group by lower(trim(t.db_name))
    ORDER by count(t.db_id) desc 
    limit 10;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `er_getCountByTagCategoryOverall`(
IN p_tagType varchar(500),
IN p_typeGroup varchar(500),
IN p_module varchar(500)
)
BEGIN
	SELECT 	t.db_Name, 
			count(t.db_id) as 'db_count',
			IF( IF(COUNT(1)=0,1,COUNT(1) / tt.cnt * 100) >= 1,ROUND(IF(COUNT(1)=0,1,COUNT(1) / tt.cnt * 100),0) ,ROUND(IF(COUNT(1)=0,1,COUNT(1) / tt.cnt * 100),1))  AS 'db_percent',
            tt.cnt as 'Total'
    FROM tags t,`types` , incidents i
    CROSS JOIN (SELECT IF(COUNT(1)=0,0,COUNT(1)) AS cnt FROM incidents,`types` ty  WHERE  ty.id = incidents.db_TypeID AND ty.`group` = p_typeGroup AND ty.`Module` = p_module AND incidents.db_deleted = 'No') tt
    WHERE t.db_GroupID = i.db_ID
    AND `types`.id = i.db_TypeID 
    AND `types`.`Module` = p_module
    AND t.db_Category = p_tagType 	
	AND (t.db_del = 'No') 
	AND (i.db_deleted = 'No')
	AND i.db_FalsePositive_Flag = 'No'
	group by lower(trim(t.db_name))
    ORDER by count(t.db_id) desc
    limit 10;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `er_getCountByTagNameOverall`(
IN p_tag varchar(500),
IN p_typeGroup varchar(500)
 
)
BEGIN
	SELECT 	t.db_Name, 
			count(t.db_id) as 'db_count',
			FLOOR(IF(COUNT(1)=0,0,COUNT(1) / t.cnt * 100))  AS 'db_percent' ,
            t.cnt as 'Total'
    FROM tags t, incidents i
    CROSS JOIN (SELECT IF(COUNT(1)=0,0,COUNT(1)) AS cnt FROM incidents,`types`  WHERE  `types`.id = incidents.db_TypeID AND `types`.`group` = p_typeGroup AND incidents.db_deleted = 'No') t
    WHERE t.db_GroupID = i.db_ID
    AND t.db_Name = p_tag 	
	AND (t.db_del = 'No') 
	AND (i.db_deleted = 'No') 
	AND i.db_FalsePositive_Flag = 'No'
	group by lower(trim(t.db_name))
    ORDER by count(t.db_id) desc
    limit 10
    ;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `er_getCountByTagOverall`(
IN p_tag varchar(500),
IN p_module varchar(500)
)
BEGIN
	SELECT 	t.db_Name, 
			count(t.db_id) as 'db_count',
			IF( IF(COUNT(1)=0,1,COUNT(1) / t.cnt * 100) >= 1,ROUND(IF(COUNT(1)=0,1,COUNT(1) / t.cnt * 100),0) ,ROUND(IF(COUNT(1)=0,1,COUNT(1) / t.cnt * 100),1))  AS 'db_percent',
            t.cnt  AS 'db_total_count' 
    FROM tags t, incidents i, types tp
    CROSS JOIN (SELECT IF(COUNT(1)=0,0,COUNT(1)) AS cnt FROM incidents WHERE db_deleted = 'No') t
    WHERE t.db_GroupID = i.db_ID
    AND tp.id = i.db_typeID
    AND tp.module = p_module
    AND t.db_Category = p_tag 	
			AND (t.db_del = 'No') 
            AND (i.db_deleted = 'No') 
	group by lower(trim(t.db_name))
    ORDER by count(t.db_id) desc
    limit 10
    ;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `er_getCountByTargetOverall`(
 
)
BEGIN
	SELECT 	t.db_Name, 
			count(t.db_id) as 'db_count',
			FLOOR(IF(COUNT(1)=0,0,COUNT(1) / t.cnt * 100))  AS 'db_percent' 	
    FROM tags t, incidents i
    CROSS JOIN (SELECT IF(COUNT(1)=0,0,COUNT(1)) AS cnt FROM incidents WHERE db_deleted = 'No') t
    WHERE t.db_GroupID = i.db_ID
    AND t.db_Category = 'Target'	
			AND (t.db_del = 'No') 
            AND (i.db_deleted = 'No') 
	group by lower(trim(t.db_name))
    ORDER by count(t.db_id) desc
    limit 10
    ;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `er_getCountByThreatActorOverall`()
BEGIN
	SELECT 	t.db_Name, 
			count(t.db_id) AS 'db_count',
			FLOOR(IF(COUNT(1)=0,0,COUNT(1) / t.cnt * 100))  AS 'db_percent' 
	FROM tags t, incidents i
    CROSS JOIN (SELECT IF(COUNT(1)=0,0,COUNT(1)) AS cnt FROM incidents WHERE db_deleted = 'No') t
    WHERE t.db_GroupID = i.db_ID
    AND lower(t.db_Category) LIKE '%threat actor%' 	
			AND (t.db_del = 'No') 
            AND (i.db_deleted = 'No') 
			 
    GROUP BY lower(trim(t.db_Name))
    ORDER BY count(t.db_id) DESC
    LIMIT 10
    ;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `er_getCountByTime`(
IN p_type varchar(50),
IN p_module VARCHAR(100),
IN p_backTime_from VARCHAR(100),
IN p_backTime_to VARCHAR(100)
)
BEGIN

	SELECT count(i.db_ID) as 'Count' 
	FROM incidents i, `types` t, categories c
	Where	i.db_typeID = t.id
			AND i.db_CategoryID = c.id
            AND (i.db_deleted = 'No') 
            AND t.name = p_type
            AND (lower(t.`Module`) = lower(p_module))
			AND ((i.db_StartDateTime BETWEEN p_backTime_from AND p_backTime_to) OR (i.db_Escalation_Date BETWEEN p_backTime_from AND p_backTime_to))
;		
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `er_getCountByTime_ByProfile_ByGroup`(
IN p_type varchar(50),
IN p_profile varchar(500),
IN p_group varchar(500),
IN p_backTime_from VARCHAR(100),
IN p_backTime_to VARCHAR(100)
)
BEGIN

	SELECT count(i.db_ID) as 'Count' 
	FROM incidents i, `types` t, categories c, users u, user_profiles up
	Where	i.db_typeID = t.id
			AND i.db_ManagerID = u.db_ID
            AND up.id = u.db_UserProfileID
			AND i.db_CategoryID = c.id
            AND (i.db_deleted = 'No') 
            AND t.name = p_type
            AND u.db_group = p_group
            AND up.name = p_profile
            AND ((i.db_StartDateTime BETWEEN p_backTime_from AND p_backTime_to) OR (i.db_Escalation_Date BETWEEN p_backTime_from AND p_backTime_to))

            
            ;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `er_getCountCurrentYear_EsclatedIncidents`(
IN p_type varchar(50),
IN p_backTime_from VARCHAR(100),
IN p_backTime_to VARCHAR(100),
IN p_escalated_module VARCHAR(100)
)
BEGIN
SELECT count(i.db_ID) as 'Count' 
	FROM incidents i, `types` t
	Where	i.db_typeID = t.id
            AND (i.db_deleted = 'No') 
            AND t.name = p_type
            AND i.db_EsclatedIncident_Flag = 'Yes'
			AND ((i.db_StartDateTime BETWEEN p_backTime_from AND p_backTime_to) OR (i.db_Escalation_Date BETWEEN p_backTime_from AND p_backTime_to))
            AND (i.db_Escalated_Module = p_escalated_module)
            ;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `er_getCountCurrentYear_EsclatedIncidents_ByProfile_ByGroup`(
IN p_type varchar(50),
IN p_profile varchar(500),
IN p_group varchar(500),
IN p_backTime_from VARCHAR(100),
IN p_backTime_to VARCHAR(100),
IN p_escalated_module VARCHAR(100)
)
BEGIN
SELECT count(i.db_ID) as 'Count' 
	FROM incidents i, `types` t, categories c, users u, user_profiles up
	Where	i.db_typeID = t.id
			AND i.db_ManagerID = u.db_ID
            AND up.id = u.db_UserProfileID
			AND i.db_CategoryID = c.id
            AND (i.db_deleted = 'No') 
            AND t.name = p_type
			AND ((i.db_StartDateTime BETWEEN p_backTime_from AND p_backTime_to) OR (i.db_Escalation_Date BETWEEN p_backTime_from AND p_backTime_to))
            AND u.db_group = p_group
            AND up.name = p_profile
            AND i.db_EsclatedIncident_Flag = 'Yes'
			AND (i.db_Escalated_Module = p_escalated_module)
            
            ;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `er_getERsByIOC`(
IN p_name longtext,
IN p_value longtext,
IN p_module varchar(45)
)
BEGIN

SELECT 	incidents.*,
		t1.db_FullName as db_Manager,
        t2.db_FullName as db_Initiator,
        `types`.name as db_Type, 
		`types`.DisplayName_2 as db_Type_2, 
        categories.`name` as db_Category,
        subcategories.`name` as db_SubCategory,
         DATE_FORMAT(incidents.db_StartDateTime,'%d-%m-%Y %h:%i %p') as 'db_StartDateTimeFormatted',
        DATE_FORMAT(incidents.db_Containment_Date,'%d-%m-%Y %h:%i %p') as 'db_ContainmentDateFormatted',
        DATE_FORMAT(incidents.db_Date_of_Closure,'%d-%m-%Y %h:%i %p') as 'db_DateOfClosureFormatted',
        '' as db_tags,  
		concat('Q',QUARTER(incidents.db_startdatetime)) as db_Quarter,
		MONTHNAME(STR_TO_DATE(Month(incidents.db_startdatetime), '%m')) as db_Month,
		s.db_title as db_sla_name 
 FROM incidents 
 LEFT JOIN `types` on incidents.db_typeID = `types`.id 
 LEFT JOIN categories on incidents.db_CategoryID = categories.id 
 LEFT JOIN subcategories on incidents.db_SubCategoryID = subcategories.id 
 LEFT JOIN users t1 on incidents.db_ManagerID = t1.db_id 
 LEFT JOIN users t2 on incidents.db_InitiatorID = t2.db_id 
 LEFT JOIN incident_ioc on incidents.db_ID = incident_ioc.db_ERID
 LEFT JOIN sla s on s.db_id = incidents.db_SLA_ID
 WHERE (incidents.db_deleted = 'No')   
 AND  incident_ioc.db_name = p_name
 AND  incident_ioc.db_value = p_value
 AND  incident_ioc.db_Del = 'No'
 AND `types`.Module = p_module
 GROUP BY incidents.db_id 
 ORDER BY  incidents.db_Escalation_Date DESC, incidents.db_StartDateTime DESC
 ;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `er_getERsByIOC_ByProfile_ByGroup`(
IN p_name longtext,
IN p_value longtext,
IN p_profile VARCHAR(500),
IN p_group VARCHAR(500),
IN p_module varchar(45)
)
BEGIN
SELECT 	i.*,
		t1.db_FullName as db_Manager,
        t2.db_FullName as db_Initiator,
        `types`.name as db_Type, 
         `types`.DisplayName_2 as db_Type_2, 
        categories.`name` as db_Category,
        subcategories.`name` as db_SubCategory,
         DATE_FORMAT(i.db_StartDateTime,'%d-%m-%Y %h:%i %p') as 'db_StartDateTimeFormatted',
        DATE_FORMAT(i.db_Containment_Date,'%d-%m-%Y %h:%i %p') as 'db_ContainmentDateFormatted',
        DATE_FORMAT(i.db_Date_of_Closure,'%d-%m-%Y %h:%i %p') as 'db_DateOfClosureFormatted',
        '' as db_tags,  
		concat('Q',QUARTER(i.db_startdatetime)) as db_Quarter,
		MONTHNAME(STR_TO_DATE(Month(i.db_startdatetime), '%m')) as db_Month,
		s.db_title as db_sla_name 
 FROM incidents i
 LEFT JOIN `types` on i.db_typeID = `types`.id 
 LEFT JOIN categories on i.db_CategoryID = categories.id 
 LEFT JOIN subcategories on i.db_SubCategoryID = subcategories.id 
 LEFT JOIN users t1 on i.db_ManagerID = t1.db_id 
 LEFT JOIN users t2 on i.db_InitiatorID = t2.db_id 
 LEFT JOIN incident_ioc on i.db_ID = incident_ioc.db_ERID
 left join users u on  i.db_ManagerID = u.db_id 
 left join user_profiles up on u.db_UserProfileID = up.id
 LEFT JOIN sla s on s.db_id = i.db_SLA_ID
 WHERE (i.db_deleted = 'No')   
 AND  incident_ioc.db_name = p_name
 AND  incident_ioc.db_value = p_value
 AND  incident_ioc.db_Del = 'No'
 AND up.name = p_profile
 AND u.db_group = p_group
 AND `types`.Module = p_module
 GROUP BY i.db_id 
 ORDER BY i.db_Escalation_Date DESC, i.db_StartDateTime DESC
 ;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `er_getERsByTagsStartWith`(
IN p_tag longtext
)
BEGIN

SELECT distinct db_name  
FROM tags 
WHERE (db_Del = 'No') and (db_name like p_tag )
LIMIT 10
;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `er_getERsByTitleStartWith`(
IN p_title longtext
)
BEGIN

SELECT distinct db_title  
FROM incidents 
WHERE (db_Deleted = 'No') and (db_title like p_title)
LIMIT 10
;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `er_getERsByType_AllYears`(
IN p_type VARCHAR(100)
)
BEGIN

	SELECT incidents.*,
			t1.db_FullName as db_Manager,
            t2.db_FullName as db_Initiator,
            `types`.name as db_Type, 
            `types`.DisplayName_2 as db_Type_2, 
            categories.name as db_Category,
            subcategories.name as db_SubCategory, 
            DATE_FORMAT(db_StartDateTime,'%m-%d-%Y %h:%i %p') as 'db_StartDateTimeFormatted',
		    DATE_FORMAT(incidents.db_Containment_Date,'%d-%m-%Y %h:%i %p') as 'db_ContainmentDateFormatted',
            DATE_FORMAT(incidents.db_Date_of_Closure,'%d-%m-%Y %h:%i %p') as 'db_DateOfClosureFormatted',
			concat('Q',QUARTER(incidents.db_startdatetime)) as db_Quarter,
			MONTHNAME(STR_TO_DATE(Month(incidents.db_startdatetime), '%m')) as db_Month 
	FROM incidents 
	LEFT JOIN `types` on incidents.db_typeID = `types`.id
		LEFT JOIN  categories on incidents.db_CategoryID = categories.id
        LEFT JOIN subcategories on incidents.db_SubCategoryID = subcategories.id
        LEFT JOIN users t1 on incidents.db_ManagerID = t1.db_id
        LEFT JOIN users t2 on incidents.db_InitiatorID = t2.db_id
         
        
	WHERE (db_deleted = 'No') 
	AND (`types`.name = p_Type) 
    
        
    
    
    GROUP BY incidents.db_id     
	ORDER by db_Escalation_Date DESC, db_StartDateTime DESC
    ;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `er_getERsMostRecent`(

IN p_status VARCHAR(50),
IN p_managerID VARCHAR(50),
IN p_module VARCHAR(100),
IN p_objectType VARCHAR(100) 

)
BEGIN

SELECT incidents.*,t1.db_FullName as db_Manager,
		t2.db_FullName as db_Initiator,
        `types`.name as db_Type, 
        `types`.DisplayName_2 as db_Type_2, 
        categories.name as db_Category,
        subcategories.name as db_SubCategory, 
        DATE_FORMAT(incidents.db_StartDateTime,'%d-%m-%Y %h:%i %p') as 'db_StartDateTimeFormatted',
        DATE_FORMAT(incidents.db_Containment_Date,'%d-%m-%Y %h:%i %p') as 'db_ContainmentDateFormatted',
        DATE_FORMAT(incidents.db_Date_of_Closure,'%d-%m-%Y %h:%i %p') as 'db_DateOfClosureFormatted',
        '' as db_tags,
        concat('Q',QUARTER(incidents.db_startdatetime)) as db_Quarter,
		MONTHNAME(STR_TO_DATE(Month(incidents.db_startdatetime), '%m')) as db_Month,
		s.db_title as db_sla_name 
        
FROM incidents 
LEFT JOIN `types` on incidents.db_typeID = `types`.id  
		LEFT JOIN  categories on incidents.db_CategoryID = categories.id
        LEFT JOIN subcategories on incidents.db_SubCategoryID = subcategories.id
        LEFT JOIN users t1 on incidents.db_ManagerID = t1.db_id
        LEFT JOIN users t2 on incidents.db_InitiatorID = t2.db_id
        LEFT JOIN sla s on s.db_id = incidents.db_SLA_ID 
         

Where	
		incidents.db_id IN  (SELECT db_id from (select i.db_id from incidents i, `types` t where i.db_typeID = t.id and t.Module = p_module and t.`Name` = p_objectType and i.db_Deleted = 'No' order by i.db_Escalation_Date DESC, i.db_StartDateTime DESC limit 10) as t) 
		AND incidents.db_Status like p_status 
        AND incidents.db_ManagerID like p_managerID           
        AND  incidents.db_Deleted = 'No'
        
        
GROUP BY incidents.db_id        
ORDER By db_Escalation_Date DESC, db_StartDateTime DESC
limit 6;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `er_getERsMostRecentByName`(

IN p_status VARCHAR(50),
IN p_managerID VARCHAR(50),
IN p_module VARCHAR(100),
IN p_objectType VARCHAR(100) 

)
BEGIN

SELECT incidents.*,t1.db_FullName as db_Manager,
		t2.db_FullName as db_Initiator,
        `types`.name as db_Type, 
        `types`.DisplayName_2 as db_Type_2, 
        categories.name as db_Category,
        subcategories.name as db_SubCategory, 
        DATE_FORMAT(incidents.db_StartDateTime,'%d-%m-%Y %h:%i %p') as 'db_StartDateTimeFormatted',
        DATE_FORMAT(incidents.db_Containment_Date,'%d-%m-%Y %h:%i %p') as 'db_ContainmentDateFormatted',
        DATE_FORMAT(incidents.db_Date_of_Closure,'%d-%m-%Y %h:%i %p') as 'db_DateOfClosureFormatted',
        '' as db_tags,
        concat('Q',QUARTER(incidents.db_startdatetime)) as db_Quarter,
		MONTHNAME(STR_TO_DATE(Month(incidents.db_startdatetime), '%m')) as db_Month,
		s.db_title as db_sla_name 
        
FROM incidents 
LEFT JOIN `types` on incidents.db_typeID = `types`.id  
		LEFT JOIN  categories on incidents.db_CategoryID = categories.id
        LEFT JOIN subcategories on incidents.db_SubCategoryID = subcategories.id
        LEFT JOIN users t1 on incidents.db_ManagerID = t1.db_id
        LEFT JOIN users t2 on incidents.db_InitiatorID = t2.db_id
        LEFT JOIN sla s on s.db_id = incidents.db_SLA_ID 
         

Where	
		incidents.db_id IN  (SELECT db_id from (select i.db_id from incidents i, `types` t where i.db_typeID = t.id and t.Module = p_module and t.`group` = p_objectType and i.db_Deleted = 'No' order by i.db_Escalation_Date DESC, i.db_StartDateTime DESC limit 10) as t) 
		AND incidents.db_Status like p_status 
        AND incidents.db_ManagerID like p_managerID           
        AND  incidents.db_Deleted = 'No'
        
        
GROUP BY incidents.db_id        
ORDER By db_Escalation_Date DESC, db_StartDateTime DESC
limit 6;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `er_getERsMostRecent_ByProfile_ByGroup`(

 
IN p_profile VARCHAR(500),
IN p_group VARCHAR(500),
IN p_module VARCHAR(100),
IN p_objectType VARCHAR(100) 

)
BEGIN

SELECT incidents.*,t1.db_FullName as db_Manager,
		t2.db_FullName as db_Initiator,
        `types`.name as db_Type, 
        `types`.DisplayName_2 as db_Type_2, 
        categories.name as db_Category,
        subcategories.name as db_SubCategory, 
        DATE_FORMAT(incidents.db_StartDateTime,'%d-%m-%Y %h:%i %p') as 'db_StartDateTimeFormatted',
        DATE_FORMAT(incidents.db_Containment_Date,'%d-%m-%Y %h:%i %p') as 'db_ContainmentDateFormatted',
        DATE_FORMAT(incidents.db_Date_of_Closure,'%d-%m-%Y %h:%i %p') as 'db_DateOfClosureFormatted',
        '' as db_tags,
        concat('Q',QUARTER(incidents.db_startdatetime)) as db_Quarter,
		MONTHNAME(STR_TO_DATE(Month(incidents.db_startdatetime), '%m')) as db_Month,
		s.db_title as db_sla_name 
        
FROM incidents 
LEFT JOIN `types` on incidents.db_typeID = `types`.id 
		LEFT JOIN  categories on incidents.db_CategoryID = categories.id
        LEFT JOIN subcategories on incidents.db_SubCategoryID = subcategories.id
        LEFT JOIN users t1 on incidents.db_ManagerID = t1.db_id
        LEFT JOIN users t2 on incidents.db_InitiatorID = t2.db_id
		LEFT JOIN user_profiles up on t1.db_UserProfileID = up.ID
        LEFT JOIN sla s on s.db_id = incidents.db_SLA_ID 

Where	
		t1.db_Group = p_group
        AND up.name = p_profile
                AND  incidents.db_Deleted = 'No'
                AND `types`.Module = p_module
                AND `types`.Name = p_objectType
        
GROUP BY incidents.db_id        
ORDER By	 db_Escalation_Date DESC, db_StartDateTime DESC
limit 15;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `er_getERsMostRecent_ciso`(
IN p_backTime_from VARCHAR(100),
IN p_backTime_to VARCHAR(100)

)
BEGIN

SELECT incidents.*,t1.db_FullName as db_Manager,
		t2.db_FullName as db_Initiator,
        `types`.name as db_Type, 
        `types`.DisplayName_2 as db_Type_2, 
        categories.name as db_Category,
        subcategories.name as db_SubCategory, 
        DATE_FORMAT(incidents.db_StartDateTime,'%d-%m-%Y %h:%i %p') as 'db_StartDateTimeFormatted',
        DATE_FORMAT(incidents.db_Containment_Date,'%d-%m-%Y %h:%i %p') as 'db_ContainmentDateFormatted',
        DATE_FORMAT(incidents.db_Date_of_Closure,'%d-%m-%Y %h:%i %p') as 'db_DateOfClosureFormatted',
        '' as db_tags,
        concat('Q',QUARTER(incidents.db_startdatetime)) as db_Quarter,
		MONTHNAME(STR_TO_DATE(Month(incidents.db_startdatetime), '%m')) as db_Month,
		s.db_title as db_sla_name 
        
FROM incidents 
LEFT JOIN `types` on incidents.db_typeID = `types`.id  
		LEFT JOIN  categories on incidents.db_CategoryID = categories.id
        LEFT JOIN subcategories on incidents.db_SubCategoryID = subcategories.id
        LEFT JOIN users t1 on incidents.db_ManagerID = t1.db_id
        LEFT JOIN users t2 on incidents.db_InitiatorID = t2.db_id
        LEFT JOIN sla s on s.db_id = incidents.db_SLA_ID 
         

Where	
		incidents.db_id IN  (SELECT db_id from (select i.db_id from incidents i, `types` t where i.db_typeID = t.id AND t.group = 'ER' AND i.db_Deleted = 'No' AND i.db_StartDateTime BETWEEN p_backTime_from AND p_backTime_to AND i.db_SLA_Applied = 'Yes' AND (i.db_Assignment_SLA_Violated = 'Yes' OR i.db_Response_SLA_Violated = 'Yes' OR i.db_Containment_SLA_Violated = 'Yes' OR i.db_Resolve_SLA_Violated = 'Yes'  OR i.db_Max_Age_SLA_Violated = 'Yes' ) order by i.db_Escalation_Date DESC, i.db_StartDateTime DESC) as t) 
        AND  incidents.db_Deleted = 'No'
        
        
GROUP BY incidents.db_id        
ORDER By db_Escalation_Date DESC, db_StartDateTime DESC
limit 6;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `er_getEvidencesByERID`(
IN p_erID INT(11)
)
BEGIN
SELECT evidences.*, users.db_FullName as db_CreatedBy, DATE_FORMAT(db_CollectionDate,'%d-%m-%Y %h:%i:%s %p') as db_CollectionDateFormated
FROM evidences, users
WHERE users.db_ID = evidences.db_UserID 
AND evidences.db_Del = 'No'
AND evidences.db_ERID = p_erID
;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `er_getImpactsByERID`(
IN p_erid INT(11),
IN p_type varchar(100)
)
BEGIN

select *, impact.db_Name as db_impact
from incident_impacts, impact 
where incident_impacts.db_ImpactID = impact.db_ID
AND db_ERID = p_erid
AND incident_impacts.db_Type = p_type
;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `er_getIncidentInfoByID`(
IN p_id INT(20)
)
BEGIN
	SELECT i.*,
    t3.name as db_Type, 
    t3.DisplayName_2 as db_Type_2, 
    t4.name as db_Category, 
    t5.name as db_SubCategory,
    t1.db_FullName as `db_Initiator`,
    t2.db_FullName as `db_Manager`,
    DATE_FORMAT(i.db_StartDateTime,'%d-%m-%Y %h:%i:%s %p') as 'db_StartDateTimeFormatted',
    DATE_FORMAT(i.db_Containment_Date,'%d-%m-%Y %h:%i:%s %p') as 'db_ContainmentDateFormatted',
    DATE_FORMAT(i.db_Date_of_Closure,'%d-%m-%Y %h:%i:%s %p') as 'db_DateOfClosureFormatted',
    DATE_FORMAT(i.db_share_published_date,'%d-%m-%Y %h:%i:%s %p') as 'db_share_published_date_formatted',
    s.db_title as db_sla_name
    
	FROM incidents i
	LEFT JOIN users t1 ON i.db_InitiatorID=t1.db_ID  
	LEFT JOIN users t2 ON i.db_ManagerID=t2.db_ID
	LEFT JOIN `types` t3 ON i.db_typeID = t3.id
	LEFT JOIN categories t4 ON i.db_CategoryID = t4.id
    LEFT JOIN subcategories t5 ON i.db_SubCategoryID = t5.id
    LEFT JOIN sla s on s.db_id = i.db_SLA_ID
	WHERE (i.db_ID=p_id); 
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `er_getInvestigations`()
BEGIN
SELECT incidents.*,
		t1.db_FullName as db_Manager,
        t2.db_FullName as db_Initiator,
        `types`.name as db_Type, 
        `types`.DisplayName_2 as db_Type_2, 
        categories.name as db_Category,
        subcategories.name as db_SubCategory, 
        DATE_FORMAT(incidents.db_StartDateTime,'%d-%m-%Y %h:%i %p') as 'db_StartDateTimeFormatted',
        DATE_FORMAT(incidents.db_Containment_Date,'%d-%m-%Y %h:%i %p') as 'db_ContainmentDateFormatted',
        DATE_FORMAT(incidents.db_Date_of_Closure,'%d-%m-%Y %h:%i %p') as 'db_DateOfClosureFormatted',
        '' as db_tags,
        concat('Q',QUARTER(incidents.db_startdatetime)) as db_Quarter,
		MONTHNAME(STR_TO_DATE(Month(i.db_startdatetime), '%m')) as db_Month,
		s.db_title as db_sla_name  
        
FROM incidents 
LEFT JOIN `types` on incidents.db_typeID = `types`.id
		LEFT JOIN  categories on incidents.db_CategoryID = categories.id
        LEFT JOIN subcategories on incidents.db_SubCategoryID = subcategories.id
        LEFT JOIN users t1 on incidents.db_ManagerID = t1.db_id
        LEFT JOIN users t2 on incidents.db_InitiatorID = t2.db_id
        LEFT JOIN sla s on s.db_id = i.db_SLA_ID
         
        
WHERE 	(incidents.db_deleted = 'No') 
		AND (`types`.`Group` = 'INV')
       
GROUP BY incidents.db_id          
ORDER BY  db_Escalation_Date DESC, db_StartDateTime DESC
;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `er_getObjecCountByAgeByTime`(
IN p_Type VARCHAR(50),
IN p_backTime_from VARCHAR(100),
IN p_backTime_to VARCHAR(100)
)
BEGIN
SELECT  count(d2.db_ID) as `2-3 Days`, count(d4.db_ID) as `4-5 Days`, count(d6.db_ID) as `6-7 Days`, count(d8.db_ID) as `8-9 Days`, count(d10.db_ID) as `10 Days`
FROM `types` , incidents t  
left join incidents d2 on t.db_ID = d2.db_ID AND datediff(now(),d2.db_StartDateTime) >= 2 and datediff(now(),d2.db_StartDateTime) <= 3   
left join incidents d4 on t.db_ID = d4.db_ID and datediff(now(),d4.db_StartDateTime) >= 4 and datediff(now(),d4.db_StartDateTime) <= 5  
left join incidents d6 on t.db_ID = d6.db_ID and datediff(now(),d6.db_StartDateTime) >= 6 and datediff(now(),d6.db_StartDateTime) <= 7   
left join incidents d8 on t.db_ID = d8.db_ID and datediff(now(),d8.db_StartDateTime) >= 8 and datediff(now(),d8.db_StartDateTime) <= 9   
left join incidents d10 on t.db_ID = d10.db_ID and datediff(now(),d10.db_StartDateTime) >=  10  AND d10.db_status = 'Open'  
WHERE (t.db_typeID) = `types`.id AND (`types`.`name` = p_Type)
AND t.db_Deleted  = 'No'
AND t.db_status = 'Open'
AND ((t.db_StartDateTime BETWEEN p_backTime_from AND p_backTime_to) OR (t.db_Escalation_Date BETWEEN p_backTime_from AND p_backTime_to))
;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `er_getRisksByERID`(
IN p_erid INT(11)
)
BEGIN

select *, risks.db_Name as db_Risk
from incident_risks, risks 
where incident_risks.db_RiskID = risks.db_ID
AND db_ERID = p_erid
;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `er_getSeverityByTime`(
IN p_typeGroup VARCHAR(100),
IN p_module VARCHAR(100),
IN p_backTime_from VARCHAR(100),
IN p_backTime_to VARCHAR(100)

)
BEGIN

SELECT s.*, IFNULL(i.db_count,0) as db_count
from severity s

left outer join (
				SELECT i.db_severity, IFNULL(count(*),0) as db_count
				FROM incidents i, `types` t
                where  i.db_TypeID = t.ID
				AND (i.db_deleted = 'No')
				AND ((i.db_StartDateTime BETWEEN p_backTime_from AND p_backTime_to) OR (i.db_Escalation_Date BETWEEN p_backTime_from AND p_backTime_to))
				AND t.Module = p_module
				AND t.`name`=p_typeGroup
                group by i.db_severity
                
    ) as i on s.db_severity = i.db_severity
group by s.db_Severity 
order by s.db_ID
;


END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `er_getSeverityByTimeByGroup`(
IN p_typeGroup VARCHAR(100),
IN p_module VARCHAR(100),
IN p_backTime_from VARCHAR(100),
IN p_backTime_to VARCHAR(100)

)
BEGIN

SELECT s.*, IFNULL(i.db_count,0) as db_count
from severity s

left outer join (
				SELECT i.db_severity, IFNULL(count(*),0) as db_count
				FROM incidents i, `types` t
                where  i.db_TypeID = t.ID
				AND (i.db_deleted = 'No')
				AND ((i.db_StartDateTime BETWEEN p_backTime_from AND p_backTime_to) OR (i.db_Escalation_Date BETWEEN p_backTime_from AND p_backTime_to))
				AND t.Module = p_module
				AND t.`group`=p_typeGroup
                group by i.db_severity
                
    ) as i on s.db_severity = i.db_severity
group by s.db_Severity 
order by s.db_ID
;


END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `er_getSeverityByTime_ByProfile_ByGroup`(
IN p_typeGroup VARCHAR(100),
IN p_profile VARCHAR(500),
IN p_group VARCHAR(500),
IN p_module VARCHAR(100),
IN p_backTime_from VARCHAR(100),
IN p_backTime_to VARCHAR(100)

)
BEGIN

SELECT s.*, IFNULL(i.db_count,0) as db_count
from severity s

left outer join (
				SELECT i.db_severity, IFNULL(count(*),0) as db_count
				FROM incidents i, `types` t, users u, user_profiles up
                where  i.db_TypeID = t.ID
				AND (i.db_deleted = 'No')
				AND ((i.db_StartDateTime BETWEEN p_backTime_from AND p_backTime_to) OR (i.db_Escalation_Date BETWEEN p_backTime_from AND p_backTime_to))
				AND t.Module = p_module
				AND t.`name`=p_typeGroup
                AND i.db_ManagerID = u.db_id 
				AND u.db_UserProfileID = up.id
				AND up.name = p_profile
				AND u.db_group = p_group
                group by i.db_severity
                
    ) as i on s.db_severity = i.db_severity
group by s.db_Severity 
order by s.db_ID

 ;


END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `er_getsubcategoriesByCategory`(

IN p_CategoryID INT(11)

)
BEGIN

SELECT subcategories.*, IFNULL(count(v.db_ID),0) as `count_objects`, IFNULL(uc.db_count,0) as `count_usecases` 

FROM subcategories 
left outer join use_cases on subcategories.ID = use_cases.db_SubCatID
left outer join (select case_triggers.* from incidents,case_triggers where incidents.db_id = case_triggers.db_CaseID and case_triggers.db_Del = 'No') as v ON use_cases.db_ID = v.db_UseCaseID 	
left outer join (select *, IFNULL(count(*),0) as db_count from use_cases where db_Del = 'No' Group by db_SubCatID) as uc ON subcategories.ID = uc.db_SubCatID 	
  	
WHERE
	subcategories.CategoryID = p_CategoryID
    AND subcategories.Del = 'No'
Group by subcategories.ID 
order by count_usecases desc
;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `er_getSubTypesByERID`(
IN p_erid INT(11)
)
BEGIN

select *, sub_types.db_Name as db_SubType
from incident_subtypes, sub_types 
where incident_subtypes.db_SubTypeID = sub_types.db_ID
AND db_ERID = p_erid
;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `er_getTopCountByCategoryOverall`(
IN p_group varchar(100),
IN p_module VARCHAR(100),
IN p_backTime_from VARCHAR(100),
IN p_backTime_to VARCHAR(100)
)
BEGIN
Select MAX(a.db_count) as `db_count` 
FROM (
	SELECT c.name as db_Category, count(i.db_id) as 'db_Count' 
    from incidents i, `types` t, categories c, subcategories sc
    WHERE 	i.db_typeID = t.id
			AND i.db_CategoryID = c.id
            AND i.db_SubCategoryID = sc.id 
			AND (i.db_deleted = 'No') 
			AND (t.`Group` = p_group )
            AND (t.`Module` = p_module)
			AND i.db_StartDateTime BETWEEN p_backTime_from AND p_backTime_to
    group by c.name
    ) as a
    limit 50
    ;
    
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `er_getTopCountByCategoryOverall_all`(
IN p_backTime_from VARCHAR(100),
IN p_backTime_to VARCHAR(100)
)
BEGIN
Select MAX(a.db_count) as `db_count` 
FROM (
	SELECT c.name as db_Category, count(i.db_id) as 'db_Count' 
    from incidents i, `types` t, categories c, subcategories sc
    WHERE 	i.db_typeID = t.id
			AND i.db_CategoryID = c.id
            AND i.db_SubCategoryID = sc.id 
			AND (i.db_deleted = 'No') 
			AND (t.`Group` = 'ER' )
			AND i.db_StartDateTime BETWEEN p_backTime_from AND p_backTime_to
    group by c.name
    ) as a
    limit 50
    ;
    
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `er_getTopCountByCountryOverall`()
BEGIN
Select MAX(a.db_count) as `db_count` 
FROM (
	SELECT db_Name , count(db_id) as 'db_count' 
    from tags
    WHERE lower(db_Category) like '%country%' 	
			AND (db_del = 'No') 
			 
    group by lower(trim(db_name))
    ) as a ;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `er_getTriggerSourceNameStartWith`(
IN p_name longtext
)
BEGIN

SELECT distinct db_TriggerSourceName  
FROM case_triggers 
WHERE (db_TriggerSourceName like p_name)
LIMIT 10
;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `er_incidents_timeline`()
BEGIN
Select i.db_ID,i.db_StartDateTime,i.db_Reference, i.db_Title, t.db_name 
from incidents i
LEFT JOIN tags t on i.db_id = t.db_GroupID 
where i.db_deleted = 'No' 
AND t.db_Del = 'No' 
AND t.db_Name IN ('National Incidents','Regional Incidents', 'Global Incidents');

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `er_insertCustomeAttribute`(
IN p_Type  VARCHAR(45),
IN p_Name  VARCHAR(50),
IN p_Title VARCHAR(500),
IN p_Value longtext,
IN p_ERID INT(11),
IN p_Parent VARCHAR(45),
OUT p_id INT(11)
)
BEGIN


INSERT INTO custom_attributes
(
db_Type, 
db_Name,
db_Title,
db_Value,
db_ERID,
db_Parent
)
VALUES
(
p_Type,
p_Name,
p_Title,
p_Value,
p_ERID,
p_Parent
);
SET p_id = last_insert_id();

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `er_insertER`(
 
IN p_StartDateTime VARCHAR(30),
IN p_Title longtext,
IN p_Severity VARCHAR(50),
IN p_InitiatorID INT(11),
IN p_ManagerID INT(11),
IN p_CategoryID INT(11),
IN p_TypeID INT(11),
IN p_SubCategoryID INT(11),
IN p_Reference VARCHAR(50),
OUT p_id INT(11),
IN p_Status VARCHAR(50)
)
BEGIN
 INSERT INTO incidents
(
db_StartDateTime,
db_Title,
db_Severity,
db_InitiatorID,
db_ManagerID,
db_CategoryID,
db_TypeID,
db_SubCategoryID,
db_Reference,
db_Status
)
VALUES
(
p_StartDateTime,
p_Title,
p_Severity,
p_InitiatorID,
p_ManagerID,
p_CategoryID,
p_TypeID,
p_SubCategoryID,
p_Reference,
p_Status
);
SET p_id = last_insert_id();
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `er_updateAge`(
IN p_erid INT(11)
)
BEGIN

update incidents 
		set db_age = 
		if(isnull(db_Date_of_Closure),'N/A', CONCAT(
			if(TIMESTAMPDIFF(day,db_StartDateTime,db_Date_of_Closure)=0,'',concat(TIMESTAMPDIFF(day,db_StartDateTime,db_Date_of_Closure),' D ')) ,
			if(MOD( TIMESTAMPDIFF(hour,db_StartDateTime,db_Date_of_Closure), 24)=0,'',concat(MOD( TIMESTAMPDIFF(hour,db_StartDateTime,db_Date_of_Closure), 24), ' H ')),
			if(MOD( TIMESTAMPDIFF(minute,db_StartDateTime,db_Date_of_Closure), 60)=0, '0 M',concat(MOD( TIMESTAMPDIFF(minute,db_StartDateTime,db_Date_of_Closure), 60), ' M '))
			)),
			db_age_min = if(isnull(db_Date_of_Closure),0,TIMESTAMPDIFF(minute,db_StartDateTime,db_Date_of_Closure)) 

where db_id = p_erid;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `event_rule_get_actions`(
IN p_rule_id int(11)
)
BEGIN

SELECT *
FROM event_actions ea
WHERE 	ea.db_rule_id = p_rule_id
AND		ea.db_del = 'No'
;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `event_rule_get_all`(
IN p_module varchar(45)
)
BEGIN

SELECT er.*, u.db_FullName as db_user, DATE_FORMAT(er.db_last_update,'%d-%m-%Y %h:%i %p') as 'db_last_update_formated'
FROM event_rules er, users u
WHERE 	er.db_user_id = u.db_id
AND		er.db_del = 'No'
AND		er.db_module = p_module

;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `event_rule_get_all_by_title`(
IN p_rule_trigger varchar(1000),
IN p_rule_title varchar(1000),
IN p_module varchar(45)
)
BEGIN

SELECT ea.* 
FROM event_rules er, event_actions ea
WHERE 	er.db_id = ea.db_rule_id
AND		er.db_del = 'No'
AND		ea.db_del = 'No'
AND		er.db_rule_title = p_rule_title 
AND		er.db_rule_trigger = p_rule_trigger
AND		er.db_module = p_module
AND		er.db_enabled = 'Yes'
;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `event_rule_get_all_by_trigger`(
IN p_type_id INT(11),
IN p_cat_id INT(11),
IN p_sub_cat_id INT(11),
IN p_rule_trigger varchar(1000),
IN p_module varchar(45)
)
BEGIN

SELECT ea.* 
FROM event_rules er, event_actions ea
WHERE 	er.db_id = ea.db_rule_id
AND		er.db_del = 'No'
AND		ea.db_del = 'No'
AND 	(er.db_type_id = 0 OR er.db_type_id = p_type_id)
AND 	(er.db_cat_id = 0 OR er.db_cat_id = p_cat_id)
AND 	(er.db_sub_cat_id = 0 OR er.db_sub_cat_id = p_sub_cat_id)
AND		er.db_rule_trigger = p_rule_trigger
AND		er.db_module = p_module
AND		er.db_enabled = 'Yes'
;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `graph_getCountBySubTypes`(
IN p_type varchar(100),
IN p_module varchar(500),
IN p_backTime_from VARCHAR(100),
IN p_backTime_to VARCHAR(100),
IN p_false_positive VARCHAR(3)
)
BEGIN
SELECT 	s.db_Name as db_Category, 
		count(s.db_id) as 'db_Count',
		IF( IF(COUNT(1)=0,1,COUNT(1) / i.cnt * 100) >= 1,ROUND(IF(COUNT(1)=0,1,COUNT(1) / i.cnt * 100),0) ,ROUND(IF(COUNT(1)=0,1,COUNT(1) / i.cnt * 100),1))  AS 'db_percent',
	    i.cnt  AS 'db_total_count' 
    FROM incidents i, sub_types s, incident_subtypes it, `types`
	CROSS JOIN (SELECT IF(COUNT(1)=0,0,COUNT(1)) AS cnt FROM incidents,`types` WHERE `types`.ID = incidents.db_TypeID AND `types`.`name` = p_type AND incidents.db_deleted = 'No' AND incidents.db_StartDateTime BETWEEN p_backTime_from AND p_backTime_to) i
    WHERE 	i.db_ID = it.db_ERID
			AND s.db_ID = it.db_SubTypeID
			AND (i.db_deleted = 'No')
            AND (it.db_del = 'No') 
            AND `types`.id = i.db_TypeID 
			AND `types`.`Module` = p_module 
            AND `types`.`name` = p_type 
            AND i.db_StartDateTime BETWEEN p_backTime_from AND p_backTime_to
			AND i.db_StartDateTime BETWEEN p_backTime_from AND p_backTime_to
			AND (i.db_FalsePositive_Flag = 'No' OR i.db_FalsePositive_Flag = p_false_positive)
			 
    group by s.db_Name
    order by count(s.db_id) desc
    ;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `graph_getCountBySubTypes_all`(
IN p_backTime_from VARCHAR(100),
IN p_backTime_to VARCHAR(100),
IN p_false_positive VARCHAR(3)
)
BEGIN
SELECT 	s.db_Name as db_Category, 
		count(s.db_id) as 'db_Count',
		IF( IF(COUNT(1)=0,1,COUNT(1) / i.cnt * 100) >= 1,ROUND(IF(COUNT(1)=0,1,COUNT(1) / i.cnt * 100),0) ,ROUND(IF(COUNT(1)=0,1,COUNT(1) / i.cnt * 100),1))  AS 'db_percent',
	    i.cnt  AS 'db_total_count' 
    FROM incidents i, sub_types s, incident_subtypes it
	CROSS JOIN (SELECT IF(COUNT(1)=0,0,COUNT(1)) AS cnt FROM incidents,`types` WHERE  incidents.db_deleted = 'No' AND incidents.db_StartDateTime BETWEEN p_backTime_from AND p_backTime_to) i
    WHERE 	i.db_ID = it.db_ERID
			AND s.db_ID = it.db_SubTypeID
			AND (i.db_deleted = 'No')
            AND (it.db_del = 'No')
            AND i.db_StartDateTime BETWEEN p_backTime_from AND p_backTime_to
			AND i.db_StartDateTime BETWEEN p_backTime_from AND p_backTime_to
			AND (i.db_FalsePositive_Flag = 'No' OR i.db_FalsePositive_Flag = p_false_positive)
			 
    group by s.db_Name
    order by count(s.db_id) desc
    ;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `graph_getObjectCountByTag`(
IN p_tag varchar(500),
IN p_type varchar(500),
IN p_module varchar(500),
IN p_backTime_from VARCHAR(100),
IN p_backTime_to VARCHAR(100),
IN p_false_positive VARCHAR(3)
)
BEGIN
	SELECT 	t.db_Name, 
			count(t.db_id) as 'db_count',
			IF( IF(COUNT(1)=0,1,COUNT(1) / t1.cnt * 100) >= 1,ROUND(IF(COUNT(1)=0,1,COUNT(1) / t1.cnt * 100),0) ,ROUND(IF(COUNT(1)=0,1,COUNT(1) / t1.cnt * 100),1))  AS 'db_percent',
            t1.cnt  AS 'db_total_count' 
    FROM tags t, incidents i, types tp
    CROSS JOIN (SELECT IF(COUNT(1)=0,0,COUNT(1)) AS cnt FROM incidents i, `types` t WHERE IF(p_type = 'ER', t.`group`, t.`name`) = p_type AND t.ID  = i.db_typeid  AND t.module = p_module  AND i.db_deleted = 'No' AND i.db_StartDateTime BETWEEN p_backTime_from AND p_backTime_to) t1
    WHERE t.db_GroupID = i.db_ID
    AND tp.id = i.db_typeID
    AND IF(p_type = 'ER', tp.`group`, tp.`name`) = p_type
    AND tp.module = p_module
    AND t.db_Category = p_tag 	
	AND (t.db_del = 'No') 
	AND (i.db_deleted = 'No') 
    AND i.db_StartDateTime BETWEEN p_backTime_from AND p_backTime_to
    AND (i.db_FalsePositive_Flag = 'No' OR i.db_FalsePositive_Flag = p_false_positive)
	GROUP BY lower(trim(t.db_name))
    ORDER BY count(t.db_id) desc
    LIMIT 10
    ;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `graph_getObjectCountByTag_all`(
IN p_tag varchar(500),
IN p_backTime_from VARCHAR(100),
IN p_backTime_to VARCHAR(100),
IN p_false_positive VARCHAR(3)
)
BEGIN
	SELECT 	t.db_Name, 
			count(t.db_id) as 'db_count',
			IF( IF(COUNT(1)=0,1,COUNT(1) / t1.cnt * 100) >= 1,ROUND(IF(COUNT(1)=0,1,COUNT(1) / t1.cnt * 100),0) ,ROUND(IF(COUNT(1)=0,1,COUNT(1) / t1.cnt * 100),1))  AS 'db_percent',
            t1.cnt  AS 'db_total_count' 
    FROM tags t, incidents i, types tp
    CROSS JOIN (SELECT IF(COUNT(1)=0,0,COUNT(1)) AS cnt FROM incidents i, `types` t WHERE  t.`group` = 'ER'  AND i.db_deleted = 'No' AND i.db_StartDateTime BETWEEN p_backTime_from AND p_backTime_to) t1
    WHERE t.db_GroupID = i.db_ID
    AND tp.id = i.db_typeID
    AND tp.`group` = 'ER'
    AND t.db_Category = p_tag 	
	AND (t.db_del = 'No') 
	AND (i.db_deleted = 'No') 
    AND i.db_StartDateTime BETWEEN p_backTime_from AND p_backTime_to
    AND (i.db_FalsePositive_Flag = 'No' OR i.db_FalsePositive_Flag = p_false_positive)
	GROUP BY lower(trim(t.db_name))
    ORDER BY count(t.db_id) desc
    LIMIT 10
    ;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `graph_getTrendByCategoryByMonth`(
IN p_category varchar(500)
)
BEGIN
SELECT m.id, concat(left(m.`name`,3),' ',right(YEAR(i.db_startdatetime),2)) AS db_field,  COUNT(i.db_ID)  AS db_count
FROM  categories, months m
	LEFT join incidents i ON MonthName(i.db_startdatetime) = m.`name`
WHERE ((i.db_CategoryID = categories.id AND categories.`name` = p_category AND db_deleted = 'No') AND (YEAR(i.db_startdatetime) = (YEAR(now())-1))AND(m.id>month(now())))
	OR((i.db_CategoryID = categories.id AND categories.`name` = p_category AND db_deleted = 'No') AND (YEAR(i.db_startdatetime)=YEAR(now()))AND(m.id<=month(now())))
GROUP BY 1
ORDER BY YEAR(i.db_startdatetime), m.id
;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `graph_getTrendByCategoryByMonth_Compare`(
IN p_category varchar(500)
)
BEGIN
 
SELECT m.id, concat(left(m.`name`,3),' ',right(IF(m.id>MONTH(now()),YEAR(now())-1,YEAR(now())),2)) AS db_Current,
 (Select count(*) from  incidents i, categories c Where i.db_CategoryID = c.id AND c.`name` = p_category AND i.db_deleted = 'No' AND i.db_deleted = 'No' AND YEAR(i.db_startdatetime)  = IF(MONTH(i.db_startdatetime)>MONTH(now()),YEAR(now())-1,YEAR(now())) AND MONTH(i.db_startdatetime) = m.ID) as db_Count_Current,
 concat(left(m.`name`,3),' ',right(IF(m.id>MONTH(now()),YEAR(now())-2,YEAR(now())-1),2)) AS db_Previous,
 (Select count(*) from  incidents i, categories c Where i.db_CategoryID = c.id AND c.`name` = p_category AND i.db_deleted = 'No' AND i.db_deleted = 'No' AND YEAR(i.db_startdatetime)  = IF(MONTH(i.db_startdatetime)>MONTH(now()),YEAR(now())-2,YEAR(now())-1) AND MONTH(i.db_startdatetime) = m.ID) as db_Count_Previous,
 IF(m.id>MONTH(now()),YEAR(now())-1,YEAR(now())) as db_year
FROM  months m 
	 
GROUP BY m.id
ORDER BY db_year, m.id
     
 ;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `graph_getTrendByCategoryByQuarter`(
IN p_category varchar(500)
)
BEGIN
SELECT q.id, concat(left(q.`name`,2),'-',right(YEAR(i.db_startdatetime),2)) AS db_field,  COUNT(i.db_ID)  AS db_count
FROM  categories,quarters q
LEFT join incidents i ON concat('Q',QUARTER(i.db_startdatetime)) = q.`name`
where (((i.db_CategoryID = categories.id AND categories.`name` = p_category AND (db_deleted = 'No')) AND (YEAR(i.db_startdatetime) = (YEAR(now())-1))AND(q.id>QUARTER(now())))
OR(((i.db_CategoryID = categories.id AND categories.`name` = p_category AND (db_deleted = 'No')) AND (YEAR(i.db_startdatetime)=YEAR(now()))AND(q.id<=QUARTER(now())))))
GROUP BY 1
order by YEAR(i.db_startdatetime), q.id;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `graph_getTrendByCategoryByQuarter_Compare`(
IN p_category varchar(500)
)
BEGIN
SELECT q.id, concat(left(q.`name`,2),' ',right(IF(q.id>QUARTER(now()),YEAR(now())-1,YEAR(now())),2)) AS db_Current,
 (Select count(*) from  incidents i, categories c Where i.db_CategoryID = c.id AND c.`name` = p_category AND i.db_deleted = 'No' 
 AND i.db_deleted = 'No' 
 AND YEAR(i.db_startdatetime)  = IF(QUARTER(i.db_startdatetime)>QUARTER(now()),YEAR(now())-1,YEAR(now())) 
 AND MONTH(i.db_startdatetime) = q.ID) as db_Count_Current,
 concat(left(q.`name`,2),' ',right(IF(q.id>QUARTER(now()),YEAR(now())-2,YEAR(now())-1),2)) AS db_Previous,
 (Select count(*) from  incidents i, categories c Where i.db_CategoryID = c.id AND c.`name` = p_category AND i.db_deleted = 'No' 
 AND i.db_deleted = 'No' 
 AND YEAR(i.db_startdatetime)  = IF(QUARTER(i.db_startdatetime)>QUARTER(now()),YEAR(now())-2,YEAR(now())-1) AND QUARTER(i.db_startdatetime) = q.ID) as db_Count_Previous,
 IF(q.id>QUARTER(now()),YEAR(now())-1,YEAR(now())) as db_year  
FROM  quarters q
	 
    
      
GROUP BY q.id
ORDER BY db_year, q.id



;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `graph_getTrendByCategoryByYear`(
	IN p_category varchar(50)
)
BEGIN
	SELECT year(db_startdatetime) AS db_Current, COUNT(db_ID) AS db_count
	FROM  incidents, categories
	where (incidents.db_CategoryID = categories.id) AND (categories.`name` = p_category) AND (db_deleted = 'No')
	GROUP BY YEAR(db_startdatetime);
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `graph_getTrendByCategoryByYear_Compare`(
IN p_category varchar(500),
IN p_start_year INT(11)
)
BEGIN
SELECT y.`name` AS db_Current, ifnull(count(ii.db_id),0) as db_Count_Current, ifnull(count(iii.db_id),0) as db_Count_Previous
FROM  years y
	LEFT join (
		Select * from  incidents i, categories c
        Where i.db_CategoryID = c.id AND c.`name` = p_category AND i.db_deleted = 'No'
        AND i.db_deleted = 'No' AND YEAR(i.db_startdatetime)  = IF(YEAR(i.db_startdatetime)>YEAR(now()),YEAR(now())-1,YEAR(now()))
    ) ii ON YEAR(ii.db_startdatetime) = y.`name`
    LEFT join (
		Select * from  incidents i, categories c
        Where i.db_CategoryID = c.id AND c.`name` = p_category AND i.db_deleted = 'No'
        AND i.db_deleted = 'No' AND YEAR(i.db_startdatetime)  = IF(YEAR(i.db_startdatetime)>YEAR(now()),YEAR(now())-2,YEAR(now())-1)
    ) iii ON YEAR(iii.db_startdatetime) = y.`name`
    
    WHERE y.`name` >= p_start_year AND y.`name` <= YEAR(now())

GROUP BY y.`name`
order by y.`name`
;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`appuser`@`localhost` PROCEDURE `graph_getTrendByGroupByMonth`(
	IN p_type varchar(50)
)
BEGIN
SELECT concat(left(m.`name`,3),' ',right(YEAR(i.db_startdatetime),2)) AS db_field,  COUNT(i.db_ID)  AS db_count
FROM  `types`, months m
LEFT join incidents i ON MonthName(i.db_startdatetime) = m.`name`
where  ((i.db_typeID = `types`.id AND `types`.`group` = p_type AND (db_deleted = 'No') AND YEAR(i.db_startdatetime) = (YEAR(now())-1))AND(m.id>month(now())))
OR((i.db_typeID = `types`.id AND `types`.`group` = p_type AND (db_deleted = 'No') AND YEAR(i.db_startdatetime)=YEAR(now()))AND(m.id<=month(now())))
GROUP BY 1,YEAR(i.db_startdatetime)
ORDER BY YEAR(i.db_startdatetime), m.id;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`appuser`@`localhost` PROCEDURE `graph_getTrendByGroupByQuarterAll`(
IN p_group varchar(500)
)
BEGIN
SELECT q.id, concat(left(q.`name`,2),'-',right(YEAR(i.db_startdatetime),2)) AS db_field,  COUNT(i.db_ID)  AS db_count
FROM  `types`,quarters q
LEFT join incidents i ON concat('Q',QUARTER(i.db_startdatetime)) = q.`name`

where (((i.db_typeID = `types`.id AND `types`.`group` = p_group AND (db_deleted = 'No')) AND (YEAR(i.db_startdatetime) = (YEAR(now())-1))AND(q.id>QUARTER(now())))
OR(((i.db_typeID = `types`.id AND `types`.`group` = p_group AND (db_deleted = 'No')) AND (YEAR(i.db_startdatetime)=YEAR(now()))AND(q.id<=QUARTER(now())))))
GROUP BY 1
order by YEAR(i.db_startdatetime), q.id;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`appuser`@`localhost` PROCEDURE `graph_getTrendByGroupByYearAll`(
IN p_group varchar(500)
)
BEGIN
SELECT year(db_startdatetime) AS db_field, COUNT(db_ID) AS db_count
FROM  incidents, `types`
where (incidents.db_TypeID = `types`.id) AND (`types`.`group` = p_group) AND (db_deleted = 'No')
GROUP BY YEAR(db_startdatetime)
;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `graph_getTrendBySubCategoryByMonth_Compare`(
IN p_sub_category varchar(500)
)
BEGIN
 
SELECT m.id, concat(left(m.`name`,3),' ',right(IF(m.id>MONTH(now()),YEAR(now())-1,YEAR(now())),2)) AS db_Current,
 (Select count(*) from  incidents i, subcategories c Where i.db_SubCategoryID = c.id AND c.`name` = p_sub_category AND i.db_deleted = 'No' AND i.db_deleted = 'No' AND YEAR(i.db_startdatetime)  = IF(MONTH(i.db_startdatetime)>MONTH(now()),YEAR(now())-1,YEAR(now())) AND MONTH(i.db_startdatetime) = m.ID) as db_Count_Current,
 concat(left(m.`name`,3),' ',right(IF(m.id>MONTH(now()),YEAR(now())-2,YEAR(now())-1),2)) AS db_Previous,
 (Select count(*) from  incidents i, subcategories c Where i.db_SubCategoryID = c.id AND c.`name` = p_sub_category AND i.db_deleted = 'No' AND i.db_deleted = 'No' AND YEAR(i.db_startdatetime)  = IF(MONTH(i.db_startdatetime)>MONTH(now()),YEAR(now())-2,YEAR(now())-1) AND MONTH(i.db_startdatetime) = m.ID) as db_Count_Previous,
 IF(m.id>MONTH(now()),YEAR(now())-1,YEAR(now())) as db_year
FROM  months m 
	 
GROUP BY m.id
ORDER BY db_year, m.id
     
 ;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `graph_getTrendBySubCategoryByQuarter_Compare`(
IN p_sub_category varchar(500)
)
BEGIN
SELECT q.id, concat(left(q.`name`,2),' ',right(IF(q.id>QUARTER(now()),YEAR(now())-1,YEAR(now())),2)) AS db_Current,
 (Select count(*) from  incidents i, subcategories c Where i.db_subCategoryID = c.id AND c.`name` = p_sub_category AND i.db_deleted = 'No' 
 AND i.db_deleted = 'No' 
 AND YEAR(i.db_startdatetime)  = IF(QUARTER(i.db_startdatetime)>QUARTER(now()),YEAR(now())-1,YEAR(now())) 
 AND MONTH(i.db_startdatetime) = q.ID) as db_Count_Current,
 concat(left(q.`name`,2),' ',right(IF(q.id>QUARTER(now()),YEAR(now())-2,YEAR(now())-1),2)) AS db_Previous,
 (Select count(*) from  incidents i, subcategories c Where i.db_subCategoryID = c.id AND c.`name` = p_sub_category AND i.db_deleted = 'No' 
 AND i.db_deleted = 'No' 
 AND YEAR(i.db_startdatetime)  = IF(QUARTER(i.db_startdatetime)>QUARTER(now()),YEAR(now())-2,YEAR(now())-1) AND QUARTER(i.db_startdatetime) = q.ID) as db_Count_Previous,
 IF(q.id>QUARTER(now()),YEAR(now())-1,YEAR(now())) as db_year  
FROM  quarters q
	 
    
      
GROUP BY q.id
ORDER BY db_year, q.id



;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `graph_getTrendBySubCategoryByYear`(
	IN p_sub_category varchar(50)
)
BEGIN
	SELECT year(db_startdatetime) AS db_Current, COUNT(db_ID) AS db_count
	FROM  incidents, subcategories
	where (incidents.db_SubCategoryID = subcategories.id) AND (subcategories.`name` = p_sub_category) AND (db_deleted = 'No')
	GROUP BY YEAR(db_startdatetime);
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`appuser`@`localhost` PROCEDURE `graph_getTrendByTypeByMonth`(
	IN p_type varchar(50)
)
BEGIN
SELECT m.id, concat(left(m.`name`,3),' ',right(YEAR(i.db_startdatetime),2)) AS db_field,  COUNT(i.db_ID)  AS db_count
FROM  `types`, months m
	LEFT join incidents i ON MonthName(i.db_startdatetime) = m.`name`
WHERE ((i.db_typeID = `types`.id AND `types`.`name` = p_type AND db_deleted = 'No' ) AND (YEAR(i.db_startdatetime) = (YEAR(now())-1))AND(m.id>month(now())))
	OR((i.db_typeID = `types`.id AND `types`.`name` = p_type AND db_deleted = 'No' ) AND (YEAR(i.db_startdatetime)=YEAR(now()))AND(m.id<=month(now())))
GROUP BY 1
ORDER BY YEAR(i.db_startdatetime), m.id
;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`appuser`@`localhost` PROCEDURE `graph_getTrendByTypeByMonth_Compare`(
IN p_type varchar(500)
)
BEGIN

SELECT m.id, concat(left(m.`name`,3),' ',right(IF(m.id>MONTH(now()),YEAR(now())-1,YEAR(now())),2)) AS db_Current,
 (Select count(*) from  incidents i, `types` t Where i.db_typeID = t.id AND t.`name` = p_type AND i.db_deleted = 'No' AND i.db_deleted = 'No' AND YEAR(i.db_startdatetime)  = IF(MONTH(i.db_startdatetime)>MONTH(now()),YEAR(now())-1,YEAR(now())) AND MONTH(i.db_startdatetime) = m.ID) as db_Count_Current,
 concat(left(m.`name`,3),' ',right(IF(m.id>MONTH(now()),YEAR(now())-2,YEAR(now())-1),2)) AS db_Previous,
 (Select count(*) from  incidents i, `types` t Where i.db_typeID = t.id AND t.`name` = p_type AND i.db_deleted = 'No' AND i.db_deleted = 'No' AND YEAR(i.db_startdatetime)  = IF(MONTH(i.db_startdatetime)>MONTH(now()),YEAR(now())-2,YEAR(now())-1) AND MONTH(i.db_startdatetime) = m.ID) as db_Count_Previous,
 IF(m.id>MONTH(now()),YEAR(now())-1,YEAR(now())) as db_year
FROM  months m 
	 
    
     
GROUP BY m.id
ORDER BY db_year, m.id
;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`appuser`@`localhost` PROCEDURE `graph_getTrendByTypeByQuarter`(
IN p_type varchar(500)
)
BEGIN
SELECT q.id, concat(left(q.`name`,2),' ',right(IF(q.id>QUARTER(now()),YEAR(now())-1,YEAR(now())),2)) AS db_Current,
 (Select count(*) from  incidents i, `types` t Where i.db_typeID = t.id AND t.`name` = p_type AND i.db_deleted = 'No' 
 AND i.db_deleted = 'No' 
 AND YEAR(i.db_startdatetime)  = IF(QUARTER(i.db_startdatetime)>QUARTER(now()),YEAR(now())-1,YEAR(now())) 
 AND MONTH(i.db_startdatetime) = q.ID) as db_Count_Current,
 concat(left(q.`name`,2),' ',right(IF(q.id>QUARTER(now()),YEAR(now())-2,YEAR(now())-1),2)) AS db_Previous,
 (Select count(*) from  incidents i, `types` t Where i.db_typeID = t.id AND t.`name` = p_type AND i.db_deleted = 'No' 
 AND i.db_deleted = 'No' 
 AND YEAR(i.db_startdatetime)  = IF(QUARTER(i.db_startdatetime)>QUARTER(now()),YEAR(now())-2,YEAR(now())-1) AND QUARTER(i.db_startdatetime) = q.ID) as db_Count_Previous,
 IF(q.id>QUARTER(now()),YEAR(now())-1,YEAR(now())) as db_year
FROM  quarters q
	 
    
      
GROUP BY q.id
ORDER BY db_year, q.id
;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`appuser`@`localhost` PROCEDURE `graph_getTrendByTypeByQuarter_Compare`(
IN p_type varchar(500)
)
BEGIN
SELECT q.id, concat(left(q.`name`,2),' ',right(IF(q.id>QUARTER(now()),YEAR(now())-1,YEAR(now())),2)) AS db_Current,
 (Select count(*) from  incidents i, `types` t Where i.db_typeID = t.id AND t.`name` = p_type AND i.db_deleted = 'No' 
 AND i.db_deleted = 'No' 
 AND YEAR(i.db_startdatetime)  = IF(QUARTER(i.db_startdatetime)>QUARTER(now()),YEAR(now())-1,YEAR(now())) 
 AND MONTH(i.db_startdatetime) = q.ID) as db_Count_Current,
 concat(left(q.`name`,2),' ',right(IF(q.id>QUARTER(now()),YEAR(now())-2,YEAR(now())-1),2)) AS db_Previous,
 (Select count(*) from  incidents i, `types` t Where i.db_typeID = t.id AND t.`name` = p_type AND i.db_deleted = 'No' 
 AND i.db_deleted = 'No' 
 AND YEAR(i.db_startdatetime)  = IF(QUARTER(i.db_startdatetime)>QUARTER(now()),YEAR(now())-2,YEAR(now())-1) AND QUARTER(i.db_startdatetime) = q.ID) as db_Count_Previous,
 IF(q.id>QUARTER(now()),YEAR(now())-1,YEAR(now())) as db_year
FROM  quarters q
	 
    
      
GROUP BY q.id
ORDER BY db_year, q.id
;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`appuser`@`localhost` PROCEDURE `graph_getTrendByTypeByYear`(
	IN p_type varchar(50)
)
BEGIN
	SELECT year(db_startdatetime) AS db_Current, COUNT(db_ID) AS db_count
	FROM  incidents, `types`
	where (incidents.db_TypeID = `types`.id) AND (`types`.`name` = p_type) AND (db_deleted = 'No')
	GROUP BY YEAR(db_startdatetime)
     ORDER BY db_Current
    ;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`appuser`@`localhost` PROCEDURE `graph_getTrendByTypeByYear_Compare`(
IN p_type varchar(500),
IN p_start_year INT(11)
)
BEGIN
SELECT y.`name` AS db_Current,ifnull(count(ii.db_id),0) as db_Count_Current, ifnull(count(iii.db_id),0) as db_Count_Previous
FROM  years y
	LEFT join (
		Select * from  incidents i, `types` t
        Where i.db_typeID = t.id AND t.`name` = p_type AND i.db_deleted = 'No'
    ) ii ON YEAR(ii.db_startdatetime) = (y.`name`)
    LEFT join (
		Select * from  incidents i, `types` t
        Where i.db_typeID = t.id AND t.`name` = p_type AND i.db_deleted = 'No'
    ) iii ON YEAR(iii.db_startdatetime) = (2018 - 1)
    

    WHERE y.`name` >= p_start_year AND y.`name` <= YEAR(now())

GROUP BY y.`name`
order by y.`name`
;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `graph_top_iocs_assets`(
IN p_module VARCHAR(100),
IN p_backTime_from VARCHAR(100),
IN p_backTime_to VARCHAR(100),
IN p_false_positive VARCHAR(3),
IN p_mode VARCHAR(50),
IN p_type VARCHAR(100)
)
BEGIN
SELECT db_Value,IFNULL(count(db_Value),0) as db_count
FROM incident_ioc ioc, incidents ii, `types` ty
WHERE ioc.db_erid = ii.db_id
AND ty.id = ii.db_typeid
AND ty.module = p_module
AND ty.DisplayName_2 = p_type
AND ii.db_deleted = 'No'                
AND ioc.db_del = 'No'
AND ioc.db_mode = p_mode
AND ii.db_StartDateTime BETWEEN p_backTime_from AND p_backTime_to
AND (ii.db_FalsePositive_Flag = 'No' OR ii.db_FalsePositive_Flag = p_false_positive)
GROUP BY ioc.db_value
ORDER BY db_count DESC
LIMIT 10
;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `graph_top_iocs_assets_all`(
IN p_backTime_from VARCHAR(100),
IN p_backTime_to VARCHAR(100),
IN p_false_positive VARCHAR(3),
IN p_mode VARCHAR(50)
)
BEGIN
SELECT db_Value,IFNULL(count(db_Value),0) as db_count
FROM incident_ioc ioc, incidents ii
WHERE ioc.db_erid = ii.db_id
AND ii.db_deleted = 'No'                
AND ioc.db_del = 'No'
AND ioc.db_mode = p_mode
AND ii.db_StartDateTime BETWEEN p_backTime_from AND p_backTime_to
AND (ii.db_FalsePositive_Flag = 'No' OR ii.db_FalsePositive_Flag = p_false_positive)
GROUP BY ioc.db_value
ORDER BY db_count DESC
LIMIT 10
;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `grc_sama_csf_get_all`()
BEGIN

SELECT 	s.*, 
		u.db_FullName as db_User, 
		DATE_FORMAT(s.db_last_update,'%d-%m-%Y %h:%i %p') as 'db_last_update_formated',
        DATE_FORMAT(s.db_target_date,'%d-%m-%Y') as 'db_target_date_formated'
        FROM sama_csf s 
        LEFT JOIN users u on s.db_user_id = u.db_ID
        WHERE 	s.db_del = 'No'
        ORDER BY db_number    

;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `grc_sama_csf_get_by_module`(
IN p_module VARCHAR(45)

)
BEGIN

SELECT 	s.*, 
		u.db_FullName as db_User, 
		DATE_FORMAT(s.db_last_update,'%d-%m-%Y %h:%i %p') as 'db_last_update_formated',
        DATE_FORMAT(s.db_target_date,'%d-%m-%Y') as 'db_target_date_formated'
        FROM sama_csf s 
        LEFT JOIN users u on s.db_user_id = u.db_ID
        WHERE 	s.db_del = 'No'
        AND s.db_module = p_module
        ORDER BY db_number

;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `insertER`(
 
IN p_StartDateTime VARCHAR(30),
IN p_Title VARCHAR(200),
IN p_Severity VARCHAR(50),
IN p_InitiatorID INT(11),
IN p_ManagerID INT(11),
IN p_CategoryID INT(11),
IN p_TypeID INT(11),
IN p_SubCategoryID INT(11),
IN p_Reference VARCHAR(50),
OUT p_id INT(11)
)
BEGIN
 INSERT INTO incidents
(
db_StartDateTime,
db_Title,
db_Severity,
db_InitiatorID,
db_ManagerID,
db_CategoryID,
db_TypeID,
db_SubCategoryID,
db_Reference,
db_Status
)
VALUES
(
p_StartDateTime,
p_Title,
p_Severity,
p_InitiatorID,
p_ManagerID,
p_CategoryID,
p_TypeID,
p_SubCategoryID,
p_Reference,
'Open'
);
SET p_id = last_insert_id();
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `insertEvidence`(

IN p_Number VARCHAR(45),
IN p_CollectionDate VARCHAR(30),
IN p_CollectedBy VARCHAR(500),
IN p_Type VARCHAR(45),
IN p_StorageLocation VARCHAR(1000),
IN p_Notes longtext,
IN p_Description VARCHAR(5000),
IN p_CollectedFrom VARCHAR(45),
IN p_UserID int(11),
IN p_ERID int(11),
IN p_Attachment VARCHAR(50),
OUT p_id INT(11)

)
BEGIN

INSERT INTO `evidences`
(
`db_Number`,
`db_CollectionDate`,
`db_CollectedBy`,
`db_Type`,
`db_StorageLocation`,
`db_Notes`,
`db_Description`,
`db_CollectedFrom`,
`db_UserID`,
`db_ERID`,
`db_Attachment`
)
VALUES
(
p_Number,
p_CollectionDate,
p_CollectedBy,
p_Type,
p_StorageLocation,
p_Notes,
p_Description,
p_CollectedFrom,
p_UserID,
p_ERID,
p_Attachment
);
SET p_id = last_insert_id();

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `ioc_getAllByERID`(
IN p_id INT(11)
)
BEGIN


SELECT t.*,
	IFNULL((select count(ioc.db_ID) FROM incident_ioc ioc,incidents i,`types` ty where ty.id = i.db_TypeID AND ioc.db_ERID = i.db_ID AND ioc.db_name = t.db_name AND  db_value = t.db_value AND db_Del = 'No' AND i.db_Deleted = 'No' AND ty.Module = 'simp' Group by ioc.db_value ),0)  as db_IR_Hits,
	IFNULL((select count(ioc.db_ID) FROM incident_ioc ioc,incidents i,`types` ty where ty.id = i.db_TypeID AND ioc.db_ERID = i.db_ID AND ioc.db_name = t.db_name AND  db_value = t.db_value AND db_Del = 'No' AND i.db_Deleted = 'No' AND ty.Module = 'stmp' Group by ioc.db_value),0)  as db_Threat_Hits,
	IFNULL((select count(ioc.db_ID) FROM incident_ioc ioc,incidents i,`types` ty where ty.id = i.db_TypeID AND ioc.db_ERID = i.db_ID AND ioc.db_name = t.db_name AND  db_value = t.db_value AND db_Del = 'No' AND i.db_Deleted = 'No' AND ty.Module = 'scmp' Group by ioc.db_value ),0)  as db_Case_Hits,
    IFNULL((select count(ioc.db_ID) FROM incident_ioc ioc,incidents i,`types` ty where ty.id = i.db_TypeID AND ioc.db_ERID = i.db_ID AND ioc.db_name = t.db_name AND  db_value = t.db_value AND db_Del = 'No' AND i.db_Deleted = 'No' AND ty.Module = 'ctsp' Group by ioc.db_value ),0)  as db_Share_Hits,
     IFNULL((select group_concat(concat(db_id,'$',db_name,'$',db_Category,'$',db_private_tag) SEPARATOR '|') from tags where db_ChildGroup = 'IOC' and db_ChildGroupID = t.db_ID and db_Del = 'No'),'')  as db_IOC_Tags
FROM incident_ioc t
WHERE t.db_ERID = p_id
	AND t.db_Del = 'No'
    AND t.db_Mode = 'IOC'
ORDER BY t.db_ID DESC    
    ;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `ioc_getAllByERID_ByProfile_ByGroup`(
IN p_id INT(11),
IN p_profile VARCHAR(500),
IN p_group VARCHAR(500)
)
BEGIN
 
SELECT t.*,
	IFNULL((select count(ioc.db_ID) FROM incident_ioc ioc,incidents i,`types` ty,users u,user_profiles up where ty.id = i.db_TypeID AND ioc.db_ERID = i.db_ID AND i.db_ManagerID = u.db_id AND u.db_UserProfileID = up.id AND up.name = p_profile AND u.db_group = p_group AND ioc.db_name = t.db_name AND  db_value = t.db_value AND ioc.db_Del = 'No' AND i.db_Deleted = 'No' AND ty.Module = 'simp' Group by ioc.db_value ),0)  as db_IR_Hits,
	IFNULL((select count(ioc.db_ID) FROM incident_ioc ioc,incidents i,`types` ty,users u,user_profiles up where ty.id = i.db_TypeID AND ioc.db_ERID = i.db_ID AND i.db_ManagerID = u.db_id AND u.db_UserProfileID = up.id AND up.name = p_profile AND u.db_group = p_group AND ioc.db_name = t.db_name AND  db_value = t.db_value AND ioc.db_Del = 'No' AND i.db_Deleted = 'No' AND ty.Module = 'stmp' Group by ioc.db_value),0)  as db_Threat_Hits,
	IFNULL((select count(ioc.db_ID) FROM incident_ioc ioc,incidents i,`types` ty,users u,user_profiles up where ty.id = i.db_TypeID AND ioc.db_ERID = i.db_ID AND i.db_ManagerID = u.db_id AND u.db_UserProfileID = up.id AND up.name = p_profile AND u.db_group = p_group AND ioc.db_name = t.db_name AND  db_value = t.db_value AND ioc.db_Del = 'No' AND i.db_Deleted = 'No' AND ty.Module = 'scmp' Group by ioc.db_value ),0)  as db_Case_Hits,
	IFNULL((select group_concat(concat(db_id,'$',db_name,'$',db_Category) SEPARATOR '|') from tags where tags.db_ChildGroup = 'IOC' and tags.db_ChildGroupID = t.db_ID and tags.db_Del = 'No'),'')  as db_IOC_Tags

FROM incident_ioc t
 
WHERE t.db_ERID = p_ID 
	AND t.db_Del = 'No'
    AND t.db_Mode = 'IOC'
    
    

ORDER BY t.db_ID DESC    
    ;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `ioc_get_count_by_module`(
IN p_module varchar(50)
)
BEGIN
SELECT count(ioc.db_id)  as db_count
FROM incident_ioc ioc, incidents i, `types` t
WHERE ioc.db_ERID = i.db_id
AND i.db_typeid = t.id
AND t.module = p_module
AND ioc.db_Del = 'No'
AND ioc.db_Mode = 'IOC' 
    
    ;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `ioc_get_count_community`()
BEGIN
SELECT i.db_id  as db_count
FROM incident_ioc i
WHERE  i.db_Del = 'No'
    AND i.db_Mode = 'IOC' 
    ;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `ioc_get_recent_items`(
IN p_name varchar(500),
IN p_module varchar(50)
)
BEGIN
SELECT distinct ioc.db_value as v1, ioc.db_geo v2, i.db_severity v3, ioc.db_EntryDate
FROM incident_ioc ioc, incidents i, `types` t
WHERE ioc.db_ERID = i.db_id
AND i.db_typeid = t.id
AND t.module = p_module
AND ioc.db_Del = 'No'
AND ioc.db_Mode = 'IOC' 
AND ioc.db_Name LIKE concat(p_name,'%')
ORDER BY ioc.db_EntryDate DESC 
LIMIT 8
;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `ioc_insertImportedIOCs`(
IN p_Name longtext,
IN p_Value  longtext,
IN p_VT longtext,
IN p_ExternalHits VARCHAR(500),
IN p_ERID INT(11),
IN p_Operator VARCHAR(45),
IN p_Mode VARCHAR(45),
OUT p_ID INT(11),
IN p_AV longtext,
IN p_ThreatLevel INT(11)


)
BEGIN
INSERT INTO incident_ioc (
db_Name,
db_Value,
db_ERID,
db_VT,
db_ExternalHits,
db_Operator,
db_Mode,
db_VT_AV_Info,
db_ThreatLevel
) 
VALUES (
TRIM(p_Name),
TRIM(p_Value),
p_ERID,
p_VT,
p_ExternalHits,
p_Operator,
p_Mode,
p_AV,
p_ThreatLevel
);

SET p_id = last_insert_id();

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `ioc_insertIOCs`(
IN p_Name longtext,
IN p_Value  longtext,
IN p_VT longtext,
IN p_ExternalHits VARCHAR(500),
IN p_ERID INT(11),
IN p_Mode VARCHAR(50),
OUT p_ID INT(11),
IN p_AV longtext,
IN p_ThreatLevel INT(11)


)
BEGIN
INSERT INTO incident_ioc (
db_Name,
db_Value,
db_ERID,
db_VT,
db_ExternalHits,
db_Mode,
db_VT_AV_Info,
db_ThreatLevel

) 
VALUES (
TRIM(p_Name),
TRIM(p_Value),
p_ERID,
p_VT,
p_ExternalHits,
p_Mode,
p_AV,
p_ThreatLevel
);

SET p_id = last_insert_id();

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `maintenance_daily_cleanup_just_for_record`()
BEGIN
-- CREATE EVENT daily_cleanup 
-- ALTER EVENT daily_cleanup 
-- ON SCHEDULE EVERY 1 DAY
-- STARTS '2020-01-18 01:00:00'
-- DO
-- 	   DELETE FROM security_logs WHERE  LogDate < (now() - Interval 3 month);
--     DELETE FROM incidents WHERE db_Deleted = 'Yes' AND  db_LastUpdate < (now() - Interval 3 month);
--     DELETE FROM activity_logs WHERE db_Del = 'Yes' AND  db_LogDate < (now() - Interval 3 month);
-- 	   DELETE FROM custom_attributes WHERE db_Del = 'Yes' AND  db_EntryDate < (now() - Interval 3 month);
--     DELETE FROM evidences WHERE db_Del = 'Yes' AND  db_Date < (now() - Interval 3 month);
-- 	   DELETE FROM handover WHERE db_Del = 'Yes' AND  db_Date < (now() - Interval 3 month);
--     DELETE FROM incident_ioc WHERE db_Del = 'Yes' AND  db_LastUpdate < (now() - Interval 3 month);
--     DELETE FROM incident_subtypes WHERE db_Del = 'Yes' AND  db_EntryDate < (now() - Interval 3 month);
--     DELETE FROM shifts WHERE db_Del = 'Yes';
--     DELETE FROM shifts_posts WHERE db_Del = 'Yes' AND  db_EntryDate < (now() - Interval 3 month);
--     DELETE FROM tags WHERE db_Del = 'Yes';
--     DELETE FROM tasks WHERE db_Del = 'Yes' AND  db_EntryDate < (now() - Interval 3 month);
--     DELETE FROM tasks_d WHERE db_Del = 'Yes';
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `new_customer_fresh_database`(
 
)
BEGIN
 
delete FROM dbname.ctivity_logs;
delete from dbname.case_triggers;
delete from dbname.custom_attributes;
delete from dbname.evidences;
delete from dbname.handover;
delete from dbname.incident_ioc;
delete from dbname.incidents;
delete from dbname.incident_subtypes;
delete from dbname.reminders;
delete from dbname.security_logs;
delete from dbname.shifts_posts;
delete from dbname.tags;
delete from dbname.tasks_d;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `orchestrator_add_log`(
IN p_job_title varchar(500),
IN p_job_start varchar(100),
IN p_job_end varchar(100),
IN p_job_output longtext,
IN p_job_delta varchar(100)
)
BEGIN

INSERT INTO `orchestrator_logs`
( 
`db_job_title`,
`db_job_start`,
`db_job_end`,
`db_job_output`,
`db_job_duration`
)
VALUES
(
p_job_title,
p_job_start,
p_job_end,
p_job_output,
p_job_delta
)
;


END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `orchestrator_callJobs`()
BEGIN
Update q_main_base.orchestrator_jobs set db_Job_Current_Status = 'Ready' Where db_Job_Current_Status = 'Running' AND TIMESTAMPDIFF(minute, db_Job_Last_Time_Run, now()) > 10;
SELECT * FROM orchestrator_jobs WHERE db_Job_Enabled = 'Yes' AND db_user_soar = 'No';
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `orchestrator_updateCallJobs`(

	IN p_ID INT(11),
    IN p_Job_Last_Time_Run TIMESTAMP,
	IN p_Job_Last_Time_Run_Length BIGINT(20),
    IN p_Job_Total_Run_Count_Success INT(11),
    IN p_Job_Total_Run_Count_Failure INT(11),
	IN p_Job_Last_Time_Run_Status longtext, 
    IN p_Job_Current_Status  longtext,
    IN p_Job_API_URL_Response_Output longtext
    
)
BEGIN

UPDATE orchestrator_jobs
	set
	db_Job_Last_Time_Run = p_Job_Last_Time_Run,
	db_Job_Last_Time_Run_Length = p_Job_Last_Time_Run_Length,
	db_Job_Total_Run_Count = db_Job_Total_Run_Count + 1,
	db_Job_Total_Run_Count_Success = db_Job_Total_Run_Count_Success + p_Job_Total_Run_Count_Success,
	db_Job_Total_Run_Count_Failure = db_Job_Total_Run_Count_Failure + p_Job_Total_Run_Count_Failure,
    db_Job_Last_Time_Run_Status = p_Job_Last_Time_Run_Status,
    db_Job_Current_Status = p_Job_Current_Status,
    db_Job_API_URL_Response_Output = p_Job_API_URL_Response_Output
    Where db_ID = p_ID;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `playbook_getAllByModule`(
IN p_module VARCHAR(50)
)
BEGIN

SELECT p.*, c.name as 'db_cat_name', sc.name as 'db_sub_cat_name', u.db_FullName as 'db_owner', DATE_FORMAT(p.db_last_update,'%d-%m-%Y %h:%i %p') as 'db_last_update_formated'
FROM playbook p, categories c,  subcategories sc, users u 
WHERE p.db_del = 'No'
AND p.db_cat_id = c.id 
AND p.db_sub_cat_id = sc.id
AND p.db_owner_id = u.db_id 
AND p.db_module = p_module;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `playbook_getPlaybookDetails_ByCat_BySubCat`(
IN p_cat_id INT(11),
IN p_sub_cat_id INT(11),
IN p_erid INT(11),
IN p_module VARCHAR(45),
IN p_use_case_id INT(11)
)
BEGIN

SELECT pd.*, u.db_FullName as 'db_owner',IFNULL(ipa.db_completed,false) as db_completed, IFNULL(ipn.db_notes,'') as db_notes , s.db_Phase as db_Phase, DATE_FORMAT(pd.db_last_update,'%d-%m-%Y %h:%i %p') as 'db_last_update_formated'
FROM playbook_d pd
LEFT JOIN incident_playbook_actions ipa on pd.db_id = ipa.db_playbook_action_id and ipa.db_ERID = p_erid
LEFT JOIN incident_playbook_notes ipn on pd.db_id = ipn.db_playbook_action_id and ipn.db_ERID = p_erid
, playbook p, users u,standards s
WHERE pd.db_del = 'No'
AND p.db_module = p_module
AND pd.db_playbook_id = p.db_id 
AND pd.db_owner_id = u.db_id  
AND pd.db_phase_id = s.db_id 
AND (  ((p.db_cat_id= p_cat_id) AND (p.db_sub_cat_id = p_sub_cat_id))
	OR ((p.db_cat_id= p_cat_id) AND (p.db_sub_cat_id = '1'))
    OR ((p.db_cat_id= '1') AND (p.db_sub_cat_id = '1'))
)
AND (p.db_use_case_id = p_use_case_id)
ORDER BY p.db_priority,pd.db_order
 
;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `playbook_getPlaybookDetails_ByCat_BySubCat_ByPhase`(
IN p_cat_id INT(11),
IN p_sub_cat_id INT(11),
IN p_erid INT(11),
IN p_phase_id INT(11)
)
BEGIN

SELECT pd.*, u.db_FullName as 'db_owner',IFNULL(ia.db_completed,false) as db_completed , s.db_Phase as db_Phase, DATE_FORMAT(pd.db_last_update,'%d-%m-%Y %h:%i %p') as 'db_last_update_formated'
FROM playbook_d pd
LEFT JOIN incident_playbook_actions ia on pd.db_id = ia.db_playbook_action_id and ia.db_ERID = p_erid
, playbook p, users u,standards s
WHERE pd.db_del = 'No'
AND pd.db_playbook_id = p.db_id 
AND pd.db_owner_id = u.db_id 
AND pd.db_phase_id = s.db_id 
AND p.db_cat_id= p_cat_id 
AND p.db_sub_cat_id= p_sub_cat_id
AND pd.db_phase_id = s.db_id
AND pd.db_phase_id = p_phase_id
ORDER BY pd.db_order
 
;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `playbook_getPlaybookDetailsByID`(
IN p_id INT(11)
)
BEGIN

SELECT pd.*, u.db_FullName as 'db_owner',IFNULL(ipa.db_completed,false) as db_completed ,IFNULL(ipn.db_notes,'') as db_notes , s.db_Phase as db_Phase, DATE_FORMAT(pd.db_last_update,'%d-%m-%Y %h:%i %p') as 'db_last_update_formated'
FROM playbook_d pd 
LEFT JOIN playbook p on pd.db_playbook_id = p.db_id
LEFT JOIN users u on pd.db_owner_id = u.db_id 
LEFT JOIN standards s on pd.db_phase_id = s.db_id 
LEFT JOIN incident_playbook_actions ipa on  pd.db_id= ipa.db_playbook_action_id
LEFT JOIN incident_playbook_notes ipn on  pd.db_id= ipn.db_playbook_action_id
WHERE pd.db_del = 'No'
AND pd.db_playbook_id= p_id
group by pd.db_id
ORDER BY pd.db_order

;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `playbook_getPlaybookInfoByID`(
IN p_id INT(11)
)
BEGIN

SELECT p.*, c.name as 'db_cat_name', sc.name as 'db_sub_cat_name', uc.db_name as 'db_use_case_name', u.db_FullName as 'db_owner', DATE_FORMAT(p.db_last_update,'%d-%m-%Y %h:%i %p') as 'db_last_update_formated'
FROM playbook p, categories c,  subcategories sc, users u, use_cases uc 
WHERE p.db_del = 'No'
AND p.db_cat_id = c.id 
AND p.db_sub_cat_id = sc.id
AND p.db_use_case_id = uc.db_id
AND p.db_owner_id = u.db_id 
AND p.db_id = p_id;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `playbook_insertNewPlaybook`(
IN p_pb_title VARCHAR(500),
IN p_pb_owner_id INT(11),
IN p_pb_module VARCHAR(50),
OUT p_id INT(11)
)
BEGIN

INSERT INTO playbook (db_Title,db_owner_id,db_Module) VALUES (p_pb_title,p_pb_owner_id,p_pb_module);
SET p_id = last_insert_id();

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `playbook_insert_playbook_details`(
IN p_playbook_id INT(11),
IN p_owner_id INT(11),
IN p_order INT(11)
 

)
BEGIN
INSERT INTO playbook_d (db_playbook_id,db_owner_id,db_order) VALUES (p_playbook_id,p_owner_id,p_order);


END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `report_getAll`(
IN p_module VARCHAR(50)
)
BEGIN

SELECT r.*,  DATE_FORMAT(r.db_EntryDate,'%d-%m-%Y %h:%i %p') as 'db_DateFormatted'
FROM reports r
WHERE r.db_module = p_module
ORDER BY r.db_EntryDate DESC 

;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `rfi_get_all_submitted_rfis`(
IN p_erid int(11) 
)
BEGIN
SELECT 	
		r.*, 
		u.db_fullname,
        DATE_FORMAT(r.db_EntryDate,'%d-%m-%Y %h:%i %p') as 'db_EntryDateFormatted',
        f.db_value,
        f.db_id,
        f.db_file_name
FROM rfi f, incident_rfi r, users u
WHERE r.db_del = 'No'
AND f.db_rfi_id = r.db_id
AND f.db_user_id = u.db_id
AND f.db_erid = p_erid
AND f.db_del = 'No'
;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `rfi_get_by_erid`(

IN p_erid int(11)

)
BEGIN
SELECT 	r.*, 
		u.db_fullname,
        DATE_FORMAT(r.db_EntryDate,'%d-%m-%Y %h:%i %p') as 'db_EntryDateFormatted'
FROM incident_rfi r, users u
WHERE r.db_del = 'NO'
AND r.db_user_id = u.db_id
AND r.db_erid = p_erid

;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `rfi_get_by_id`(
IN p_id int(11)
)
BEGIN
SELECT 	r.* 
FROM incident_rfi r
WHERE r.db_del = 'No'
AND r.db_id = p_id
;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `rfi_get_by_member_id`(
IN p_erid int(11),
IN p_user_id int(11)
)
BEGIN
SELECT 	
		r.*, 
		u.db_fullname,
        DATE_FORMAT(r.db_EntryDate,'%d-%m-%Y %h:%i %p') as 'db_EntryDateFormatted',
        f.db_value,
        f.db_id,
        f.db_file_name
FROM rfi f, incident_rfi r, users u
WHERE r.db_del = 'No'
AND f.db_rfi_id = r.db_id
AND f.db_user_id = u.db_id
AND f.db_user_id = p_user_id
AND f.db_erid = p_erid
AND f.db_del = 'No'
;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `rfi_get_template_by_name`(

IN p_template_name varchar(100),
IN p_module varchar(100)


)
BEGIN
SELECT 	*, 
        DATE_FORMAT(rt.db_EntryDate,'%d-%m-%Y %h:%i %p') as 'db_EntryDateFormatted'
FROM rfi_templates rt 
WHERE rt.db_del = 'No'
AND db_module = p_module

;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `rfi_get_templates`(

 
IN p_module varchar(100)


)
BEGIN
SELECT 	*, 
        DATE_FORMAT(rt.db_EntryDate,'%d-%m-%Y %h:%i %p') as 'db_EntryDateFormatted'
FROM rfi_templates rt 
WHERE rt.db_del = 'No'
AND db_module = p_module

;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `rfi_insert_new`(
IN p_erid INT(11),
IN p_user_id INT(11),
IN p_rfi_id INT(11),
IN p_value LONGTEXT,
OUT p_id INT(11)
)
BEGIN
INSERT INTO `q_main_base`.`rfi`
( 
`db_erid`,
`db_user_id`,
`db_rfi_id`,
`db_value`
)
VALUES
( 
p_erid,
p_user_id,
p_rfi_id,
p_value
);
SET p_id = last_insert_id();
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `sandbox_getAll`(
IN p_module VARCHAR(50)
)
BEGIN

SELECT s.*,  DATE_FORMAT(s.db_submission_date,'%d-%m-%Y %h:%i %p') as 'db_DateFormatted', u.db_FullName
FROM sandbox s, users u
WHERE s.db_module = p_module
AND s.db_del = 'No'
AND s.db_user_id = u.db_id
ORDER BY s.db_id DESC
LIMIT 1000

;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `sandbox_get_all_by_param`(
IN p_module VARCHAR(50),
IN p_field VARCHAR(50),
IN p_value VARCHAR(1000)

)
BEGIN

SELECT s.*,  DATE_FORMAT(s.db_submission_date,'%d-%m-%Y %h:%i %p') as 'db_DateFormatted', u.db_FullName
FROM sandbox s, users u
WHERE s.db_module = p_module
AND s.db_del = 'No'
AND IF(p_field != 'hash', s.db_value, s.db_hash_sha256)  LIKE CONCAT('%', p_value, '%')
AND s.db_user_id = u.db_id
ORDER BY s.db_id DESC
LIMIT 500

;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `sandbox_get_all_queued`(
IN p_technology varchar (100),
IN p_module varchar (100)
)
BEGIN
SELECT s.*
FROM sandbox s
WHERE s.db_del = 'No'
AND s.db_job_status = 'Queued'
AND s.db_module = p_module
AND s.db_sb_technology = p_technology
ORDER BY s.db_id
LIMIT 1;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `sandbox_get_all_running`(
IN p_technology varchar (100),
IN p_module varchar (100)
)
BEGIN
SELECT s.*
FROM sandbox s
WHERE s.db_del = 'No'
AND s.db_job_status = 'Running'
AND s.db_module = p_module
AND s.db_sb_technology = p_technology
ORDER BY s.db_id
LIMIT 5;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `sandbox_insert_new`(
IN p_user_id INT(11),
IN p_reference VARCHAR(50),
IN p_value LONGTEXT,
IN p_sb_technology VARCHAR(100),
IN p_type VARCHAR(45),
IN p_hash_sha256 VARCHAR(500),
IN p_module VARCHAR(45),
IN p_file_full_path LONGTEXT,
OUT p_id INT(11)

)
BEGIN

INSERT INTO sandbox (
db_user_id,
db_reference,
db_value,
db_sb_technology,
db_type,
db_hash_sha256,
db_module,
db_file_full_path
) 
VALUES 
(
p_user_id,
p_reference,
p_value,
p_sb_technology,
p_type,
p_hash_sha256,
p_module,
p_file_full_path
)
;
SET p_id = last_insert_id();
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `setCurrentUser`(IN useridP INT(11))
BEGIN
    SELECT * from users 
  WHERE (users.db_ID=useridP);
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `settings_getcategories`(
IN p_module varchar(50)
)
BEGIN

SELECT c.*, DATE_FORMAT(c.db_LastUpdate,'%d-%m-%Y %h:%i %p') as 'db_LastUpdateFormated' 
FROM categories c where db_module = p_module AND c.Del = 'No' AND c.db_SystemReserved = 'No' 
order by ID desc;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `settings_getImpacts`(
IN p_module varchar(50)
)
BEGIN
SELECT *, DATE_FORMAT(db_LastUpdate,'%d-%m-%Y %h:%i %p') as 'db_LastUpdateFormated' 
FROM impact  where db_module = p_module AND db_Del = 'No'
order by db_ID desc;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `settings_getIOCs`()
BEGIN
select *, DATE_FORMAT(db_EntryDate,'%d-%m-%Y %h:%i %p') as 'db_LastUpdate' from lists where db_Group = 'IOC' and db_Del = 'No'
order by db_ID DESC
;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `settings_getObjectCountByCategory`(
IN p_CategoryID INT (11)
)
BEGIN

SELECT count(db_id) as db_count FROM incidents where db_deleted = 'No' AND db_CategoryID = p_CategoryID ;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `settings_getObjectCountByIOC`(
IN p_iocID INT(11)
)
BEGIN
SELECT count(i.db_id) as db_count 
FROM incidents i, incident_ioc ioc, lists l
where i.db_deleted = 'No' 
AND i.db_ID = ioc.db_ERID
AND ioc.db_Name = l.db_Value
AND l.db_ID = p_iocID
AND ioc.db_Del = 'No'

;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `settings_getObjectCountByPhase`( 
IN p_standardID INT(11)
)
BEGIN
SELECT count(i.db_id) as db_count 
FROM incidents i, tasks t, standards s
where i.db_deleted = 'No' 
AND i.db_ID = t.db_ERID 
AND t.db_IRPhaseID = s.db_id
AND s.db_ID = p_standardID
AND t.db_Del = 'No'

;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `settings_getObjectCountBySubCategory`(
IN p_SubCategoryID INT (11)
)
BEGIN

SELECT count(db_id) as db_count FROM incidents where db_deleted = 'No' AND db_SubCategoryID = p_SubCategoryID ;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `settings_getObjectCountByTag`(
IN p_tagID INT(11)
)
BEGIN
SELECT count(i.db_id) as db_count 
FROM incidents i, tags t, lists l
where i.db_deleted = 'No' 
AND i.db_ID = t.db_GroupID
AND t.db_Category = l.db_Value
AND l.db_ID = p_tagID
AND t.db_Del = 'No'
AND t.db_Group = 'ER'

;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `settings_getRisks`(
IN p_module varchar(50)
)
BEGIN
SELECT *, DATE_FORMAT(db_LastUpdate,'%d-%m-%Y %h:%i %p') as 'db_LastUpdateFormated' 
FROM risks  where db_module = p_module AND db_Del = 'No'
order by db_ID desc;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `settings_getShifts`()
BEGIN
SELECT 	*, 
		u.db_FullName as db_Manager, 
		concat("From: ",DATE_FORMAT(s.db_Effective_Date,'%d-%m-%Y'),"\n","To: ",DATE_FORMAT(s.db_Expiration_Date,'%d-%m-%Y')) as 'db_Date', 
        concat("From: ",DATE_FORMAT(s.db_Time_Start,'%h:%i %p'),"\n","To: ",DATE_FORMAT(s.db_Time_End,'%h:%i %p')) as 'db_Time' 
        FROM shifts s, users u
        WHERE 	s.db_del = 'No'
				AND s.db_ManagerID = u.db_ID
;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `settings_getStandards`(
IN p_module varchar(45)
)
BEGIN
SELECT *,   DATE_FORMAT(db_EntryDate,'%d-%m-%Y %h:%i %p') as 'db_LastUpdate'
FROM standards Where db_del = 'No' AND db_SystemReserved = 'No' AND (db_Module = 'system' OR db_Module = p_module)  order by db_ID DESC
;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `settings_getsubcategories`(
IN p_module varchar(50)
)
BEGIN

SELECT sc.*, c.`Name` as cname, c2.`Name` as cname_escalated, sc2.`Name` as scname_escalated, DATE_FORMAT(sc.db_LastUpdate,'%d-%m-%Y %h:%i %p') as 'db_LastUpdateFormated'
FROM subcategories sc 
LEFT JOIN categories c on sc.categoryID = c.id 
LEFT JOIN categories c2 on sc.db_Mapped_simp_CategoryID = c2.id 
LEFT JOIN subcategories sc2 on sc.db_Mapped_simp_SubCategoryID = sc2.id 
WHERE sc.Del = 'No' 
AND sc.db_SystemReserved = 'No'
AND sc.db_module = p_module
ORDER BY sc.ID DESC;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `settings_TagGroups`()
BEGIN
select *, DATE_FORMAT(db_EntryDate,'%d-%m-%Y %h:%i %p') as 'db_LastUpdate' from lists where db_Group <> 'IOC' and db_Del = 'No' 
order by db_ID DESC
;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `shifts_addNewHandover`(
 
IN p_Number VARCHAR(20), 
IN p_ManagerID INT(20),  
IN p_CreatedByID INT(20), 
IN p_ShiftID INT(20), 
IN p_Members VARCHAR(1000),
IN p_Attendees VARCHAR(1000),
IN p_Absentees VARCHAR(1000),
OUT p_id INT(11)
 
  )
BEGIN
 INSERT INTO `handover`
(
db_Number,
db_ManagerID,
db_InitiatorID,
db_ShiftID,
db_Members,
db_Attendees,
db_Absentees
)
VALUES
(
p_Number, 
p_ManagerID,  
p_CreatedByID, 
p_ShiftID, 
p_Members,
p_Attendees,
p_Absentees
);

SET p_id = last_insert_id();
 
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `shifts_getAllShiftHandover`()
BEGIN

SELECT 	h.*, 
		u2.db_FullName as db_Manager,
		u1.db_FullName as db_Initiator,
        s.db_name as db_ShiftName,
        DATE_FORMAT(h.db_Date,'%d-%m-%Y %h:%i %p') as 'db_DateFormatted'
FROM 	handover h
		LEFT JOIN shifts s on h.db_ShiftID = s.db_ID
		LEFT JOIN users u1 on h.db_InitiatorID = u1.db_id
        LEFT JOIN users u2 on h.db_ManagerID = u2.db_id
       
        
WHERE h.db_del = 'No'

ORDER BY h.db_ID DESC

LIMIT 500
;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `shifts_getPosts`()
BEGIN
SELECT 	s.*, 
		u.db_FullName as db_PostedBy, 
        DATE_FORMAT(s.db_EntryDate,'%d-%m-%Y %h:%i %p') as 'db_Time', 
		DATE_FORMAT(s.db_Start_Date,'%d-%m-%Y %h:%i %p') as 'db_Date_Start', 
        DATE_FORMAT(s.db_End_Date,'%d-%m-%Y %h:%i %p') as 'db_Date_End' 
        FROM shifts_posts s 
        LEFT JOIN users u on s.db_PostedByID = u.db_ID
        WHERE 	s.db_del = 'No'
        AND YEAR(db_Start_Date) >= (YEAR(now()) -1) 
        AND YEAR(db_End_Date) = YEAR(now())
        ORDER BY s.db_ID DESC
         
				
;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `shifts_getShiftHandoverByID`(
IN p_id INT(11)
)
BEGIN

SELECT 	h.*, 
		u2.db_FullName as db_Manager,
		u1.db_FullName as db_Initiator,
        s.db_name as db_ShiftName,
        s.db_Type as db_ShiftType,
        DATE_FORMAT(h.db_Date,'%d-%m-%Y %h:%i %p') as 'db_DateFormatted'
FROM 	handover h
		LEFT JOIN shifts s on h.db_ShiftID = s.db_ID
		LEFT JOIN users u1 on h.db_InitiatorID = u1.db_id
        LEFT JOIN users u2 on h.db_ManagerID = u2.db_id
       
        
WHERE 	h.db_del = 'No'
		AND h.db_ID = p_id

ORDER BY h.db_ID DESC

LIMIT 500
;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `shifts_getShifts`()
BEGIN
SELECT 	s.*, 
		u.db_FullName as db_Manager, 
		DATE_FORMAT(s.db_Time_Start,'%h:%i %p') as 'db_Time_Start_Formated', 
        DATE_FORMAT(s.db_Time_End,'%h:%i %p') as 'db_Time_End_Formated' 
        FROM shifts s 
        LEFT JOIN users u on s.db_ManagerID = u.db_ID
        WHERE 	s.db_del = 'No'
        ORDER BY db_ID desc
				
;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `shifts_insertNewPost`(
 
IN p_Number VARCHAR(50), 
IN p_Shift VARCHAR(20), 
IN p_StartDate VARCHAR(50),
IN p_EndDate VARCHAR(50), 
IN p_PostedByID INT(11), 
IN p_ShiftMembers VARCHAR(500), 
OUT p_id INT(11)
 
  )
BEGIN
 INSERT INTO `shifts_posts`
(
db_Number,
db_Shift,
db_Start_Date,
db_End_Date,
db_PostedByID,
db_ShiftMembers 
)
VALUES
(
p_Number,
p_Shift,
p_StartDate,
p_EndDate,
p_PostedByID,
p_ShiftMembers
);

SET p_id = last_insert_id();
 
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `sla_escalation_check_by_priority`()
BEGIN
SELECT * FROM tasks WHERE db_del = 'No' AND db_SLA_Applied = 'Yes' AND db_SLA_ID <> 0 AND db_Status != 'Closed'
;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `sla_escalation_check_by_rfi`()
BEGIN
SELECT s.*, i.db_severity, i.db_StartDateTime, i.db_Reference, i.db_Title, i.db_Status
FROM `share` s, incidents i
WHERE s.db_erid = i.db_id
AND s.db_del = 'No'
AND i.db_Deleted = 'No'
AND i.db_Share_SLA_Enabled = 'Yes'
AND i.db_Share_RFI_Enabled = 'Yes'
AND i.db_Share_Status = 'Published'
;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `sla_escalation_check_by_severity`(
)
BEGIN
SELECT *
FROM incidents i
WHERE i.db_Deleted = 'No' 
AND i.db_SLA_Applied = 'Yes' 
AND i.db_SLA_ID <> 0 
AND i.db_Status = 'Open'
;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `sla_getAllSLAsByModule`(
IN p_module varchar(45)
)
BEGIN
SELECT s.*, u.db_FullName as db_owner_name, t.name as db_type_name, DATE_FORMAT(s.db_LastUpdate,'%d-%m-%Y %h:%i %p') as 'db_LastUpdateFormatted'
FROM sla s, users u, `types` t 
where s.db_typeid = t.id
and (t.Module = p_module OR t.name = 'Task')
and s.db_owner = u.db_id 
and s.db_del = 'No' 
and s.db_module = p_module;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `sla_getByObjectType`(
IN p_target_type varchar(100),
IN p_module varchar(100),
IN p_ApplyToGroup varchar(100),
IN p_type varchar(100),
IN p_typeID INT(11)
)
BEGIN
SELECT s.* FROM 
sla s, sla_d sd 
where s.db_id = sd.db_sid 
and sd.db_Target_Type = p_target_type
and s.db_Module = p_module
and s.db_ApplyToGroup = p_ApplyToGroup 
and s.db_type = p_type
and s.db_TypeID = p_typeID
and s.db_Del = 'No'
and sd.db_Del = 'No'
;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `sla_getByObjectTypeEscalated`(
IN p_target_type varchar(100),
IN p_module varchar(100),
IN p_type varchar(100),
IN p_typeID INT(11)
)
BEGIN
SELECT s.*, sd.db_Target_Type 
FROM   sla s, sla_d sd 
where s.db_id = sd.db_sid 
and sd.db_Target_Type = p_target_type
and s.db_Module = p_module
and s.db_type = p_type
and s.db_TypeID = p_typeID
and s.db_EscalationDefult = 'Yes'
and s.db_Del = 'No'
and sd.db_Del = 'No'
;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `sla_getByTaskType`(
IN p_target_type varchar(100),
IN p_module varchar(100),
IN p_ApplyToGroup varchar(100),
IN p_type varchar(100)
)
BEGIN
SELECT s.* FROM 
sla s, sla_d sd 
where s.db_id = sd.db_sid 
and sd.db_Target_Type = p_target_type
and s.db_Module = p_module
and s.db_ApplyToGroup = p_ApplyToGroup 
and s.db_type = p_type
and s.db_Del = 'No'
and sd.db_Del = 'No'
;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `sla_getByTeam`(
IN p_module varchar(100),
IN p_ApplyToGroup varchar(100)
)
BEGIN
SELECT s.* FROM 
sla s
where s.db_Module = p_module
and s.db_ApplyToGroup = p_ApplyToGroup 
and s.db_Del = 'No'
and s.db_Enabled = 'Yes'
;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `sla_getByTypeByObject`(
IN p_target_type varchar(100),
IN p_module varchar(100),
IN p_type varchar(100),
IN p_typeID INT(11)
)
BEGIN
SELECT s.*, sd.db_Target_Type 
FROM   sla s, sla_d sd 
where s.db_id = sd.db_sid 
and sd.db_Target_Type = p_target_type
and s.db_Module = p_module
and s.db_type = p_type
and s.db_TypeID = p_typeID
and s.db_Del = 'No'
and sd.db_Del = 'No'
;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `sla_getSLAByID`(
IN p_sla_id INT(11)
)
BEGIN
SELECT *, TIMESTAMPDIFF(MINUTE,db_Target_Daily_Service_Time_Start,db_Target_Daily_Service_Time_End) as db_SLA_Daily_Time_Diff  
FROM q_main_base.sla
WHERE db_ID = p_sla_id
AND db_del = 'No'
;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `sla_getSLADeatilsBySLA_ID`(
IN p_sla_id INT(11)
)
BEGIN
SELECT * FROM sla_d where db_del = 'No' and db_SID = p_sla_id;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `sla_getSLAInfoByID`(
IN p_sla_id INT(11),
IN p_module varchar(45)
)
BEGIN
SELECT s.*, u.db_FullName as db_owner_name, t.`name` AS db_type_name, DATE_FORMAT(s.db_LastUpdate,'%d-%m-%Y %h:%i %p') as 'db_LastUpdateFormatted'
FROM sla s, users u, `types` t 
WHERE s.db_typeid = t.id
AND (t.Module = p_module or t.name = 'Task')
AND s.db_owner = u.db_id 
AND s.db_del = 'No' 
AND s.db_module = p_module
AND s.db_ID = p_sla_id

;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `sla_insertNewSLA`( 
IN p_sla_title VARCHAR(500),
IN p_sla_type VARCHAR(500),
IN p_sla_owner_id INT(11),
IN p_sla_type_id INT(11),
IN p_sla_module VARCHAR(50),
OUT p_id INT(11)
)
BEGIN

INSERT INTO sla (db_Title,db_Type,db_Owner,db_TypeID,db_Module) VALUES (p_sla_title,p_sla_type,p_sla_owner_id,p_sla_type_id,p_sla_module);
SET p_id = last_insert_id();

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `sla_insertNewSLA_Details`(
IN p_sla_id INT(11)
)
BEGIN

INSERT INTO sla_d (db_Target_Type,db_SID,db_Escalation_Recipients) VALUES ('New',p_sla_id,'');

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `soar_get_all_groups`(
IN p_module VARCHAR(1000),
IN p_view VARCHAR(1000)
)
BEGIN
SELECT * 
FROM orchestrator_jobs 
WHERE db_user_soar = 'Yes' 
AND db_Job_Enabled = 'Yes'
AND db_allowed_module LIKE  CONCAT('%', p_module, '%')
AND db_allowed_view LIKE  CONCAT('%', p_view, '%')
;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `subtypes_get_count_by_subtype`(
IN p_subtype VARCHAR(500),
IN p_module VARCHAR(50)
)
BEGIN

SELECT COUNT(s.db_SubTypeID) AS db_count 
FROM sub_types st, incident_subtypes s, `types` t
WHERE (s.db_Del = 'No')
AND st.db_id = s.db_SubTypeID
AND st.db_typeid = t.id
AND st.db_Name = p_subtype
AND t.module = p_module
;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `system_getAllSystemProperties`()
BEGIN
SELECT * FROM system_properties where db_Customizable = 'Yes' order by db_id, db_Group_Order;
 
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `system_getAllSystemPropertiesAll`()
BEGIN
SELECT * FROM system_properties order by db_id, db_Group_Order;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `system_getAllSystemSettings`()
BEGIN
SELECT * FROM system_settings order by db_Setting;
 
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `tags_concatenatedTagsByERID`(
p_erid INT(11)
)
BEGIN
set session group_concat_max_len = 204800;
SELECT group_concat(DISTINCT concat('<font color="gray"> \[</font><font color="#000">',trim(db_name),'</font><font color="gray">\] </font>') SEPARATOR '   ') as db_tag 
FROM tags 
WHERE db_Del = 'No'  
AND db_GroupID = p_erid
AND db_ChildGroup = 'Object'
;


END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `tags_get_recent_items`(
IN p_cat varchar(500),
IN p_module varchar(50)
)
BEGIN
SELECT distinct ta.db_name as v1, ta.db_LastUpdate
FROM tags ta, incidents i, `types` t
WHERE ta.db_GroupID = i.db_id
AND i.db_typeid = t.id
AND t.module = p_module
AND ta.db_Del = 'No'
AND ta.db_Category LIKE concat(p_cat,'%')
ORDER BY ta.db_LastUpdate DESC 
LIMIT 8
;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `tags_getTagsByERID`(
IN p_erID INT(11),
IN p_module VARCHAR(100),
IN p_group VARCHAR(100)
)
BEGIN
SELECT t1.*, count(t2.db_Name) as db_count 
                     FROM tags t1 
                     LEFT JOIN (select ta.db_name from tags ta,incidents i,`types` t where  i.db_TypeID = t.ID and i.db_id = ta.db_groupID  and t.Module = p_module and i.db_Deleted = 'No' and ta.db_Del = 'No') as t2 ON t1.db_Name = t2.db_Name 
                     WHERE (t1.db_GroupID = p_erID) 
                     AND (t1.db_Group = p_group) 
                     AND (t1.db_Del = 'No') 
                     GROUP BY t1.db_Name, t1.db_ID
                     ORDER BY t1.db_ID DESC;
                     
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `tags_getTagsByERID_ByProfile_ByGroup`(
IN p_erID INT(11),
IN p_profile VARCHAR(500),
IN p_group VARCHAR(500),
IN p_module VARCHAR(100),
IN p_tagGroup VARCHAR(100)
)
BEGIN
SELECT t1.*, count(t2.db_Name) as db_count 
	 FROM tags t1 
	 LEFT JOIN (SELECT ta.db_name FROM tags ta,incidents i, `types` t, users u, user_profiles up  WHERE i.db_id = ta.db_groupID AND i.db_TypeID = t.ID AND t.Module = p_module AND i.db_ManagerID = u.db_id AND u.db_UserProfileID = up.id AND up.name = p_profile AND u.db_group = p_group  AND  i.db_Deleted = 'No' AND ta.db_Del = 'No') AS t2 ON t1.db_Name = t2.db_Name      
     WHERE (t1.db_GroupID = p_erID) 
	 AND (t1.db_Group = p_tagGroup) 
	 AND (t1.db_ChildGroup = 'Object')
     AND (t1.db_Del = 'No') 
	 GROUP BY t1.db_Name, t1.db_ID 
	 ORDER BY t1.db_ID DESC;
                     
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `tags_getTopTags`(
)
BEGIN

SELECT db_name, COUNT(db_id) AS db_count 
FROM tags 
WHERE (db_Del = 'No')
GROUP BY db_name
ORDER BY db_count 
DESC LIMIT 15;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `tasks_d_InsertNewTask`(

IN p_UserID INT(11),
IN p_TaskID INT(11),
IN p_Details longtext, 
IN p_Attachments longtext, 
IN p_Status longtext, 
OUT p_id INT(11)

)
BEGIN

INSERT INTO  tasks_d
( 
db_UserID,
db_TaskID,
db_Details,
db_Attachments,
db_Status

)
VALUES
(
p_UserID,
p_TaskID,
p_Details,
p_Attachments,
p_Status
);

SET p_id = last_insert_id();

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `tasks_getAllByDate`(
IN p_backTime_from VARCHAR(100),
IN p_backTime_to VARCHAR(100),
IN p_module VARCHAR(100),
IN p_coordinator VARCHAR(100)
)
BEGIN

SELECT tasks.*,t1.db_FullName as db_Assignee,
		t2.db_FullName as db_Initiator,
         i.db_Title, i.db_Reference as db_ERNumber,
        DATE_FORMAT(tasks.db_Time,'%d-%m-%Y %h:%i %p') as 'db_TimeStamp',
         t3.db_Phase as 'db_IRPhase',
        (select count(db_ID) as db_value from reminders where db_Object = 'Task' AND db_ObjectID = tasks.db_id) as db_reminders,
        i.db_Reference as db_Parent,
        t4.db_title as db_sla_name
        
        
FROM tasks 
LEFT JOIN incidents i on i.db_ID = tasks.db_ERID
		LEFT JOIN `types` t on  i.db_TypeID = t.ID  	 
        LEFT JOIN users t1 on tasks.db_AssigneeID = t1.db_id
        LEFT JOIN users t2 on tasks.db_InitiatorID = t2.db_id
		LEFT JOIN standards t3 on tasks.db_IRPhaseID = t3.db_id 
        LEFT JOIN sla t4 on tasks.db_SLA_ID = t4.db_id 
         
Where	(tasks.db_del = 'No') 
	AND (
		t1.db_UserName = p_coordinator
		OR 
        lower(t.`Module`) = lower(p_module)
        OR 
        t1.db_Module = p_module
    )
	AND (i.db_deleted = 'No') 
    AND (tasks.db_Time BETWEEN p_backTime_from AND p_backTime_to)


order by tasks.db_ID desc	
    
;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `tasks_getAllByDateByDomainUser`(
IN p_backTime VARCHAR(100),
IN p_assigneeDomainUserID VARCHAR(100),
IN p_module VARCHAR(100)
)
BEGIN

SELECT tasks.*,t1.db_FullName as db_Assignee,
		t2.db_FullName as db_Initiator,
         i.db_Title,
        DATE_FORMAT(tasks.db_Time,'%d-%m-%Y %h:%i %p') as 'db_TimeStamp',
         t3.db_Phase as 'db_IRPhase',
        (select count(db_ID) as db_value from reminders where db_Object = 'Task' AND db_ObjectID = tasks.db_id) as db_reminders,
        i.db_Reference as db_Parent
        
        
FROM tasks 
LEFT JOIN incidents i on i.db_ID = tasks.db_ERID	
		LEFT JOIN `types` t on  i.db_TypeID = t.ID  	 
		LEFT JOIN users t1 on tasks.db_AssigneeID = t1.db_id
        LEFT JOIN users t2 on tasks.db_InitiatorID = t2.db_id
        LEFT JOIN standards t3 on tasks.db_IRPhaseID = t3.db_id
         
Where	(tasks.db_del = 'No') 
	AND 
		(tasks.db_domain_user_id = p_assigneeDomainUserID)
	AND lower(t.`Module`) = lower(p_module)
	 AND (tasks.db_Time BETWEEN p_backTime AND NOW())


order by tasks.db_ID desc
;	
    
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `tasks_getAllByDate_ByProfile_ByGroup`(
IN p_backTime VARCHAR(100),
IN p_profile VARCHAR(500),
IN p_group VARCHAR(500),
IN p_module VARCHAR(100)
)
BEGIN

SELECT tasks.*,t1.db_FullName as db_Assignee,
		t2.db_FullName as db_Initiator,
         i.db_Title,
        DATE_FORMAT(tasks.db_Time,'%d-%m-%Y %h:%i %p') as 'db_TimeStamp',
         t3.db_Phase as 'db_IRPhase',
        (select count(db_ID) as db_value from reminders where db_Object = 'Task' AND db_ObjectID = tasks.db_id) as db_reminders,
        i.db_Reference as db_Parent
        
        
FROM tasks 
LEFT JOIN incidents i on i.db_ID = tasks.db_ERID	
		LEFT JOIN `types` t on  i.db_TypeID = t.ID  
        LEFT JOIN users t1 on tasks.db_AssigneeID = t1.db_id
        LEFT JOIN users t2 on tasks.db_InitiatorID = t2.db_id
		LEFT JOIN standards t3 on tasks.db_IRPhaseID = t3.db_id
        LEFT JOIN users u on  tasks.db_AssigneeID = u.db_id 
		LEFT JOIN user_profiles up on u.db_UserProfileID = up.id
WHERE	(tasks.db_del = 'No') 
	AND (tasks.db_Time BETWEEN p_backTime AND NOW())
	AND up.name = p_profile 
	AND u.db_group = p_group


order by tasks.db_ID desc	
    
;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `tasks_getAllByDateByUser`(
IN p_backTime VARCHAR(100),
IN p_AssigneeID INT(11),
IN p_module VARCHAR(100)
)
BEGIN

SELECT tasks.*,t1.db_FullName as db_Assignee,
		t2.db_FullName as db_Initiator,
         i.db_Title,
        DATE_FORMAT(tasks.db_Time,'%d-%m-%Y %h:%i %p') as 'db_TimeStamp',
         t3.db_Phase as 'db_IRPhase',
        (select count(db_ID) as db_value from reminders where db_Object = 'Task' AND db_ObjectID = tasks.db_id) as db_reminders,
        i.db_Reference as db_Parent
        
        
FROM tasks 
LEFT JOIN incidents i on i.db_ID = tasks.db_ERID	
		LEFT JOIN `types` t on  i.db_TypeID = t.ID  	 
        LEFT JOIN users t1 on tasks.db_AssigneeID = t1.db_id
        LEFT JOIN users t2 on tasks.db_InitiatorID = t2.db_id
        LEFT JOIN standards t3 on tasks.db_IRPhaseID = t3.db_id
         
Where	(tasks.db_del = 'No') 
	AND 
		(tasks.db_AssigneeID = p_AssigneeID)
	AND lower(t.`Module`) = lower(p_module)
	 AND (tasks.db_Time BETWEEN p_backTime AND NOW())


order by tasks.db_ID desc	
    
;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `tasks_getAllBySearchKeyword`(
IN p_keyword longtext
)
BEGIN

SELECT tasks.*,t1.db_FullName as db_Assignee,
		t2.db_FullName as db_Initiator,
		i.db_Title,
        t3.db_Phase as 'db_IRPhase',
        DATE_FORMAT(tasks.db_Time,'%d-%m-%Y %h:%i %p') as 'db_TimeStamp',
        i.db_Reference as db_Parent,
        (select count(db_ID) as db_value from reminders where db_Object = 'Task' AND db_ObjectID = tasks.db_id) as db_reminders,
        group_concat(t.db_Details SEPARATOR '<br/>') db_details,
        concat(
		ifnull(tasks.db_Time ,''),' ',
		ifnull(tasks.db_Number ,''),' ',
		ifnull(i.db_Reference,''),' ',
		ifnull(tasks.db_Status,''),' ',
		ifnull(tasks.db_Priority ,''),' ',
		ifnull(tasks.db_Subject,''),' ',
		ifnull(t1.db_FullName ,''),' ',
		ifnull(t2.db_FullName ,''),' ',
		ifnull(group_concat(t.db_Details SEPARATOR ' '),' ')
        ) as 'allData'   
        
        
FROM tasks 
LEFT JOIN incidents i on i.db_ID = tasks.db_ERID	
        LEFT JOIN users t1 on tasks.db_AssigneeID = t1.db_id
        LEFT JOIN users t2 on tasks.db_InitiatorID = t2.db_id
		LEFT JOIN tasks_d t on tasks.db_id = t.db_TaskID
		LEFT JOIN standards t3 on tasks.db_IRPhaseID = t3.db_id
         
Where	(tasks.db_del = 'No') 
	AND
		(i.db_Deleted = 'No') 

GROUP BY tasks.db_id
having alldata like p_keyword   
order by tasks.db_ID desc	

    
;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `tasks_getAllBySearchKeyword_ByProfile_ByGroup`(
IN p_keyword longtext,
IN p_profile VARCHAR(500),
IN p_group VARCHAR(500)
)
BEGIN

SELECT tasks.*,t1.db_FullName as db_Assignee,
		t2.db_FullName as db_Initiator,
		i.db_Title,
        t3.db_Phase as 'db_IRPhase',
        DATE_FORMAT(tasks.db_Time,'%d-%m-%Y %h:%i %p') as 'db_TimeStamp',
        i.db_Reference as db_Parent,
        (select count(db_ID) as db_value from reminders where db_Object = 'Task' AND db_ObjectID = tasks.db_id) as db_reminders,
        group_concat(t.db_Details SEPARATOR '<br/>') db_details,
        concat(
		ifnull(tasks.db_Time ,''),' ',
		ifnull(tasks.db_Number ,''),' ',
		ifnull(i.db_Reference,''),' ',
		ifnull(tasks.db_Status,''),' ',
		ifnull(tasks.db_Priority ,''),' ',
		ifnull(tasks.db_Subject,''),' ',
		ifnull(t1.db_FullName ,''),' ',
		ifnull(t2.db_FullName ,''),' ',
		ifnull(group_concat(t.db_Details SEPARATOR ' '),' ')
        ) as 'allData'   
        
        
FROM tasks 
LEFT JOIN incidents i on i.db_ID = tasks.db_ERID	
        LEFT JOIN users t1 on tasks.db_AssigneeID = t1.db_id
        LEFT JOIN users t2 on tasks.db_InitiatorID = t2.db_id
		LEFT JOIN tasks_d t on tasks.db_id = t.db_TaskID
		LEFT JOIN standards t3 on tasks.db_IRPhaseID = t3.db_id
        left join users u on  i.db_ManagerID = u.db_id 
		left join user_profiles up on u.db_UserProfileID = up.id

         
Where	(tasks.db_del = 'No') 
	AND	(i.db_Deleted = 'No') 
	AND up.name = p_profile
	AND u.db_group = p_group

GROUP BY tasks.db_id
having alldata like p_keyword   
order by tasks.db_ID desc	

    
;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `tasks_geTaskByID`(
IN p_TaskID INT(11)
)
BEGIN

SELECT tasks.*,t1.db_FullName as db_Assignee,
		t2.db_FullName as db_Initiator,
         i.db_Title,
          t3.db_Phase as 'db_IRPhase',
        DATE_FORMAT(tasks.db_Time,'%d-%m-%Y %h:%i %p') as 'db_TimeStamp',
        (select count(db_ID) as db_value from reminders where db_Object = 'Task' AND db_ObjectID = tasks.db_id) as db_reminders,
        i.db_Reference as db_Parent
                
FROM tasks 
LEFT JOIN incidents i on i.db_ID = tasks.db_ERID	
        LEFT JOIN users t1 on tasks.db_AssigneeID = t1.db_id
        LEFT JOIN users t2 on tasks.db_InitiatorID = t2.db_id
        LEFT JOIN standards t3 on tasks.db_IRPhaseID = t3.db_id
        
Where	(tasks.db_del = 'No') 
	AND (tasks.db_ID= p_TaskID)    
;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `tasks_geTaskByStatus`(
IN p_status VARCHAR(100),
IN p_module VARCHAR(100),
IN p_coordinator VARCHAR(100)
)
BEGIN
 
SELECT tasks.*,t1.db_FullName as db_Assignee,
		t2.db_FullName as db_Initiator,
         i.db_Title, 
         i.db_Reference as db_Parent,
        DATE_FORMAT(tasks.db_Time,'%d-%m-%Y %h:%i %p') as 'db_TimeStamp',
         t3.db_Phase as 'db_IRPhase',
        (select count(db_ID) as db_value from reminders where db_Object = 'Task' AND db_ObjectID = tasks.db_id) as db_reminders
      
        
        
FROM tasks 
LEFT JOIN incidents i on i.db_ID = tasks.db_ERID
		LEFT JOIN `types` t on  i.db_TypeID = t.ID  	 
        LEFT JOIN users t1 on tasks.db_AssigneeID = t1.db_id
        LEFT JOIN users t2 on tasks.db_InitiatorID = t2.db_id
		LEFT JOIN standards t3 on tasks.db_IRPhaseID = t3.db_id 
         
Where	(tasks.db_del = 'No') 
	AND (t1.db_UserName = p_coordinator OR t.Module = p_module)
 	AND (tasks.db_Status = p_status)   

order by tasks.db_ID desc	
;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `tasks_getByID`(
IN p_ERID INT(11)
)
BEGIN

SELECT tasks.*,t1.db_FullName as db_Assignee,
		t2.db_FullName as db_Initiator,
         i.db_Title,
         t3.db_Phase as 'db_IRPhase',
        DATE_FORMAT(tasks.db_Time,'%d-%m-%Y %h:%i %p') as 'db_TimeStamp',
        (select count(db_ID) as db_value from reminders where db_Object = 'Task' AND db_ObjectID = tasks.db_id) as db_reminders,
        i.db_Reference as db_Parent
        
        
FROM tasks 
LEFT JOIN incidents i on i.db_ID = tasks.db_ERID	
        LEFT JOIN users t1 on tasks.db_AssigneeID = t1.db_id
        LEFT JOIN users t2 on tasks.db_InitiatorID = t2.db_id
        LEFT JOIN standards t3 on tasks.db_IRPhaseID = t3.db_id
         
Where	(tasks.db_del = 'No') 
	AND (tasks.db_ERID = p_ERID)
    
    order by db_id desc
    
;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `tasks_getCountByTime`( 
IN p_module VARCHAR(100),
IN p_coordinator VARCHAR(100),
IN p_backTime_from VARCHAR(100),
IN p_backTime_to VARCHAR(100)
 

)
BEGIN
	SELECT COUNT(t.db_ID) as 'db_Count' 
	FROM tasks t, incidents i, users u, `types` ty
    WHERE t.db_del = 'No'
    AND i.db_typeID = ty.id 
    AND i.db_deleted = 'No'
    AND i.db_ID = t.db_ERID
    AND i.db_ManagerID = u.db_id 
    AND (
		u.db_UserName = p_coordinator
		OR 
        (lower(ty.`Module`) = lower(p_module))
    )
	AND  (t.db_Time BETWEEN p_backTime_from AND p_backTime_to)
    ;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `tasks_getCountByTime_ByProfile_ByGroup`( 
IN p_profile VARCHAR(500),
IN p_group VARCHAR(500),
IN p_module VARCHAR(100),
IN p_backTime_from VARCHAR(100),
IN p_backTime_to VARCHAR(100)
)
BEGIN
	SELECT count(t.db_ID) as 'db_Count' 
	from tasks t
    
    LEFT JOIN incidents i on i.db_ID = t.db_ERID	
    LEFT JOIN `types` ty on i.db_typeID = ty.id 
	LEFT JOIN users u on  i.db_ManagerID = u.db_id 
	LEFT JOIN user_profiles up on u.db_UserProfileID = up.id
    
    WHERE (t.db_del = 'No') 
	AND  (t.db_Time BETWEEN p_backTime_from AND p_backTime_to)
    AND up.name = p_profile
	AND u.db_group = p_group
    AND (lower(ty.`Module`) = lower(p_module))
    
    ;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `tasks_getTaskDetailsByTaskID`(

IN p_TaskID INT(11)

)
BEGIN

SELECT tasks_d.*,
		t1.db_FullName as db_Initiator,
        t1.db_pic,
        DATE_FORMAT(tasks_d.db_Time,'%d-%m-%Y %h:%i %p') as 'db_TimeStamp'
                
FROM tasks_d 
LEFT JOIN tasks t on t.db_ID = tasks_d.db_TaskID	
        LEFT JOIN users t1 on tasks_d.db_UserID = t1.db_id
        
WHERE (tasks_d.db_TaskID= p_TaskID)  

order by db_id desc
;         

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `tasks_InsertNewReminder`(
IN p_Name varchar(45),
IN p_UserID INT(11),
IN p_ObjectID INT(11),
IN p_Object varchar(45)
)
BEGIN

INSERT INTO  reminders
( 
db_Name,
db_UserID,
db_ObjectID,
db_Object
)
VALUES
(
p_Name,
p_UserID,
p_ObjectID,
p_Object
);


END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `tasks_InsertNewTask`(
IN p_Number varchar(45),
IN p_InitiatorID INT(11),
IN p_AssigneeID INT(11),
IN p_Status varchar(45), 
IN p_ERID INT(11),
IN p_Priority varchar(45),
IN p_Subject varchar (500),
IN p_IRPhaseID INT(11),
IN p_Time varchar(45),
OUT p_id INT(11)
)
BEGIN

INSERT INTO  tasks
( 
db_Number,
db_InitiatorID,
db_AssigneeID,
db_Status,
db_ERID,
db_Priority,
db_Subject,
db_IRPhaseID,
db_Time
)
VALUES
(
p_Number,
p_InitiatorID,
p_AssigneeID,
p_Status,
p_ERID,
p_Priority,
p_Subject,
p_IRPhaseID,
p_Time
);

SET p_id = last_insert_id();

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `Tasks_TasksByProgress`()
BEGIN

SELECT p.db_name, ifnull(count(t1.db_id),0) as `db_Count`
		
FROM progress p 
left join tasks t1 on p.db_Name = t1.db_status AND t1.db_Del  = 'No'
left join incidents i on i.db_ID = t1.db_ERID AND i.db_status = 'Open'  AND i.db_Deleted  = 'No' 
 
group by p.db_name

;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `Tasks_TasksByStatusByTime`(
IN p_backTime INT(11),
IN p_module VARCHAR(100),
IN p_coordinator VARCHAR(100),
IN p_backTime_from VARCHAR(100),
IN p_backTime_to VARCHAR(100)
)
BEGIN

SELECT tasks.db_status as 'db_name', ifnull(count(tasks.db_id),0) as `db_Count`
        
        
FROM tasks 
LEFT JOIN incidents i on i.db_ID = tasks.db_ERID
		LEFT JOIN `types` t on  i.db_TypeID = t.ID  	 
        LEFT JOIN users t1 on tasks.db_AssigneeID = t1.db_id
        LEFT JOIN users t2 on tasks.db_InitiatorID = t2.db_id
		LEFT JOIN standards t3 on tasks.db_IRPhaseID = t3.db_id 
         
Where	(tasks.db_del = 'No') 
	AND (
		t1.db_UserName = p_coordinator
		OR 
        (lower(t.`Module`) = lower(p_module))
    )
	AND (i.db_deleted = 'No') 
    AND (tasks.db_Time BETWEEN p_backTime_from AND p_backTime_to)
	AND tasks.db_status IN ('New','In Progress','Pending','Returned','Assgined','Cancelled','Incompleted')

group by tasks.db_status
    
;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `tasks_updateAge`( 
IN p_id INT(11)
)
BEGIN

update tasks 
		set db_age = 
		if(isnull(db_Date_of_Closure),'N/A', CONCAT(
			if(TIMESTAMPDIFF(day,db_Time,db_Date_of_Closure)=0,'',concat(TIMESTAMPDIFF(day,db_Time,db_Date_of_Closure),' D ')) ,
			if(MOD( TIMESTAMPDIFF(hour,db_Time,db_Date_of_Closure), 24)=0,'',concat(MOD( TIMESTAMPDIFF(hour,db_Time,db_Date_of_Closure), 24), ' H ')),
			if(MOD( TIMESTAMPDIFF(minute,db_Time,db_Date_of_Closure), 60)=0, if (TIMESTAMPDIFF(day,db_Time,db_Date_of_Closure)<>0 and MOD( TIMESTAMPDIFF(hour,db_Time,db_Date_of_Closure), 24)<>0,'','0 M'),concat(MOD( TIMESTAMPDIFF(minute,db_Time,db_Date_of_Closure), 24), ' M '))
			)),
			db_age_min = if(isnull(db_Date_of_Closure),0,TIMESTAMPDIFF(minute,db_Time,db_Date_of_Closure)) 

where db_id = p_id;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `template_get_by_id`(
IN p_id INT(11)
)
BEGIN
SELECT t.*, ty.name as db_type, c.name as db_category, sc.name as db_sub_category, u.db_fullname as db_user_name, DATE_FORMAT(t.db_entry_date,'%h:%i %p') as 'db_entry_date_formated'
FROM templates t, users u, types ty, categories c, subcategories sc
WHERE t.db_del = 'No'
AND t.db_created_by = u.db_id
AND t.db_type_id = ty.id
AND t.db_category_id = c.id
AND t.db_sub_category_id = sc.id
AND t.db_id = p_id
ORDER BY t.db_id desc

;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `template_get_by_module`(
IN p_module VARCHAR(45)
)
BEGIN
SELECT t.*, ty.name as db_type, c.name as db_category, sc.name as db_sub_category, u.db_fullname as db_user_name, DATE_FORMAT(t.db_entry_date,'%h:%i %p') as 'db_entry_date_formated'
FROM templates t, users u, types ty, categories c, subcategories sc
WHERE t.db_del = 'No'
AND t.db_created_by = u.db_id
AND t.db_type_id = ty.id
AND t.db_category_id = c.id
AND t.db_sub_category_id = sc.id
AND t.db_module = p_module
ORDER BY t.db_id desc

;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `template_get_by_type`(
IN p_type_id INT(11)
)
BEGIN
SELECT * 
FROM templates 
WHERE db_del = 'No'
AND db_type_id = p_type_id
;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `test_deplicate_entries_example`()
BEGIN
CREATE TEMPORARY TABLE tmp_incidents SELECT * from incidents WHERE db_id = 1027;
ALTER TABLE tmp_incidents drop db_id; 
INSERT INTO incidents SELECT 0,tmp_incidents.* FROM tmp_incidents;
DROP TEMPORARY TABLE tmp_incidents;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `trigger_getAllCaseTriggersByID`(
p_caseID INT(11)
)
BEGIN

SELECT case_triggers.*,use_cases.db_Name as db_UseCase,use_cases.db_MonitoringChannel, DATE_FORMAT(case_triggers.db_dateTime,'%d-%m-%Y %h:%i %p') as db_dateTimeFormated  

FROM case_triggers, use_cases 

WHERE  case_triggers.db_UseCaseID = use_cases.db_ID
    AND case_triggers.db_Del = 'No'
    AND case_triggers.db_CaseID = p_caseID
     
ORDER BY case_triggers.db_ID  
    ;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `trigger_insertNewTrigger`(

IN p_TriggerSourceType VARCHAR(500),
IN p_TriggerSourceName VARCHAR(500),
IN p_Risk VARCHAR(5),
IN p_CaseID int(11),
IN p_UseCaseID int(11)

)
BEGIN

INSERT INTO `case_triggers`
(
`db_TriggerSourceType`,
`db_TriggerSourceName`,
`db_Risk`,
`db_CaseID`,
`db_UseCaseID`
)
VALUES
(
p_TriggerSourceType,
p_TriggerSourceName,
p_Risk,
p_CaseID,
p_UseCaseID
);


END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `triggers_getTriggersBySubcategory`(
IN p_SubCategoryID INT(11)

)
BEGIN

SELECT use_cases.*, IFNULL(v1.db_count,0) as db_countOpen, IFNULL(v2.db_count,0) as db_countFalsePositive, IFNULL(v3.db_count,0) as db_countTotal  
FROM use_cases 
	left outer join (
				SELECT case_triggers.db_UseCaseID, IFNULL(count(*),0)  as db_count
				FROM case_triggers, incidents 
				where case_triggers.db_CaseID = incidents.db_id
				AND incidents.db_Status = 'Open'
                AND case_triggers.db_Del = 'No'
                AND incidents.db_Deleted = 'No'
				group by case_triggers.db_UseCaseID 
    ) as v1 ON use_cases.db_ID = v1.db_UseCaseID 
    left outer join (
    SELECT case_triggers.db_UseCaseID, IFNULL(count(*),0) as db_count
				FROM case_triggers, incidents 
				where case_triggers.db_CaseID = incidents.db_id
                AND incidents.db_FalsePositive_Flag = 'Yes'
                AND case_triggers.db_Del = 'No'
                AND incidents.db_Deleted = 'No'
				group by case_triggers.db_UseCaseID 
    
    ) as v2 ON use_cases.db_ID = v2.db_UseCaseID 
    left outer join (
    SELECT case_triggers.db_UseCaseID, IFNULL(count(*),0) as db_count
				FROM case_triggers, incidents 
				where case_triggers.db_CaseID = incidents.db_id
                AND case_triggers.db_Del = 'No'
                AND incidents.db_Deleted = 'No'
				group by case_triggers.db_UseCaseID 
    
    ) as v3 ON use_cases.db_ID = v3.db_UseCaseID 
      
      
WHERE   
	use_cases.db_SubCatID = p_SubCategoryID
    AND db_Del = 'No'
Group by 1
;
    
    

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `updateCustomeAttribute`(
IN p_Type  VARCHAR(45),
IN p_Name  VARCHAR(100),
IN p_Title longtext,
IN p_Value longtext,
IN p_id INT(11)
)
BEGIN

	UPDATE custom_attributes
	SET 
	db_Type = p_Type, 
	db_Name = p_Name ,
	db_Title = p_Title,
	db_Value = p_Value
	Where db_ID = p_id
;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `updateER`( 
	IN p_StartDateTime VARCHAR(30),
	IN p_Title VARCHAR(200),
	IN p_ManagerID INT(11),
	IN p_CategoryID INT(11),
	IN p_TypeID INT(11),
	IN p_SubCategoryID INT(11),
	IN p_Reference VARCHAR(50),
    IN p_ID INT(11)
	

)
BEGIN
	UPDATE incidents
	set
	db_StartDateTime = p_StartDateTime,
	db_Title = p_Title,
	db_ManagerID = p_ManagerID,
	db_CategoryID = p_CategoryID,
	db_TypeID = p_TypeID,
	db_SubCategoryID = p_SubCategoryID,
	db_Reference = p_Reference
    Where db_ID = p_ID;
	
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `updateERAttributes`( 
	
    IN p_Containment_Date datetime(6),
	IN p_Date_of_Closure datetime(6),
    IN p_Report VARCHAR(30),
    IN p_Severity VARCHAR(30),
    IN p_Status VARCHAR(30),
	IN p_Percentage_of_Progress INT(3),
    IN p_ID INT(11),
	IN p_SamaNotified VARCHAR(30) 
)
BEGIN
	UPDATE incidents
	set
	db_Containment_Date = p_Containment_Date,
	db_Date_of_Closure = p_Date_of_Closure,
	db_Report = p_Report,
    db_SamaNotified = p_SamaNotified,
	db_Severity = p_Severity,
	db_Status = p_Status,
	db_Percentage_of_Progress = p_Percentage_of_Progress
    Where db_ID = p_ID;
	
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `updateERBasicInfo`( 
	IN p_StartDateTime VARCHAR(30),
	IN p_Title VARCHAR(200),
	IN p_ManagerID INT(11),
	IN p_CategoryID INT(11),
	IN p_TypeID INT(11),
	IN p_SubCategoryID INT(11),
	IN p_Reference VARCHAR(50),
    IN p_ID INT(11)
	

)
BEGIN
	UPDATE incidents
	set
	db_StartDateTime = p_StartDateTime,
	db_Title = p_Title,
	db_ManagerID = p_ManagerID,
	db_CategoryID = p_CategoryID,
	db_TypeID = p_TypeID,
	db_SubCategoryID = p_SubCategoryID,
	db_Reference = p_Reference
    Where db_ID = p_ID;
	
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `updateEvidence`(

p_CollectionDate VARCHAR(30),
p_CollectedBy VARCHAR(500),
p_Type VARCHAR(45),
p_StorageLocation VARCHAR(1000),
p_Notes longtext,
p_Description VARCHAR(5000),
p_CollectedFrom VARCHAR(45),
p_EvidenceID int(11),
p_Attachment VARCHAR(50)
)
BEGIN
UPDATE `evidences`
SET

`db_CollectionDate` = p_CollectionDate,
`db_CollectedBy` = p_CollectedBy,
`db_Type` = p_Type,
`db_StorageLocation` = p_StorageLocation,
`db_Notes` = p_Notes,
`db_Description` = p_Description,
`db_CollectedFrom` = p_CollectedFrom,
`db_Attachment` = p_Attachment
WHERE `db_ID` = p_EvidenceID;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `updateUserLogs`(IN logsP INT(20), IN useridP INT(11))
BEGIN
    update `users` set db_LastLogin=NOW(),db_Logs=logsP where db_ID=useridP;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `usecases_getAll`()
BEGIN
SELECT uc.*, sc.`Name` as 'db_subCat', DATE_FORMAT(uc.db_LastUpdate,'%d-%m-%Y %h:%i %p') as 'db_LastUpdateFormatted'
FROM use_cases uc
LEFT JOIN subcategories sc on uc.db_SubCatID = sc.ID
WHERE uc.db_del = 'No'
ORDER BY uc.db_ID DESC
;


END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `userRoles`()
BEGIN
    SELECT * FROM userroles;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `usersByAdmin`()
BEGIN
    SELECT users.*, userroles.Role
  FROM users, userroles 
  WHERE(users.RoleID = userroles.ID) 
  AND (users.db_SystemReserved = 'No')
  ORDER BY userroles.role,users.ID DESC;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `usersByEditor`()
BEGIN
    SELECT users.*, userroles.Role 
  FROM users, userroles 
  WHERE(users.RoleID = userroles.ID) AND (users.db_SystemReserved = 'No') AND users.RoleID <> 3 
  ORDER BY userroles.role,users.ID DESC;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `users_countLicensedUsers`(
IN p_module varchar(100)
)
BEGIN
Select count(u.db_id) as 'db_count' 
from users u, user_profiles up, userroles ur
where (up.Name IN ('Manager','Analyst','Limited') AND u.db_UserName <> 'admin' )
and u.db_UserProfileID = up.id 
and u.db_RoleID = ur.id 
and u.db_Module = p_module 
and u.db_del = 'F'
and ur.Role <> 'System Admin' 
;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `users_deleteUser`(
IN  p_UserID INT(20)

)
BEGIN
 
UPDATE users SET
db_Del = 'T'
WHERE db_ID=p_UserID; 
 
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `users_get_community_groups`(
IN p_user_id INT(11)
)
BEGIN

select u.db_id db_user_id, c.db_id as db_community_group_id , c.db_Name as db_community_group
from users u, community_groups c, user_community_groups uc 
where u.db_id = uc.db_user_id
AND c.db_id = uc.db_community_group_id
AND u.db_id = p_user_id
;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `users_getNotificationEnabledUsers`(
IN p_module varchar(50) 
)
BEGIN
SELECT u.*, up.`name` as db_profile
FROM  users u, user_profiles up
	where (u.db_UserProfileID = up.ID)
    AND (u.db_Module = p_module)
	AND (u.db_Del = 'F') 
	AND (u.db_SystemReserved = 'No') 
	AND (u.db_Dep <> 'Coordinators')
    AND (u.db_Notifications_Enabled = 'Yes')
    AND (up.Name IN ('Analyst','Manager'))
    
    ;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `users_getNotificationEnabledUsers_ByProfile_ByGroup`(
IN p_module varchar(50),
IN p_limited_group varchar(50)
)
BEGIN
SELECT group_concat(DISTINCT u.db_Email SEPARATOR ';') db_recipiants_list
FROM  users u, user_profiles up
	where (u.db_UserProfileID = up.ID)
    AND (u.db_Module = p_module)
	AND (u.db_Del = 'F') 
	AND (u.db_SystemReserved = 'No') 
	AND (u.db_Dep <> 'Coordinators')
    AND (u.db_Notifications_Enabled = 'Yes')
    AND (up.Name IN ('Analyst','Manager') or (up.Name = 'Limited' and u.db_group = p_limited_group))
    ;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `users_getUserInfoByID`(
IN UserIDP INT(20)
)
BEGIN
SELECT users.*, userroles.Role as db_role, users_1.db_FullName AS db_CreatedBy, user_profiles.`Name` as db_Profile
FROM users, users AS users_1, userroles, user_profiles 
WHERE (users.db_ID=UserIDP) 
AND (users.db_CreatedByID = users_1.db_ID) 
AND (users.db_RoleID = userroles.ID)
AND (users.db_UserProfileID = user_profiles.ID) 
AND (users.db_SystemReserved = 'No')
ORDER BY db_role,users.db_ID DESC;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `users_getUsers`(
IN p_module varchar(50)
)
BEGIN
SELECT users.*,DATE_FORMAT(users.db_LastLogin,'%d-%m-%Y %h:%i %p') as 'db_LastLoginFormatted', userroles.Role as db_Role,user_profiles.`Name` as db_Profile
FROM users, userroles , user_profiles 
WHERE (users.db_RoleID = userroles.ID) 
AND (users.db_UserProfileID = user_profiles.ID)
AND (users.db_Del = 'F') 
AND (users.db_SystemReserved = 'No') 
AND (users.db_Dep <> 'Coordinators')
AND (users.db_Module = p_module)
ORDER BY users.db_ID DESC;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `users_insertUser`(
 
IN p_UserName VARCHAR(20), 
IN p_PW VARCHAR(500), 
IN p_Email VARCHAR(100), 
IN p_FullName VARCHAR(100), 
IN p_Phone VARCHAR(20), 
IN p_CellPhone VARCHAR(20), 
IN p_Status VARCHAR(20), 
IN p_EmpID VARCHAR(20), 
IN p_PhoneEx VARCHAR(20), 
IN p_Floor VARCHAR(100), 
IN p_JobTitle VARCHAR(100), 
IN p_Building VARCHAR(100), 
IN p_Dep VARCHAR(100),
IN p_RoleID INT(20),  
IN p_CreatedByID INT(20), 
IN p_LManager VARCHAR(100),
IN p_AuthType VARCHAR(100),
IN p_UserProfileID INT(20),
IN p_Group VARCHAR(100),
OUT p_id INT(11)

 
  )
BEGIN
 INSERT INTO `users`
(
db_UserName,
db_PW,
db_Email,
db_FullName,
db_RDate,
db_RoleID,
db_Del,
db_Phone,
db_CellPhone,
db_CreatedByID,
db_LManager,
db_Status,
db_EmpID,
db_PhoneEx,
db_Floor,
db_JobTitle,
db_Building,
db_Dep,
db_AuthType,
db_UserProfileID,
db_Group
)
VALUES
(
p_UserName,
p_PW,
p_Email,
p_FullName,
NOW(),
p_RoleID,
'F',
p_Phone,
p_CellPhone,
p_CreatedByID,
p_LManager,
p_Status,
p_EmpID,
p_PhoneEx,
p_Floor,
p_JobTitle,
p_Building,
p_Dep,
p_AuthType,
p_UserProfileID,
p_Group
);

SET p_id = last_insert_id();

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `usersList`()
BEGIN
SELECT * FROM users 
WHERE db_Status = 'Active' 
AND (db_SystemReserved = 'No')
Order By db_UserName;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `users_login`(
IN usernameP VARCHAR(100) 

)
BEGIN
 
    select users.*, userroles.role as db_Role,  user_profiles.`name` as db_Profile
    from users,userroles,user_profiles 
    where users.db_UserProfileID=user_profiles.id 
    AND users.db_roleid=userroles.id 
    AND Lower(users.db_UserName)=lower(usernameP) 
    AND users.db_Del='F';
 
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `users_ResetUserPassword`(
  IN UserIDP INT(20),
  IN PWP VARCHAR(500)
 
 
  )
BEGIN
 
UPDATE users SET
 
db_PW=PWP
 
WHERE db_ID=UserIDP; 
 
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `users_updateUser`(
 
IN  p_UserID INT(20),
IN  p_RoleID INT(20),
IN  p_LManager VARCHAR(100),
IN  p_UserName VARCHAR(50),
IN  p_Email VARCHAR(100),
IN  p_FullName VARCHAR(100),
IN  p_Phone VARCHAR(50),
IN  p_CellPhone VARCHAR(50),
IN  p_Status VARCHAR(30),
IN  p_EmpID VARCHAR(30),
IN  p_PhoneEx VARCHAR(20),
IN  p_Floor VARCHAR(50),
IN  p_JobTitle VARCHAR(500),
IN  p_Building VARCHAR(500),
IN  p_Dep VARCHAR(500),
IN  p_Pic VARCHAR(500),
IN  p_AuthType VARCHAR(100),
IN  p_UserProfileID INT(20),
IN  p_Group VARCHAR(100)

)
BEGIN
 
UPDATE users SET
db_UserName = p_UserName,
db_Email = p_Email,
db_FullName = p_FullName,
db_RoleID = p_RoleID,
db_UserProfileID = p_UserProfileID,
db_Phone = p_Phone,
db_CellPhone = p_CellPhone,
db_LManager = p_LManager,
db_Status = p_Status,
db_EmpID = p_EmpID,
db_PhoneEx = p_PhoneEx,
db_Floor = p_Floor,
db_JobTitle = p_JobTitle,
db_Building = p_Building,
db_Dep = p_Dep,
db_Pic = p_Pic,
db_AuthType = p_AuthType,
db_Group = p_Group
WHERE db_ID=p_UserID; 
 
END$$
DELIMITER ;
