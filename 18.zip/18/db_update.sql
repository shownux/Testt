ALTER TABLE `q_main_base`.`orchestrator_jobs` ADD COLUMN `db_execution_type` VARCHAR(45) NULL DEFAULT 'Auto' COMMENT 'Auto\nFetch' AFTER `db_allowed_view`;

UPDATE `q_main_base`.`system_properties` SET `db_Applied_To_Module` = 'simp' WHERE (`db_Name` = 'ESCALATED_INCIDENTS_VIEW_ENABLED');

Update incidents  set db_Severity = 'Low' where db_Severity = '' OR db_Severity = null;