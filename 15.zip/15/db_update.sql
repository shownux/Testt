DROP TABLE IF EXISTS  `incident_rfi`;
CREATE TABLE `incident_rfi` (
  `db_id` int NOT NULL AUTO_INCREMENT,
  `db_erid` int DEFAULT NULL,
  `db_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `db_title` varchar(100) DEFAULT NULL,
  `db_label` longtext,
  `db_default` longtext,
  `db_placeholder` varchar(500) DEFAULT '',
  `db_del` varchar(3) DEFAULT 'No',
  `db_EntryDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `db_LastUpdateTime` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `db_user_id` int DEFAULT NULL,
  `db_required` varchar(3) DEFAULT 'Yes',
  `db_multiple_selection` varchar(3) DEFAULT 'Yes',
  PRIMARY KEY (`db_id`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS  `community_article_views`;
CREATE TABLE `community_article_views` (
  `db_user_id` int DEFAULT NULL,
  `db_erid` int DEFAULT NULL,
  `db_view_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `db_module` varchar(5) DEFAULT 'ctsp'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

DROP TABLE IF EXISTS  `community_groups`;
CREATE TABLE `community_groups` (
  `db_ID` int NOT NULL AUTO_INCREMENT,
  `db_Name` varchar(100) DEFAULT 'New Group',
  `db_Del` varchar(3) DEFAULT 'No',
  `db_LastUpdate` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `db_module` varchar(5) DEFAULT 'ctsp',
  PRIMARY KEY (`db_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;



DROP TABLE IF EXISTS  `rfi`;
CREATE TABLE `rfi` (
  `db_id` int NOT NULL AUTO_INCREMENT,
  `db_erid` int DEFAULT NULL,
  `db_user_id` int DEFAULT NULL,
  `db_rfi_id` int DEFAULT NULL,
  `db_value` longtext,
  `db_file_name` varchar(100) DEFAULT NULL,
  `db_del` varchar(3) DEFAULT 'No',
  `db_EntryDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`db_id`)
) ENGINE=InnoDB AUTO_INCREMENT=547 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;



DROP TABLE IF EXISTS  `share`;
CREATE TABLE `share` (
  `db_id` int NOT NULL AUTO_INCREMENT,
  `db_erid` int DEFAULT NULL,
  `db_rfi_acknowledge` varchar(3) DEFAULT 'No',
  `db_rfi_respond` varchar(3) DEFAULT 'No',
  `db_shared_with_id` int DEFAULT NULL,
  `db_shared_by_id` int DEFAULT NULL,
  `db_del` varchar(3) DEFAULT 'No',
  `db_EntryDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `db_LastUpdateTime` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `db_Share_Acknowledge_Date` datetime DEFAULT NULL,
  `db_Share_Acknowledge_Duration` int DEFAULT '0',
  `db_Share_Acknowledge_Status` varchar(45) DEFAULT 'Not Started',
  `db_Share_Acknowledge_SLA_Violated` varchar(5) DEFAULT 'No',
  `db_Share_Acknowledge_Escalation_Email_Sent` varchar(5) DEFAULT 'No',
  `db_Share_Acknowledge_SLA_Warning_Email_Sent` varchar(5) DEFAULT 'No',
  `db_Share_Response_Date` datetime DEFAULT NULL,
  `db_Share_Response_Duration` int DEFAULT '0',
  `db_Share_Response_Status` varchar(45) DEFAULT 'Not Started',
  `db_Share_Response_SLA_Violated` varchar(5) DEFAULT 'No',
  `db_Share_Response_Escalation_Email_Sent` varchar(5) DEFAULT 'No',
  `db_Share_Response_SLA_Warning_Email_Sent` varchar(5) DEFAULT 'No',
  PRIMARY KEY (`db_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

DROP TABLE IF EXISTS  `user_community_groups`;
CREATE TABLE `user_community_groups` (
  `db_community_group_id` int NOT NULL,
  `db_user_id` int NOT NULL,
  `db_del` varchar(5) DEFAULT 'No',
  `db_EntryDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `db_LastUpdateTime` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`db_community_group_id`,`db_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;



DROP TABLE IF EXISTS  `discussion`;
CREATE TABLE `discussion` (
  `db_id` int NOT NULL AUTO_INCREMENT,
  `db_user_id` int DEFAULT NULL,
  `db_entry_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `db_post` longtext,
  `db_del` varchar(3) DEFAULT 'No',
  `db_object` varchar(45) DEFAULT NULL,
  `db_object_id` int DEFAULT NULL,
  `db_attachment_name` varchar(100) DEFAULT 'No',
  `db_file_name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`db_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;




DROP TABLE IF EXISTS  `rfi_templates`;
CREATE TABLE `rfi_templates` (
  `db_id` int NOT NULL AUTO_INCREMENT,
  `db_group_name` varchar(45) DEFAULT 'New Item',
  `db_type` varchar(100) DEFAULT 'Text',
  `db_title` varchar(100) DEFAULT NULL,
  `db_label` longtext,
  `db_default` longtext,
  `db_placeholder` longtext,
  `db_del` varchar(3) DEFAULT 'No',
  `db_EntryDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `db_LastUpdateTime` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `db_user_id` int DEFAULT NULL,
  `db_required` varchar(3) DEFAULT 'Yes',
  `db_multiple_selection` varchar(3) DEFAULT 'Yes',
  `db_module` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`db_id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;